import base64
import gzip
import json
import os
import re
import signal
import shutil
import subprocess
import tarfile
import threading
import time
import uuid
import zipfile
from datetime import datetime
from pathlib import Path
from urllib.parse import quote, unquote
from zoneinfo import ZoneInfo

import requests
from flask import Flask, Response, after_this_request, jsonify, make_response, redirect, request, send_file, session
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

APP = Flask(__name__)
APP.secret_key = os.environ.get('APP_SECRET', 'change-me-offline-panel-2026')
BASE = Path('/srv/offline-downloader')
DOWNLOADS = BASE / 'downloads'
TMP = BASE / 'tmp'
CONFIG = BASE / 'config.json'
HLS_JOBS = BASE / 'hls_jobs.json'
ARIA_CONF = BASE / 'aria2' / 'aria2.conf'
TRACKER_META = BASE / 'tracker_meta.json'
SESSIONS = BASE / 'sessions.json'
UPDATE_STATUS = BASE / 'update_status.json'
UPDATE_REQUEST = BASE / 'update_request.json'
TASK_SOURCES = BASE / 'task_sources.json'
TRASH = BASE / 'trash'
TRASH_META = BASE / 'trash.json'
YTDLP_COOKIES = BASE / 'ytdlp_cookies.txt'
YTDLP_COOKIES_DIR = BASE / 'ytdlp_cookies'
HOST_PROJECT_DIR = Path(os.environ.get('HOST_PROJECT_DIR', '/opt/offline-downloader-docker'))
ARIA_RPC = os.environ.get('ARIA_RPC', 'http://127.0.0.1:6800/jsonrpc')
ARIA_SECRET = os.environ.get('ARIA_SECRET', 'offline_rpc_2026')
INITIAL_ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'qq123456')
APP_VERSION = os.environ.get('APP_VERSION', 'V1.5.9')
VIDEO_EXT = {'.mp4', '.mkv', '.webm', '.mov', '.m4v', '.avi', '.ts'}
AUDIO_EXT = {'.mp3', '.m4a', '.aac', '.flac', '.wav', '.ogg'}
TIMEZONE_OPTIONS = {
    'local': '系统时间',
    'Asia/Shanghai': '中国/北京',
    'Asia/Tokyo': '日本/东京',
    'Asia/Singapore': '新加坡',
    'America/New_York': '美国/纽约',
    'America/Los_Angeles': '美国/洛杉矶',
    'Europe/London': '英国/伦敦',
    'Europe/Paris': '法国/巴黎',
    'Asia/Dubai': '阿联酋/迪拜',
    'Australia/Sydney': '澳大利亚/悉尼',
}

for p in [DOWNLOADS, TMP, ARIA_CONF.parent, TRASH, YTDLP_COOKIES_DIR]:
    p.mkdir(parents=True, exist_ok=True)
if not CONFIG.exists():
    CONFIG.write_text(json.dumps({'username': 'admin', 'password_hash': generate_password_hash(INITIAL_ADMIN_PASSWORD), 'share_token': uuid.uuid4().hex}, ensure_ascii=False), encoding='utf-8')
else:
    _cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    if not _cfg.get('share_token'):
        _cfg['share_token'] = uuid.uuid4().hex
        CONFIG.write_text(json.dumps(_cfg, ensure_ascii=False, indent=2), encoding='utf-8')
if not HLS_JOBS.exists():
    HLS_JOBS.write_text('[]', encoding='utf-8')
if not TRACKER_META.exists():
    TRACKER_META.write_text(json.dumps({'url': 'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_all.txt', 'updated_at': '', 'count': 0}, ensure_ascii=False, indent=2), encoding='utf-8')
if not SESSIONS.exists():
    SESSIONS.write_text('{}', encoding='utf-8')
if not UPDATE_STATUS.exists():
    UPDATE_STATUS.write_text(json.dumps({'running': False, 'message': '暂无更新任务', 'updated_at': ''}, ensure_ascii=False, indent=2), encoding='utf-8')
if not TASK_SOURCES.exists():
    TASK_SOURCES.write_text('{}', encoding='utf-8')
if not TRASH_META.exists():
    TRASH_META.write_text('[]', encoding='utf-8')


@APP.after_request
def gzip_response(response):
    if response.direct_passthrough:
        return response
    if 'gzip' not in (request.headers.get('Accept-Encoding') or '').lower():
        return response
    if response.headers.get('Content-Encoding'):
        return response
    content_type = response.headers.get('Content-Type') or ''
    if not any(x in content_type for x in ('text/html', 'text/css', 'application/javascript', 'application/json')):
        return response
    data = response.get_data()
    if len(data) < 128:
        return response
    compressed = gzip.compress(data, compresslevel=6)
    response.set_data(compressed)
    response.headers['Content-Encoding'] = 'gzip'
    response.headers['Content-Length'] = str(len(compressed))
    response.headers['Vary'] = 'Accept-Encoding'
    return response


def load_config():
    return json.loads(CONFIG.read_text(encoding='utf-8'))


def save_config(cfg):
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')


def registration_enabled():
    return bool(load_config().get('registration_enabled', False))


def registration_defaults():
    cfg = load_config()
    raw = cfg.get('registration_defaults') if isinstance(cfg.get('registration_defaults'), dict) else {}
    return {
        'quota': str(raw.get('quota') or '0').strip(),
        'speed_limit': str(raw.get('speed_limit') or '*').strip(),
        'expires_at': str(raw.get('expires_at') or '').strip(),
        'allowed_roots': str(raw.get('allowed_roots') or '_users/{username}').strip(),
    }


def stream_prioritize_enabled():
    return bool(load_config().get('bt_stream_prioritize', False))


def proxy_fields_from(container):
    return {
        'video_proxy_type': str(container.get('video_proxy_type') or 'http').strip().lower(),
        'video_proxy_host': str(container.get('video_proxy_host') or '').strip(),
        'video_proxy_port': str(container.get('video_proxy_port') or '').strip(),
        'video_proxy_username': str(container.get('video_proxy_username') or '').strip(),
        'video_proxy_password': str(container.get('video_proxy_password') or '').strip(),
        'video_proxy_enabled': bool(container.get('video_proxy_enabled')),
        'video_proxy_mode': str(container.get('video_proxy_mode') or 'geo').strip().lower(),
    }


def video_proxy_config(username=None):
    cfg = load_config()
    source = cfg
    if username:
        user = user_record(username)
        if user.get('role') != 'admin':
            if not cfg.get('user_proxy_enabled'):
                return False, '', 'geo'
            source = user
    fields = proxy_fields_from(source)
    try:
        url = build_proxy_url(fields['video_proxy_type'], fields['video_proxy_host'], fields['video_proxy_port'], fields['video_proxy_username'], fields['video_proxy_password'])
    except ValueError:
        url = ''
    if not url and source is cfg:
        url = str(cfg.get('video_proxy_url') or '').strip()
    enabled = bool(fields['video_proxy_enabled']) and bool(url)
    mode = fields['video_proxy_mode']
    if mode not in {'geo', 'full'}:
        mode = 'geo'
    return enabled, url, mode


def server_time_string():
    cfg = load_config()
    mode = str(cfg.get('server_time_mode') or 'local')
    if mode == 'local' or mode not in TIMEZONE_OPTIONS:
        return time.strftime('%Y-%m-%d %H:%M:%S')
    try:
        return datetime.now(ZoneInfo(mode)).strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return time.strftime('%Y-%m-%d %H:%M:%S')


def build_proxy_url(proxy_type, host, port, username='', password=''):
    proxy_type = str(proxy_type or 'http').strip().lower()
    host = str(host or '').strip()
    port = str(port or '').strip()
    username = str(username or '').strip()
    password = str(password or '').strip()
    if not host and not port:
        return ''
    if proxy_type not in {'http', 'https', 'socks4', 'socks4a', 'socks5', 'socks5h'}:
        raise ValueError('代理类型不支持')
    if not host:
        raise ValueError('请填写代理 IP 或域名')
    if not port:
        raise ValueError('请填写代理端口')
    if any(x in host for x in ['/', '\\', '\n', '\r', ' ', '\t']):
        raise ValueError('代理 IP/域名不能包含协议、斜杠、空格或换行')
    if not port.isdigit() or not (1 <= int(port) <= 65535):
        raise ValueError('代理端口必须是 1-65535 的数字')
    auth = ''
    if username or password:
        auth = quote(username, safe='') + ':' + quote(password, safe='') + '@'
    return f'{proxy_type}://{auth}{host}:{port}'


def user_language(username=None):
    lang = str(user_record(username).get('language') or 'zh').lower()
    return 'en' if lang == 'en' else 'zh'


def set_aria_conf_option(name, value):
    text = ARIA_CONF.read_text(encoding='utf-8') if ARIA_CONF.exists() else ''
    pattern = rf'^{re.escape(name)}=.*$'
    if value:
        line = f'{name}={value}'
        if re.search(pattern, text, flags=re.M):
            text = re.sub(pattern, line, text, flags=re.M)
        else:
            text = text.rstrip() + '\n' + line + '\n'
    else:
        text = re.sub(pattern + r'\n?', '', text, flags=re.M)
    ARIA_CONF.write_text(text, encoding='utf-8')


def apply_stream_prioritize(enabled):
    value = 'head=4M,tail=4M' if enabled else ''
    set_aria_conf_option('bt-prioritize-piece', value)
    try:
        aria('aria2.changeGlobalOption', [{'bt-prioritize-piece': value}])
    except Exception as e:
        print(f'[settings] changeGlobalOption bt-prioritize-piece failed: {e}', flush=True)


def ensure_users_config():
    cfg = load_config()
    changed = False
    if 'users' not in cfg:
        username = cfg.get('username', 'admin')
        cfg['users'] = {
            username: {
                'password_hash': cfg.get('password_hash', generate_password_hash('qq123456')),
                'role': 'admin' if username == 'admin' else 'user',
                'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                'quota_bytes': 0,
                'allowed_roots': [] if username == 'admin' else [f'_users/{username}'],
                'disclaimer_accepted_at': ''
            }
        }
        changed = True
    if 'admin' not in cfg['users']:
        cfg['users']['admin'] = {'password_hash': generate_password_hash(INITIAL_ADMIN_PASSWORD), 'role': 'admin', 'created_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'quota_bytes': 0, 'allowed_roots': [], 'disclaimer_accepted_at': ''}
        changed = True
    if cfg['users'].get('admin', {}).get('role') != 'admin':
        cfg['users']['admin']['role'] = 'admin'
        changed = True
    for name, user in cfg.get('users', {}).items():
        if 'disclaimer_accepted_at' not in user:
            user['disclaimer_accepted_at'] = ''
            changed = True
        if 'language' not in user:
            user['language'] = 'zh'
            changed = True
    if changed:
        save_config(cfg)
    return cfg


SESSIONS_LOCK = threading.Lock()


def _read_sessions_unlocked():
    try:
        data = json.loads(SESSIONS.read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def read_sessions():
    with SESSIONS_LOCK:
        return _read_sessions_unlocked()


def _write_sessions_unlocked(data):
    tmp = SESSIONS.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(SESSIONS)


def write_sessions(data):
    with SESSIONS_LOCK:
        _write_sessions_unlocked(data)


def client_ip():
    forwarded = (request.headers.get('X-Forwarded-For') or '').split(',')[0].strip()
    return forwarded or request.remote_addr or '-'


def short_ua(value):
    value = (value or '').strip()
    if not value:
        return '-'
    value = re.sub(r'\s+', ' ', value)
    return value[:120]


def create_login_session(username):
    sid = uuid.uuid4().hex
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    with SESSIONS_LOCK:
        data = _read_sessions_unlocked()
        data[sid] = {'username': username, 'ip': client_ip(), 'user_agent': short_ua(request.headers.get('User-Agent')), 'created_at': now, 'last_seen': now}
        _write_sessions_unlocked(data)
    return sid


def touch_login_session(username, sid):
    if not sid:
        return False
    with SESSIONS_LOCK:
        data = _read_sessions_unlocked()
        item = data.get(sid)
        if not item or item.get('username') != username:
            return False
        item['last_seen'] = time.strftime('%Y-%m-%d %H:%M:%S')
        item['ip'] = client_ip()
        _write_sessions_unlocked(data)
    return True


def remove_login_session(sid):
    if not sid:
        return
    with SESSIONS_LOCK:
        data = _read_sessions_unlocked()
        if sid in data:
            del data[sid]
            _write_sessions_unlocked(data)


def remove_user_sessions(username):
    with SESSIONS_LOCK:
        data = _read_sessions_unlocked()
        changed = False
        for sid, item in list(data.items()):
            if item.get('username') == username:
                del data[sid]
                changed = True
        if changed:
            _write_sessions_unlocked(data)


def user_devices(username):
    data = read_sessions()
    out = []
    for sid, item in sorted(data.items(), key=lambda kv: kv[1].get('last_seen', ''), reverse=True):
        if item.get('username') == username:
            out.append({'id': sid, 'current': sid == session.get('sid'), 'ip': item.get('ip', '-'), 'user_agent': item.get('user_agent', '-'), 'created_at': item.get('created_at', ''), 'last_seen': item.get('last_seen', '')})
    return out


def current_user():
    return session.get('user') or ('admin' if session.get('ok') else '')


def is_admin():
    if not authed():
        return False
    cfg = ensure_users_config()
    user = current_user()
    return cfg.get('users', {}).get(user, {}).get('role') == 'admin'


def valid_username(name):
    return bool(re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_-]{2,31}', name or ''))


def captcha_new():
    a = 10 + (uuid.uuid4().int % 40)
    b = 1 + ((uuid.uuid4().int >> 8) % 30)
    session['register_captcha_answer'] = str(a + b)
    session['register_captcha_at'] = time.time()
    return f'{a} + {b} = ?'


def captcha_valid(answer):
    expected = str(session.get('register_captcha_answer') or '')
    created = float(session.get('register_captcha_at') or 0)
    session.pop('register_captcha_answer', None)
    session.pop('register_captcha_at', None)
    if not expected or time.time() - created > 600:
        return False
    return str(answer or '').strip() == expected


def authed():
    if session.get('ok') is not True:
        return False
    username = session.get('user') or ('admin' if session.get('ok') else '')
    if not username:
        session.clear()
        return False
    cfg = ensure_users_config()
    if username not in cfg.get('users', {}):
        remove_login_session(session.get('sid'))
        session.clear()
        return False
    if user_expired(username):
        remove_login_session(session.get('sid'))
        session.clear()
        return False
    if not touch_login_session(username, session.get('sid')):
        session.clear()
        return False
    return True


def require_auth_json():
    if not authed():
        return jsonify({'ok': False, 'error': '未登录'}), 401
    return None


def parse_size_to_bytes(value):
    text = str(value or '').strip().lower()
    if not text or text in {'0', 'unlimited', '无限制'}:
        return 0
    m = re.fullmatch(r'([0-9]+(?:\.[0-9]+)?)\s*(b|k|kb|m|mb|g|gb|t|tb)?', text)
    if not m:
        raise ValueError('空间格式错误，例如 500M、2G、10240M，0 表示无限制')
    n = float(m.group(1))
    unit = m.group(2) or 'b'
    unit = {'k':'kb','m':'mb','g':'gb','t':'tb'}.get(unit, unit)
    mult = {'b':1, 'kb':1024, 'mb':1024**2, 'gb':1024**3, 'tb':1024**4}[unit]
    return int(n * mult)


def user_record(username=None):
    cfg = ensure_users_config()
    username = username or current_user()
    return cfg.get('users', {}).get(username, {})


def disclaimer_accepted(username=None):
    return bool(user_record(username).get('disclaimer_accepted_at'))


def normalize_expiry(value):
    text = str(value or '').strip()
    if not text or text in {'*', '0', '永久', '无限制'}:
        return ''
    for fmt, suffix in (('%Y-%m-%d', ' 23:59:59'), ('%Y-%m-%d %H:%M', ':00'), ('%Y-%m-%d %H:%M:%S', '')):
        try:
            time.strptime(text, fmt)
            return text + suffix
        except ValueError:
            pass
    raise ValueError('到期日期格式错误，例如 2026-12-31 或 2026-12-31 23:59')


def user_expired(username=None):
    user = user_record(username)
    if user.get('role') == 'admin':
        return False
    expires_at = user.get('expires_at') or ''
    if not expires_at:
        return False
    try:
        return time.time() > time.mktime(time.strptime(expires_at, '%Y-%m-%d %H:%M:%S'))
    except Exception:
        return False


def fmt_expiry(username=None):
    user = user_record(username)
    if user.get('role') == 'admin':
        return '管理员'
    return user.get('expires_at') or '永久有效'


def parse_speed_to_bytes(value):
    text = str(value or '').strip().lower().replace('/s', '').replace('每秒', '')
    if not text or text in {'*', '0', 'unlimited', '无限制'}:
        return 0
    m = re.fullmatch(r'([0-9]+(?:\.[0-9]+)?)\s*(b|k|kb|m|mb|g|gb)?', text)
    if not m:
        raise ValueError('限速格式错误，例如 500K、2M，* 表示不限速')
    n = float(m.group(1))
    unit = m.group(2) or 'b'
    unit = {'k':'kb','m':'mb','g':'gb'}.get(unit, unit)
    mult = {'b':1, 'kb':1024, 'mb':1024**2, 'gb':1024**3}[unit]
    return int(n * mult)


def fmt_speed_limit(n):
    n = int(n or 0)
    return '*' if n <= 0 else fmt_bytes(n) + '/s'


def user_speed_limit_bytes(username=None):
    return int(user_record(username).get('speed_limit_bytes') or 0)


def aria_speed_option(username=None):
    limit = user_speed_limit_bytes(username)
    return str(limit) if limit > 0 else '0'


def apply_user_speed_limit_to_task(gid, owner):
    if not gid or not owner:
        return
    try:
        aria('aria2.changeOption', [gid, {'max-download-limit': aria_speed_option(owner)}])
    except Exception as e:
        print(f'[speed] changeOption failed gid={gid} owner={owner}: {e}', flush=True)


def ensure_user_defaults(username):
    cfg = ensure_users_config()
    user = cfg.get('users', {}).get(username)
    if not user:
        return cfg
    changed = False
    if username != 'admin' and user.get('role') != 'admin':
        default_root = f'_users/{username}'
        if 'allowed_roots' not in user:
            user['allowed_roots'] = [default_root]
            changed = True
        if 'quota_bytes' not in user:
            user['quota_bytes'] = 0
            changed = True
        if 'expires_at' not in user:
            user['expires_at'] = ''
            changed = True
        (DOWNLOADS / default_root).mkdir(parents=True, exist_ok=True)
    if changed:
        save_config(cfg)
    return cfg


def user_allowed_roots(username=None):
    username = username or current_user()
    if not username:
        return ['']
    cfg = ensure_user_defaults(username)
    user = cfg.get('users', {}).get(username, {})
    if user.get('role') == 'admin':
        return ['']
    roots = user.get('allowed_roots') or [f'_users/{username}']
    clean = []
    for r in roots:
        r = str(r or '').strip().strip('/')
        if r == '*':
            clean.append('*')
        elif r and '..' not in Path(r).parts:
            clean.append(r)
    if not clean:
        clean = [f'_users/{username}']
    for r in clean:
        if r != '*':
            (DOWNLOADS / r).mkdir(parents=True, exist_ok=True)
    return clean


def path_is_allowed(path, username=None):
    username = username or current_user()
    try:
        target = path.resolve()
        base = DOWNLOADS.resolve()
    except Exception:
        return False
    if target != base and base not in target.parents:
        return False
    user = user_record(username)
    if user.get('role') == 'admin':
        return True
    for root in user_allowed_roots(username):
        if root == '*':
            return True
        allowed = (DOWNLOADS / root).resolve()
        if target == allowed or allowed in target.parents:
            return True
    return False


def safe_path(rel=''):
    rel = unquote(rel or '').strip('/')
    target = (DOWNLOADS / rel).resolve()
    if not path_is_allowed(target):
        raise ValueError('路径非法或没有访问权限')
    return target


def directory_size(path):
    total = 0
    path = Path(path)
    if not path.exists():
        return 0
    if path.is_file():
        return path.stat().st_size
    for f in path.rglob('*'):
        try:
            if f.is_file():
                total += f.stat().st_size
        except FileNotFoundError:
            pass
    return total


def user_quota_roots(username=None):
    username = username or current_user()
    if not username:
        return []
    user = user_record(username)
    if user.get('role') == 'admin':
        return ['']
    # Quota is always charged to the user's own private folder. Access roots
    # such as "*" only control browsing permissions, not quota ownership.
    root = f'_users/{username}'
    (DOWNLOADS / root).mkdir(parents=True, exist_ok=True)
    return [root]


def user_usage_bytes(username=None):
    username = username or current_user()
    if not username:
        return 0
    active_size = sum(directory_size(DOWNLOADS / r) if r else directory_size(DOWNLOADS) for r in user_quota_roots(username))
    trash_size = 0
    for item in read_trash():
        if item.get('user') != username:
            continue
        try:
            p = trash_item_path(item)
            trash_size += directory_size(p) if p.exists() else int(item.get('size') or 0)
        except Exception:
            trash_size += int(item.get('size') or 0)
    return active_size + trash_size


def user_primary_dir(username=None):
    username = username or current_user()
    user = user_record(username)
    if username and user.get('role') != 'admin':
        primary = f'_users/{username}'
    else:
        roots = user_allowed_roots(username)
        primary = f'_users/{username}' if roots and roots[0] == '*' else (roots[0] if roots else '')
    path = DOWNLOADS / primary
    path.mkdir(parents=True, exist_ok=True)
    return path


def user_for_download_path(path):
    try:
        target = Path(path).resolve()
    except Exception:
        return None
    cfg = ensure_users_config()
    best = None
    best_len = -1
    for username, user in cfg.get('users', {}).items():
        if user.get('role') == 'admin':
            continue
        for root in user_allowed_roots(username):
            if root == '*':
                # Star users share the whole tree; prefer explicit directory owners first.
                continue
            allowed = (DOWNLOADS / root).resolve()
            if target == allowed or allowed in target.parents:
                score = len(str(allowed))
                if score > best_len:
                    best = username
                    best_len = score
    if best:
        return best
    # Fallback for conventional per-user folders.
    try:
        rel = target.relative_to(DOWNLOADS.resolve())
        parts = rel.parts
        if len(parts) >= 2 and parts[0] == '_users':
            return parts[1]
    except Exception:
        pass
    return None


def aria_task_owner(info):
    for f in (info or {}).get('files') or []:
        owner = user_for_download_path(f.get('path') or '')
        if owner:
            return owner
    return None


def aria_task_allowed(info):
    if is_admin():
        return True
    files = (info or {}).get('files') or []
    if not files:
        return False
    paths = [f.get('path') or '' for f in files if f.get('path')]
    if not paths:
        return False
    return all(path_is_allowed(Path(p)) for p in paths)


def hls_job_allowed(job):
    if is_admin():
        return True
    username = current_user()
    if job.get('user'):
        return job.get('user') == username
    rel = job.get('path') or job.get('name') or ''
    try:
        return path_is_allowed((DOWNLOADS / str(rel).strip('/')).resolve())
    except Exception:
        return False


def delete_aria_task(tid, delete_files=False):
    info = None
    try:
        info = aria('aria2.tellStatus', [tid, ['files']])
    except Exception:
        pass
    if not info and not is_admin():
        return False
    if info and not aria_task_allowed(info):
        return False
    for m in ['aria2.forceRemove', 'aria2.remove', 'aria2.removeDownloadResult']:
        try:
            aria(m, [tid])
        except Exception:
            pass
    try:
        aria('aria2.saveSession', [])
    except Exception:
        pass
    if delete_files and info:
        for f in info.get('files') or []:
            p = Path(f.get('path','')).resolve()
            if str(p).startswith(str(DOWNLOADS.resolve())) and p.exists():
                move_to_trash(p)
    return True


def delete_hls_task(tid, delete_files=False):
    jobs = read_hls_jobs()
    job = next((j for j in jobs if j['id'] == tid), None)
    if job and not hls_job_allowed(job):
        return False
    if job and job.get('pid'):
        try:
            os.kill(int(job['pid']), signal.SIGTERM)
        except ProcessLookupError:
            pass
        except Exception:
            pass
    jobs = [j for j in jobs if j['id'] != tid]
    write_hls_jobs(jobs)
    if delete_files and job:
        rel = job.get('path') or job.get('name')
        try:
            p = safe_path(rel)
            if p.exists():
                move_to_trash(p)
        except Exception:
            pass
    return True


def signal_hls_task(tid, sig, paused):
    jobs = read_hls_jobs()
    job = next((j for j in jobs if j['id'] == tid), None)
    if not job:
        return True
    if not hls_job_allowed(job):
        return False
    pid = job.get('pid')
    if not pid:
        return True
    try:
        os.kill(int(pid), sig)
    except ProcessLookupError:
        pass
    except Exception:
        pass
    update_hls(tid, status='paused' if paused else 'active', speed='0 B/s' if paused else '', message='已暂停' if paused else '已继续')
    return True


def quota_exceeded_for_user(username):
    user = user_record(username)
    quota = int(user.get('quota_bytes') or 0)
    if not quota:
        return False, 0, 0
    used = user_usage_bytes(username)
    return used >= quota, used, quota


def quota_guard_loop():
    while True:
        try:
            keys = ['gid', 'status', 'files']
            tasks = aria('aria2.tellActive', [keys]) + aria('aria2.tellWaiting', [0, 100, keys])
            for task in tasks:
                gid = task.get('gid')
                files = task.get('files') or []
                owner = None
                for f in files:
                    path = f.get('path') or ''
                    owner = user_for_download_path(path)
                    if owner:
                        break
                if not owner:
                    continue
                exceeded, used, quota = quota_exceeded_for_user(owner)
                if exceeded:
                    print(f'[quota] user={owner} used={used} quota={quota} stopping gid={gid}', flush=True)
                    stopped = False
                    for method in ('aria2.forceRemove', 'aria2.remove', 'aria2.forcePause'):
                        try:
                            aria(method, [gid])
                            stopped = True
                            print(f'[quota] {method} ok gid={gid}', flush=True)
                            break
                        except Exception as e:
                            print(f'[quota] {method} failed gid={gid}: {e}', flush=True)
                    if stopped:
                        try:
                            aria('aria2.removeDownloadResult', [gid])
                        except Exception as e:
                            print(f'[quota] removeDownloadResult failed gid={gid}: {e}', flush=True)
                        try:
                            aria('aria2.saveSession', [])
                        except Exception as e:
                            print(f'[quota] saveSession failed gid={gid}: {e}', flush=True)
        except Exception as e:
            print(f'[quota] guard loop error: {e}', flush=True)
        time.sleep(5)


def start_quota_guard():
    if getattr(APP, '_quota_guard_started', False):
        return
    APP._quota_guard_started = True
    threading.Thread(target=quota_guard_loop, daemon=True).start()


def ensure_quota_available():
    if is_admin():
        return None
    user = user_record()
    quota = int(user.get('quota_bytes') or 0)
    if quota and user_usage_bytes() >= quota:
        return jsonify({'ok': False, 'error': f'空间额度已用完：{fmt_bytes(user_usage_bytes())} / {fmt_bytes(quota)}'}), 400
    return None


def save_dir_from_request(value):
    rel = str(value or '').strip().strip('/')
    if not rel:
        return user_primary_dir() if not is_admin() else DOWNLOADS
    target = safe_path(rel)
    if target.exists() and not target.is_dir():
        raise ValueError('保存位置不是文件夹')
    target.mkdir(parents=True, exist_ok=True)
    return target


def safe_upload_name(filename):
    name = Path(str(filename or '').replace('\\', '/')).name.strip()
    if not name or name in {'.', '..'} or '..' in Path(name).parts or '/' in name or '\\' in name:
        raise ValueError('文件名不合法')
    return name


def unique_upload_path(folder, filename):
    target = (folder / filename).resolve()
    if not path_is_allowed(target):
        raise ValueError('没有权限保存到这个目录')
    if not target.exists():
        return target
    stem = target.stem
    suffix = target.suffix
    for i in range(1, 1000):
        candidate = (folder / f'{stem} ({i}){suffix}').resolve()
        if path_is_allowed(candidate) and not candidate.exists():
            return candidate
    raise ValueError('同名文件太多，请换个文件名')


def list_allowed_dirs():
    roots = user_allowed_roots()
    start_dirs = [DOWNLOADS] if is_admin() or '*' in roots else [(DOWNLOADS / r) for r in roots]
    out = []
    seen = set()
    for root in start_dirs:
        try:
            root.mkdir(parents=True, exist_ok=True)
            base = root.resolve()
        except Exception:
            continue
        stack = [base]
        while stack and len(out) < 500:
            cur = stack.pop(0)
            try:
                rel = '' if cur == DOWNLOADS.resolve() else str(cur.relative_to(DOWNLOADS.resolve()))
            except Exception:
                continue
            if rel not in seen and path_is_allowed(cur):
                seen.add(rel)
                label = '/' + rel if rel else '/'
                out.append({'path': rel, 'label': label})
            try:
                children = sorted([x for x in cur.iterdir() if x.is_dir()], key=lambda x: x.name.lower())
            except Exception:
                children = []
            stack.extend(children)
    return out


def aria(method, params=None):
    payload = {'jsonrpc': '2.0', 'id': str(uuid.uuid4()), 'method': method, 'params': ['token:' + ARIA_SECRET] + (params or [])}
    r = requests.post(ARIA_RPC, json=payload, timeout=8)
    r.raise_for_status()
    data = r.json()
    if 'error' in data:
        raise RuntimeError(data['error'].get('message', 'aria2 调用失败'))
    return data.get('result')


def fmt_bytes(n):
    try:
        n = float(n)
    except Exception:
        return '0 B'
    for u in ['B', 'KB', 'MB', 'GB', 'TB']:
        if n < 1024:
            return f'{n:.1f} {u}' if u != 'B' else f'{int(n)} B'
        n /= 1024
    return f'{n:.1f} PB'


def read_hls_jobs():
    try:
        return json.loads(HLS_JOBS.read_text(encoding='utf-8'))
    except Exception:
        return []


def write_hls_jobs(jobs):
    HLS_JOBS.write_text(json.dumps(jobs, ensure_ascii=False, indent=2), encoding='utf-8')


def read_trash():
    try:
        return json.loads(TRASH_META.read_text(encoding='utf-8'))
    except Exception:
        return []


def write_trash(items):
    TRASH_META.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding='utf-8')


def ytdlp_cookie_path(username=None):
    username = username or current_user() or 'admin'
    safe = re.sub(r'[^A-Za-z0-9_.-]+', '_', str(username))[:80] or 'user'
    return YTDLP_COOKIES_DIR / f'{safe}.txt'


def ytdlp_version():
    try:
        result = subprocess.run(['python3', '-m', 'yt_dlp', '--version'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, errors='ignore', timeout=8)
    except Exception as e:
        return '', str(e)
    version = (result.stdout or '').strip().splitlines()
    if result.returncode == 0 and version:
        return version[-1].strip(), ''
    return '', ((result.stderr or result.stdout or '').strip() or f'视频下载固件退出码 {result.returncode}')


def trash_item_path(item):
    return (TRASH / item.get('stored_name', '')).resolve()


def move_to_trash(path):
    path = Path(path).resolve()
    if path == DOWNLOADS.resolve():
        raise ValueError('不能删除根目录')
    if not path.exists():
        return None
    if not path_is_allowed(path):
        raise ValueError('路径非法或没有访问权限')
    item_id = uuid.uuid4().hex
    stored_name = item_id + '_' + path.name
    target = (TRASH / stored_name).resolve()
    rel = str(path.relative_to(DOWNLOADS.resolve()))
    item = {
        'id': item_id,
        'stored_name': stored_name,
        'name': path.name,
        'path': rel,
        'dir': path.is_dir(),
        'size': directory_size(path),
        'user': current_user() or 'admin',
        'deleted_at': time.time(),
    }
    shutil.move(str(path), str(target))
    items = read_trash()
    items.append(item)
    write_trash(items)
    return item


def update_hls(job_id, **fields):
    jobs = read_hls_jobs()
    for j in jobs:
        if j['id'] == job_id:
            j.update(fields)
            break
    write_hls_jobs(jobs)


def hls_job_status(job_id):
    for j in read_hls_jobs():
        if j.get('id') == job_id:
            return j.get('status', '')
    return ''


def hls_worker(job_id, url, filename, out_dir):
    out = Path(out_dir) / filename
    cmd = ['ffmpeg', '-y', '-protocol_whitelist', 'file,http,https,tcp,tls,crypto', '-i', url, '-c', 'copy', str(out)]
    start = time.time()
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, errors='ignore')
    update_hls(job_id, pid=proc.pid, status='active', message='正在下载', started_at=start)
    last = ''
    speed = ''
    for line in proc.stderr:
        last = line.strip()[-180:]
        m = re.search(r'speed=\s*([^\s]+)', line)
        if m:
            speed = m.group(1)
        size = out.stat().st_size if out.exists() else 0
        if hls_job_status(job_id) == 'paused':
            update_hls(job_id, size=size, speed='0 B/s', message='已暂停', elapsed=int(time.time() - start))
        else:
            update_hls(job_id, status='active', size=size, speed=speed, message=last, elapsed=int(time.time() - start))
    code = proc.wait()
    size = out.stat().st_size if out.exists() else 0
    update_hls(job_id, status='complete' if code == 0 else 'error', size=size, speed='', message='下载完成' if code == 0 else f'下载失败，退出码 {code}', elapsed=int(time.time() - start))


def ytdlp_format(quality):
    if quality == '1080p':
        return 'bestvideo*[height<=1080]+bestaudio/best[height<=1080]/best'
    if quality == '720p':
        return 'bestvideo*[height<=720]+bestaudio/best[height<=720]/best'
    if quality == 'audio':
        return 'bestaudio/best'
    return 'bestvideo*+bestaudio/best'


def ytdlp_site_options(url):
    host = url.lower()
    if 'pornhub.com' in host:
        return [
            '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            '--referer', 'https://www.pornhub.com/',
            '--add-header', 'Accept-Language:en-US,en;q=0.9',
        ]
    return []


def ytdlp_friendly_error(url, message):
    if 'pornhub.com' in url.lower() and 'Unable to extract title' in message:
        return (
            message + '。服务器当前拿到的可能不是正常视频页，而是首页/年龄确认/地区限制/反爬页面，'
            '所以视频下载组件无法提取标题。可以尝试上传该站点真实 cookies，或更换服务器 IP/代理后再试。'
        )
    return message


def ytdlp_base_cmd(out_dir, quality):
    return [
        'python3', '-m', 'yt_dlp',
        '--no-check-certificate',
        '--no-playlist',
        '--newline',
        '--paths', str(out_dir),
        '--output', '%(title).200B.%(ext)s',
        '--format', ytdlp_format(quality),
        '--ffmpeg-location', '/usr/bin/ffmpeg',
        '--js-runtimes', 'node:/usr/bin/node',
        '--remote-components', 'ejs:github',
    ]


def video_worker(job_id, url, quality, out_dir, owner):
    out_dir = Path(out_dir)
    start = time.time()
    before = {p.resolve() for p in out_dir.iterdir()} if out_dir.exists() else set()
    info_json = None
    cmd = ytdlp_base_cmd(out_dir, quality)
    cmd += ytdlp_site_options(url)
    cookie_file = ytdlp_cookie_path(owner)
    if cookie_file.exists() and cookie_file.stat().st_size > 0:
        cmd += ['--cookies', str(cookie_file)]
    proxy_enabled, proxy_url, proxy_mode = video_proxy_config(owner)
    if proxy_enabled:
        if proxy_mode == 'full':
            cmd += ['--proxy', proxy_url]
        else:
            info_json = TMP / f'ytdlp-info-{job_id}.info.json'
            info_base = f'ytdlp-info-{job_id}'
            extract_cmd = [
                'python3', '-m', 'yt_dlp',
                '--no-check-certificate',
                '--no-playlist',
                '--newline',
                '--skip-download',
                '--write-info-json',
                '--paths', 'infojson:' + str(TMP),
                '--output', 'infojson:' + info_base,
                '--format', ytdlp_format(quality),
                '--ffmpeg-location', '/usr/bin/ffmpeg',
                '--js-runtimes', 'node:/usr/bin/node',
                '--remote-components', 'ejs:github',
            ]
            extract_cmd += ytdlp_site_options(url)
            if cookie_file.exists() and cookie_file.stat().st_size > 0:
                extract_cmd += ['--cookies', str(cookie_file)]
            extract_cmd += ['--proxy', proxy_url, url]
            update_hls(job_id, status='active', message='正在通过代理解析真实下载链接', started_at=start)
            extract = subprocess.run(extract_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors='ignore')
            if not info_json.exists():
                candidates = sorted(TMP.glob(info_base + '*.info.json'), key=lambda p: p.stat().st_mtime, reverse=True)
                if candidates:
                    info_json = candidates[0]
            if extract.returncode != 0 or not info_json.exists():
                msg = (extract.stdout or '').strip().splitlines()
                last = msg[-1][-240:] if msg else '解析失败'
                update_hls(job_id, status='error', message=ytdlp_friendly_error(url, f'视频解析失败，退出码 {extract.returncode}：{last}'), speed='', elapsed=int(time.time() - start))
                return
            cmd += ['--load-info-json', str(info_json)]
    if quality == 'audio':
        cmd += ['--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0']
    if not (proxy_enabled and proxy_mode == 'geo'):
        cmd.append(url)
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors='ignore')
    except Exception as e:
        update_hls(job_id, status='error', message=f'启动视频下载组件失败：{e}')
        return
    update_hls(job_id, pid=proc.pid, status='active', message='正在解析视频链接', started_at=start)
    progress = 0
    speed = ''
    eta = ''
    final_path = None
    last_message = ''
    for line in proc.stdout:
        text = line.strip()
        if not text:
            continue
        last_message = text[-240:]
        m = re.search(r'\[download\]\s+(\d+(?:\.\d+)?)%', text)
        if m:
            progress = float(m.group(1))
        m = re.search(r'\bat\s+([^\s]+/s)', text)
        if m:
            speed = m.group(1)
        m = re.search(r'\bETA\s+([^\s]+)', text)
        if m:
            eta = m.group(1)
        m = re.search(r'(?:Destination|ExtractAudio\] Destination):\s+"?([^"]+)"?', text) or re.search(r'Merging formats into\s+"([^"]+)"', text)
        if m:
            candidate = Path(m.group(1)).expanduser()
            if candidate.exists():
                final_path = candidate.resolve()
        size = final_path.stat().st_size if final_path and final_path.exists() else 0
        message = text[-180:]
        if eta:
            message = f'{message} ETA {eta}'
        if hls_job_status(job_id) == 'paused':
            update_hls(job_id, speed='0 B/s', size=size, message='已暂停', elapsed=int(time.time() - start))
        else:
            update_hls(job_id, status='active', progress=progress, speed=speed, size=size, message=message, elapsed=int(time.time() - start))
    code = proc.wait()
    if not final_path:
        created = [p for p in out_dir.iterdir() if p.resolve() not in before and p.is_file()] if out_dir.exists() else []
        if created:
            final_path = max(created, key=lambda p: p.stat().st_mtime).resolve()
    size = final_path.stat().st_size if final_path and final_path.exists() else 0
    rel = ''
    if final_path and final_path.exists():
        try:
            rel = str(final_path.relative_to(DOWNLOADS.resolve()))
        except Exception:
            rel = ''
    error_message = f'视频下载失败，退出码 {code}'
    if last_message:
        error_message += f'：{last_message}'
    error_message = ytdlp_friendly_error(url, error_message)
    if info_json:
        try:
            info_json.unlink(missing_ok=True)
        except Exception:
            pass
    update_hls(job_id, status='complete' if code == 0 else 'error', progress=100 if code == 0 else progress, size=size, speed='', message='视频下载完成' if code == 0 else error_message, path=rel)


def transcode_worker(job_id, rel):
    try:
        src = safe_path(rel)
        stem = src.stem
        out = src.with_name(stem + '.mobile.mp4')
        idx = 1
        while out.exists():
            out = src.with_name(f'{stem}.mobile-{idx}.mp4')
            idx += 1
        cmd = [
            'ffmpeg', '-y', '-i', str(src),
            '-map', '0:v:0?', '-map', '0:a:0?',
            '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23',
            '-pix_fmt', 'yuv420p', '-profile:v', 'main', '-level', '4.0',
            '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart',
            str(out)
        ]
        start = time.time()
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, errors='ignore')
        update_hls(job_id, pid=proc.pid, status='active', message='正在转为手机兼容 MP4', started_at=start)
        last = ''
        speed = ''
        for line in proc.stderr:
            last = line.strip()[-180:]
            m = re.search(r'speed=\s*([^\s]+)', line)
            if m:
                speed = m.group(1)
            size = out.stat().st_size if out.exists() else 0
            update_hls(job_id, size=size, speed=speed, message=last or '正在转码', elapsed=int(time.time() - start))
        code = proc.wait()
        size = out.stat().st_size if out.exists() else 0
        update_hls(job_id, status='complete' if code == 0 else 'error', size=size, speed='', message='转码完成，请在文件管理里播放 .mobile.mp4' if code == 0 else f'转码失败，退出码 {code}', elapsed=int(time.time() - start))
    except Exception as e:
        update_hls(job_id, status='error', message=str(e), speed='')


def load_tracker_meta():
    try:
        return json.loads(TRACKER_META.read_text(encoding='utf-8'))
    except Exception:
        return {'url': 'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_all.txt', 'updated_at': '', 'count': 0}


def save_tracker_meta(meta):
    TRACKER_META.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')


def read_task_sources():
    try:
        data = json.loads(TASK_SOURCES.read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def write_task_sources(data):
    TASK_SOURCES.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def task_source_record(task):
    record = read_task_sources().get(str(task.get('gid') or ''))
    if isinstance(record, dict):
        return record
    if isinstance(record, str):
        return {'url': record, 'remark': ''}
    return {}


def remember_task_source(gid, url, remark=''):
    if not gid or not url:
        return
    data = read_task_sources()
    data[str(gid)] = {'url': str(url), 'remark': str(remark or '').strip()}
    write_task_sources(data)


def magnet_from_task(task):
    bt = task.get('bittorrent') or {}
    info_hash = (bt.get('infoHash') or task.get('infoHash') or '').strip()
    if not info_hash:
        return ''
    name = ((bt.get('info') or {}).get('name') or '').strip()
    magnet = f'magnet:?xt=urn:btih:{info_hash}'
    if name:
        from urllib.parse import quote
        magnet += '&dn=' + quote(name)
    return magnet


def task_source_url(task):
    remembered = task_source_record(task).get('url')
    if remembered:
        return remembered
    for f in task.get('files') or []:
        for item in f.get('uris') or []:
            uri = (item.get('uri') or '').strip()
            if uri:
                return uri
    return magnet_from_task(task)


def task_remark(task):
    return task_source_record(task).get('remark', '')


def task_bt_stats(task):
    bt = task.get('bittorrent') or {}
    seeders = bt.get('numSeeders')
    if seeders in (None, ''):
        seeders = task.get('numSeeders')
    try:
        seeders = int(seeders)
    except Exception:
        seeders = 0
    try:
        connections = int(task.get('connections') or 0)
    except Exception:
        connections = 0
    return seeders, connections


def eta_label(total, done, speed):
    try:
        total = int(total or 0)
        done = int(done or 0)
        speed = int(speed or 0)
    except Exception:
        return '--'
    if total <= 0:
        return '未知'
    if done >= total:
        return '已完成'
    if speed <= 0:
        return '--'
    seconds = max(0, int((total - done) / speed))
    if seconds < 60:
        return f'{seconds}秒'
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f'{minutes}分{sec:02d}秒'
    hours, minutes = divmod(minutes, 60)
    if hours < 24:
        return f'{hours}小时{minutes:02d}分'
    days, hours = divmod(hours, 24)
    return f'{days}天{hours:02d}小时'


def cleanup_task_sources(live_gids):
    data = read_task_sources()
    keep = {str(gid) for gid in live_gids}
    cleaned = {gid: url for gid, url in data.items() if gid in keep}
    if cleaned != data:
        write_task_sources(cleaned)


def current_bt_tracker_count():
    try:
        for line in ARIA_CONF.read_text(encoding='utf-8').splitlines():
            if line.startswith('bt-tracker='):
                value = line.split('=', 1)[1].strip()
                return 0 if not value else len([x for x in value.split(',') if x.strip()])
    except Exception:
        pass
    return 0


def update_trackers_from_url(url):
    if not (url.startswith('https://') or url.startswith('http://')) or not url.lower().split('?', 1)[0].endswith('.txt'):
        raise ValueError('请输入 http(s) 的 .txt tracker 列表地址')
    r = requests.get(url, timeout=25)
    r.raise_for_status()
    trackers = [line.strip() for line in r.text.splitlines() if line.strip() and not line.strip().startswith('#')]
    trackers = list(dict.fromkeys(trackers))
    if len(trackers) < 1:
        raise ValueError('这个地址没有读取到 tracker')
    text = ARIA_CONF.read_text(encoding='utf-8')
    line = 'bt-tracker=' + ','.join(trackers)
    if re.search(r'^bt-tracker=.*$', text, flags=re.M):
        text = re.sub(r'^bt-tracker=.*$', line, text, flags=re.M)
    else:
        text = text.rstrip() + '\n' + line + '\n'
    ARIA_CONF.write_text(text, encoding='utf-8')
    try:
        aria('aria2.changeGlobalOption', [{'bt-tracker': ','.join(trackers)}])
    except Exception as e:
        print(f'[tracker] changeGlobalOption failed: {e}', flush=True)
    meta = {'url': url, 'updated_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'count': len(trackers)}
    save_tracker_meta(meta)
    return meta


def read_update_status():
    try:
        data = json.loads(UPDATE_STATUS.read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {'running': False, 'message': '暂无更新任务', 'updated_at': ''}


def write_update_status(**fields):
    data = read_update_status()
    data.update(fields)
    data['updated_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
    UPDATE_STATUS.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def validate_update_archive(archive_path):
    required = {
        'offline-downloader-docker/app/app.py',
        'offline-downloader-docker/Dockerfile',
        'offline-downloader-docker/docker-compose.yml',
        'offline-downloader-docker/docker/entrypoint.sh',
        'offline-downloader-docker/docker/updater.sh',
    }
    found = set()
    forbidden_parts = {'data', 'downloads', '.env'}
    with tarfile.open(archive_path, 'r:*') as tf:
        for member in tf.getmembers():
            name = member.name.strip('/')
            parts = Path(name).parts
            if not parts:
                continue
            # macOS tar may include AppleDouble metadata files such as ._Dockerfile.
            if any(part.startswith('._') for part in parts):
                continue
            if member.name.startswith('/') or '..' in parts:
                raise ValueError('更新包包含非法路径')
            if parts[0] == 'offline-downloader-docker':
                check_parts = parts[1:]
                normalized = name
            else:
                check_parts = parts
                normalized = 'offline-downloader-docker/' + name
            if any(part in forbidden_parts for part in check_parts):
                raise ValueError('更新包不能包含 data、downloads 或 .env')
            if normalized in required:
                found.add(normalized)
    missing = sorted(required - found)
    if missing:
        raise ValueError('更新包缺少必要文件：' + ', '.join(missing))


def apply_update_archive(archive_path):
    staging = None
    try:
        write_update_status(running=True, message='正在校验更新包')
        validate_update_archive(archive_path)
        staging = TMP / f'update-{uuid.uuid4().hex}'
        staging.mkdir(parents=True, exist_ok=True)
        write_update_status(running=True, message='正在解压更新包')
        with tarfile.open(archive_path, 'r:*') as tf:
            tf.extractall(staging)
        src = staging / 'offline-downloader-docker'
        if not src.exists():
            src = staging
        if not (src / 'app' / 'app.py').exists() or not (src / 'Dockerfile').exists():
            raise ValueError('更新包目录不存在或结构不正确')
        if not HOST_PROJECT_DIR.exists():
            raise RuntimeError('宿主机项目目录未挂载，无法自动更新')
        write_update_status(running=True, message='正在覆盖程序文件')
        pack = subprocess.Popen(['tar', '--exclude=./data', '--exclude=./downloads', '--exclude=./.env', '-C', str(src), '-cf', '-', '.'], stdout=subprocess.PIPE)
        unpack = subprocess.run(['tar', '-C', str(HOST_PROJECT_DIR), '-xf', '-'], stdin=pack.stdout, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if pack.stdout:
            pack.stdout.close()
        code = pack.wait()
        if code != 0 or unpack.returncode != 0:
            raise RuntimeError(unpack.stderr or '覆盖程序文件失败')
        request_data = {
            'id': uuid.uuid4().hex,
            'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
            'project_dir': str(HOST_PROJECT_DIR),
        }
        tmp_request = UPDATE_REQUEST.with_suffix('.json.tmp')
        tmp_request.write_text(json.dumps(request_data, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp_request.replace(UPDATE_REQUEST)
        write_update_status(running=True, message='更新文件已覆盖，正在等待更新助手重建容器')
    except Exception as e:
        write_update_status(running=False, message='更新失败：' + str(e))
    finally:
        try:
            Path(archive_path).unlink(missing_ok=True)
        except Exception:
            pass
        try:
            if staging:
                shutil.rmtree(staging, ignore_errors=True)
        except Exception:
            pass


HTML = r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>离线下载中心</title>
<style>
:root{--bg:#f6f7f9;--panel:#fff;--text:#18202a;--muted:#667085;--line:#d8dde5;--brand:#0f766e;--brand2:#164e63;--danger:#b42318;--ok:#067647;--warn:#b54708;--shadow:0 8px 24px rgba(15,23,42,.08)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.login{min-height:100vh;display:grid;place-items:center;padding:24px}.loginbox{width:min(420px,100%);background:var(--panel);border:1px solid var(--line);border-radius:8px;box-shadow:var(--shadow);padding:28px}.loginbox h1{margin:0 0 8px;font-size:24px}.loginbox p{margin:0 0 20px;color:var(--muted)}
.top{height:58px;background:#101820;color:white;display:flex;align-items:center;justify-content:space-between;padding:0 22px}.brand{font-weight:700;font-size:18px}.app-shell{display:grid;grid-template-columns:190px minmax(0,1fr);max-width:1440px;margin:0 auto}.side{padding:22px 0 22px 22px}.nav{position:sticky;top:18px;display:grid;gap:8px}.nav .btn{width:100%;text-align:left;background:white;color:#344054;border:1px solid var(--line);box-shadow:none}.nav .btn.active{background:#0f766e;color:white;border-color:#0f766e}.wrap{max-width:1240px;width:100%;padding:22px}.page{display:none}.page.active{display:block}.grid{display:grid;grid-template-columns:360px 1fr;gap:18px}.panel{background:var(--panel);border:1px solid var(--line);border-radius:8px;box-shadow:var(--shadow);transition:box-shadow .18s ease,transform .18s ease}.panel h2{font-size:16px;margin:0;padding:16px 18px;border-bottom:1px solid var(--line)}.body{padding:16px 18px}label{display:block;color:#344054;font-weight:600;margin:12px 0 6px}input,select,textarea{width:100%;border:1px solid #c9d1dc;border-radius:6px;padding:10px 11px;background:white;color:var(--text);font:inherit;transition:border-color .16s ease,box-shadow .16s ease}input:focus,select:focus,textarea:focus{outline:0;border-color:#0f766e;box-shadow:0 0 0 3px rgba(15,118,110,.14)}textarea{min-height:96px;resize:vertical}.row{display:flex;gap:10px;align-items:center}.row>*{flex:1}.btn{position:relative;overflow:hidden;border:0;border-radius:6px;padding:10px 13px;background:var(--brand);color:white;font-weight:700;cursor:pointer;transform:translateY(0);transition:transform .12s ease,box-shadow .16s ease,filter .16s ease,background-color .16s ease;box-shadow:0 2px 0 rgba(15,23,42,.12)}.btn:hover{filter:brightness(1.04);box-shadow:0 6px 14px rgba(15,23,42,.12)}.btn:active,.btn.pressed{transform:translateY(1px) scale(.985);box-shadow:0 1px 0 rgba(15,23,42,.15)}.btn.secondary{background:#344054}.btn.danger{background:var(--danger)}.btn.light{background:#eef4f3;color:#0f514b;border:1px solid #bdd7d3}.btn:disabled{opacity:.65;cursor:not-allowed;filter:none}.btn.loading{color:transparent;pointer-events:none}.btn.loading:after,.loading-dot:after{content:"";position:absolute;inset:0;margin:auto;width:16px;height:16px;border-radius:50%;border:2px solid currentColor;border-right-color:transparent;animation:spin .7s linear infinite}.btn.loading:after{color:white}.btn.light.loading:after{color:#0f514b}.ripple{position:absolute;border-radius:999px;transform:scale(0);background:rgba(255,255,255,.36);animation:ripple .48s ease-out;pointer-events:none}.btn.light .ripple{background:rgba(15,118,110,.18)}.tabs{display:flex;gap:8px;margin-bottom:12px}.tab{padding:8px 10px;border:1px solid var(--line);border-radius:6px;background:white;cursor:pointer;transition:transform .12s ease,background-color .16s ease,border-color .16s ease}.tab:active{transform:translateY(1px) scale(.985)}.tab.active{background:#dff3ef;border-color:#8fcac0;color:#0f514b;font-weight:700}.hint{color:var(--muted);font-size:12px;margin-top:8px}.stats{display:grid;grid-template-columns:repeat(7,1fr);gap:12px;margin-bottom:18px}.stat{background:white;border:1px solid var(--line);border-radius:8px;padding:14px;box-shadow:var(--shadow);transition:transform .18s ease,box-shadow .18s ease}.stat:hover{transform:translateY(-1px);box-shadow:0 10px 24px rgba(15,23,42,.1)}.stat b{display:block;font-size:20px}.stat span{color:var(--muted)}
.task{border-bottom:1px solid var(--line);padding:14px 0}.task:last-child{border-bottom:0}.task-head{display:flex;justify-content:space-between;gap:12px}.name{font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.badge{font-size:12px;border-radius:999px;padding:3px 8px;background:#eef2f6;color:#344054}.badge.active{background:#e0f2fe;color:#075985}.badge.complete{background:#dcfae6;color:#067647}.badge.error{background:#fee4e2;color:#b42318}.meta{color:var(--muted);font-size:12px;margin-top:5px}.bar{height:8px;background:#eef2f6;border-radius:999px;overflow:hidden;margin-top:9px}.bar>i{display:block;height:100%;background:linear-gradient(90deg,var(--brand),var(--brand2));width:0;transition:width .28s ease}.actions{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}.actions a{display:inline-flex;text-decoration:none}.files{width:100%;border-collapse:collapse}.files th,.files td{border-bottom:1px solid var(--line);padding:10px;text-align:left}.files th{color:var(--muted);font-size:12px}.files tr{transition:background-color .14s ease}.files tbody tr:hover{background:#f8fafb}.files a{color:#075985;text-decoration:none}.viewer{margin-top:14px}.viewer video,.viewer audio{width:100%;max-height:520px;background:#000;border-radius:8px}.toast{position:fixed;right:18px;bottom:18px;background:#101820;color:white;padding:11px 14px;border-radius:6px;box-shadow:var(--shadow);display:none;animation:toastIn .18s ease}.toolbar{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:12px}.path{color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.settings{display:flex;gap:8px;align-items:center}.settings input{width:130px;padding:7px 8px}.settings select{width:auto;min-width:96px;padding:7px 8px}
@media(max-width:900px){.app-shell{grid-template-columns:1fr}.side{padding:12px}.nav{position:static;grid-template-columns:1fr 1fr}.grid{grid-template-columns:1fr}.stats{grid-template-columns:1fr}.top{height:auto;gap:10px;align-items:flex-start;flex-direction:column;padding:14px 16px}.wrap{padding:14px}.task-head{display:block}.settings{flex-wrap:wrap}}

.stats-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px}.section-title{font-weight:800;font-size:16px}.panel-head{display:flex;align-items:center;justify-content:space-between;gap:12px;border-bottom:1px solid var(--line);padding-right:18px}.panel-head h2{border-bottom:0;flex:1}.panel-head .btn{white-space:nowrap}.files-wrap{width:100%;overflow-x:auto}.files{min-width:720px}.files td:last-child,.files th:last-child{min-width:230px}.files .btn{margin:2px 3px 2px 0;white-space:nowrap}.task{overflow:hidden}.task .actions .btn{min-height:38px}
@media(max-width:900px){body{font-size:13px}.top{height:auto;gap:12px;align-items:stretch;flex-direction:column;padding:14px}.brand{font-size:17px}.settings{display:grid;grid-template-columns:1fr 1fr;gap:8px}.settings input{width:100%;min-width:0}.settings .btn{width:100%;padding:9px 8px}.wrap{padding:12px}.stats-head{margin-top:2px}.stats{grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.stat{padding:10px 8px}.stat b{font-size:16px;white-space:nowrap}.stat span{font-size:12px}.grid{grid-template-columns:1fr;gap:12px}.panel h2{padding:12px 14px}.body{padding:12px}.tabs{gap:6px}.tab,.btn,input,select,textarea{font-size:13px}.btn{padding:9px 10px}.task-head{display:flex;align-items:flex-start}.name{white-space:normal;line-height:1.35}.actions{display:grid;grid-template-columns:1fr 1fr;gap:8px}.actions .btn{width:100%}.toolbar{align-items:flex-start}.path{white-space:normal;word-break:break-all}.viewer video,.viewer audio{max-height:52vh}.files-wrap{margin:0 -12px;padding:0 12px}.files{min-width:680px}.toast{left:12px;right:12px;bottom:12px;text-align:center}}
@media(max-width:430px){.stats{grid-template-columns:1fr}.settings{grid-template-columns:1fr}.actions{grid-template-columns:1fr}.files{min-width:620px}}


.tracker-grid{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:end}.download-settings-grid{display:grid;grid-template-columns:150px 120px 150px auto;gap:12px;align-items:end}.proxy-fields-grid{display:grid;grid-template-columns:120px minmax(180px,1fr) 110px minmax(150px,1fr) minmax(150px,1fr);gap:12px;align-items:end;margin-top:12px}.download-settings-grid select,.proxy-fields-grid select{min-width:0}.download-settings-grid input,.proxy-fields-grid input{min-width:0}.tracker-actions{padding-bottom:0}.tracker-meta{display:flex;gap:16px;flex-wrap:wrap;color:var(--muted);font-size:12px;margin-top:10px}.tracker-meta b{color:var(--text);font-weight:700}.tracker-panel input{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px}.changelog{margin-top:14px;border-top:1px solid var(--line);padding-top:10px}.changelog-head{display:flex;align-items:center;justify-content:space-between;gap:10px}.changelog-head .btn{padding:7px 10px}.changelog-item{padding:10px 0;border-bottom:1px solid var(--line)}.changelog-item:last-child{border-bottom:0}.changelog-title{font-weight:800;margin-bottom:5px}.changelog ul{margin:0;padding-left:20px;color:#344054}.changelog li{margin:3px 0}
@media(max-width:900px){.tracker-grid,.download-settings-grid,.proxy-fields-grid{grid-template-columns:1fr}.tracker-actions .btn{width:100%}.tracker-meta{display:grid;gap:6px}}


.user-add{display:grid;grid-template-columns:1fr 1fr 140px 120px 150px 1fr 120px auto;gap:10px;align-items:center}.users-table{width:100%;border-collapse:collapse;margin-top:12px}.users-table th,.users-table td{border-bottom:1px solid var(--line);padding:9px;text-align:left;vertical-align:top}.users-table th{font-size:12px;color:var(--muted)}.users-table .btn{margin:2px}.user-list-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:16px}.pager{display:flex;gap:8px;align-items:center;justify-content:flex-end;margin-top:12px;flex-wrap:wrap}.pager .btn{padding:7px 10px}.role-pill{display:inline-block;border-radius:999px;padding:3px 8px;background:#eef2f6;color:#344054;font-size:12px}.role-pill.admin{background:#dcfae6;color:#067647}.device-list{display:grid;gap:6px;min-width:260px}.device-item{border:1px solid var(--line);border-radius:6px;padding:7px 8px;background:#fbfcfd}.device-top{display:flex;align-items:center;justify-content:space-between;gap:8px}.device-ip{font-weight:700}.device-current{font-size:12px;color:#067647;background:#dcfae6;border-radius:999px;padding:2px 7px;white-space:nowrap}.device-meta{font-size:12px;color:var(--muted);word-break:break-all;margin-top:3px}.device-item .btn{padding:6px 8px;font-size:12px;margin-top:6px}.folder-tools{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.folder-tools input{max-width:220px}.file-search{display:grid;grid-template-columns:minmax(180px,1fr) auto auto;gap:8px;align-items:center;margin:10px 0 12px}.save-row{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:end}@media(max-width:900px){.user-add{grid-template-columns:1fr}.users-box{overflow-x:auto}.users-table{min-width:980px}.file-search{grid-template-columns:1fr}.file-search .btn{width:100%}}
.disclaimer-list{margin:12px 0 0;padding-left:20px;color:#344054}.disclaimer-list li{margin:8px 0}.checkline{display:flex;gap:8px;align-items:flex-start;margin-top:16px;color:#344054}.checkline input{width:auto;margin-top:4px}.loginbox .btn[disabled]{opacity:.5}
.loading-line{position:relative;min-height:34px}.loading-line:before{content:"";display:inline-block;width:16px;height:16px;margin-right:8px;vertical-align:-3px;border-radius:50%;border:2px solid #98a2b3;border-right-color:transparent;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}@keyframes ripple{to{transform:scale(4);opacity:0}}@keyframes fadeSlide{from{opacity:.3;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}@keyframes toastIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}

</style>
</head>
<body data-lang="{{ lang }}">
{% if not authed %}
<div class="login"><form id="loginForm" class="loginbox" method="post" action="/login" {% if register_error %}style="display:none"{% endif %}><select id="publicLang" onchange="setPublicLang(this.value)" style="margin-bottom:12px"><option value="zh">中文</option><option value="en">English</option></select><h1 data-public-i18n="loginTitle">离线下载中心 {{ version }}</h1><p data-public-i18n="loginSubtitle">支持 BT / 磁力 / 种子 / M3U8 / HTTP / FTP</p><label data-public-i18n="username">账户</label><input name="username" autofocus required><label data-public-i18n="password">密码</label><input name="password" type="password" required>{% if error %}<p style="color:#b42318;margin:10px 0 0">{{ error }}</p>{% endif %}<button class="btn" style="width:100%;margin-top:18px" data-public-i18n="loginButton">登录</button>{% if registration_enabled %}<button class="btn light" type="button" style="width:100%;margin-top:10px" onclick="showRegister()" data-public-i18n="registerAccount">注册账号</button>{% endif %}</form>{% if registration_enabled %}<form id="registerForm" class="loginbox" method="post" action="/register" {% if not register_error %}style="display:none"{% endif %}><select id="registerLang" name="language" onchange="setPublicLang(this.value)" style="margin-bottom:12px"><option value="zh">中文</option><option value="en">English</option></select><h1 data-public-i18n="registerTitle">注册账号</h1><p data-public-i18n="registerSubtitle">请输入账户密码，并完成验证码验证。</p><label data-public-i18n="username">账户</label><input name="username" required><label data-public-i18n="password">密码</label><input name="password" type="password" required><label data-public-i18n="confirmPassword">确认密码</label><input name="confirm" type="password" required><label><span data-public-i18n="captcha">验证码</span>：{{ captcha_text }}</label><input name="captcha" inputmode="numeric" autocomplete="off" required>{% if register_error %}<p style="color:#b42318;margin:10px 0 0">{{ register_error }}</p>{% endif %}<button class="btn" style="width:100%;margin-top:18px" data-public-i18n="registerButton">注册</button><button class="btn light" type="button" style="width:100%;margin-top:10px" onclick="showLogin()" data-public-i18n="backToLogin">返回登录</button></form>{% endif %}<script>const PUBLIC_I18N={zh:{loginTitle:'离线下载中心 {{ version }}',loginSubtitle:'支持 BT / 磁力 / 种子 / M3U8 / HTTP / FTP',username:'账户',password:'密码',loginButton:'登录',registerAccount:'注册账号',registerTitle:'注册账号',registerSubtitle:'请输入账户密码，并完成验证码验证。',confirmPassword:'确认密码',captcha:'验证码',registerButton:'注册',backToLogin:'返回登录'},en:{loginTitle:'Offline Downloader {{ version }}',loginSubtitle:'Supports BT / Magnet / Torrent / M3U8 / HTTP / FTP',username:'Username',password:'Password',loginButton:'Login',registerAccount:'Register',registerTitle:'Register account',registerSubtitle:'Enter your account and password, then complete captcha verification.',confirmPassword:'Confirm password',captcha:'Captcha',registerButton:'Register',backToLogin:'Back to login'}};function setPublicLang(lang){lang=lang==='en'?'en':'zh';document.querySelectorAll('#publicLang,#registerLang').forEach(x=>x.value=lang);document.querySelectorAll('[data-public-i18n]').forEach(el=>{el.textContent=(PUBLIC_I18N[lang]&&PUBLIC_I18N[lang][el.dataset.publicI18n])||el.textContent});document.documentElement.lang=lang==='en'?'en':'zh-CN'}function showRegister(){document.getElementById('loginForm').style.display='none';document.getElementById('registerForm').style.display='block'}function showLogin(){document.getElementById('registerForm').style.display='none';document.getElementById('loginForm').style.display='block'}setPublicLang('{{ lang }}')</script></div>
{% elif needs_disclaimer %}
<div class="login"><div class="loginbox"><h1>使用声明</h1><p>请在继续使用前确认你理解并同意以下内容。</p><ul class="disclaimer-list"><li>本工具仅用于下载、管理你拥有权利或已获得授权的文件内容。</li><li>请遵守你所在地法律法规、服务商规则以及版权相关规定。</li><li>使用者应自行承担因下载、传播、保存内容产生的全部责任。</li><li>作者和部署者不对使用者的具体下载内容、用途、后果承担责任。</li></ul><label class="checkline"><input id="agreeDisclaimer" type="checkbox" onchange="qs('#agreeBtn').disabled=!this.checked"><span>我已阅读并同意以上声明，只将本工具用于合法用途。</span></label><button id="agreeBtn" class="btn" style="width:100%;margin-top:18px" disabled onclick="acceptDisclaimer()">同意并进入</button><button class="btn secondary" style="width:100%;margin-top:10px" onclick="location.href='/logout'">不同意，退出登录</button></div></div><script>function qs(x){return document.querySelector(x)}async function acceptDisclaimer(){let r=await fetch('/api/disclaimer/accept',{method:'POST'});if(r.ok)location.href='/';else alert('提交失败，请重新登录')}</script>
{% else %}
<div class="top"><div class="brand"><span data-i18n="appTitle">离线下载中心</span> {{ version }}</div><div class="settings"><select id="langSelect" onchange="changeLanguage(this.value)"><option value="zh">中文</option><option value="en">English</option></select><input id="oldpass" type="password" placeholder="旧密码" data-i18n-placeholder="oldPass"><input id="newpass" type="password" placeholder="新密码" data-i18n-placeholder="newPass"><button class="btn light" onclick="changePass()" data-i18n="changePass">改密码</button><button class="btn secondary" onclick="location.href='/logout'" data-i18n="logout">退出</button></div></div>
<div class="app-shell"><aside class="side"><nav class="nav"><button id="navMain" class="btn active" onclick="showPage('main')" data-i18n="dashboard">首页</button><button id="navUsers" class="btn" style="display:none" onclick="showPage('users')" data-i18n="userManagement">用户管理</button></nav></aside><main class="wrap">
  <div class="stats-head"><div class="section-title" data-i18n="serverStatus">服务器状态</div><button class="btn light" onclick="refresh();loadFiles(currentPath)" data-i18n="refresh">刷新</button></div>
  <div class="stats"><div class="stat"><b id="free">-</b><span id="freeLabel">剩余空间</span></div><div class="stat"><b id="downspeed">-</b><span data-i18n="downloadSpeed">下载速度</span></div><div class="stat"><b id="active">-</b><span data-i18n="activeTasks">活动任务</span></div><div class="stat"><b id="speedlimit">*</b><span data-i18n="accountLimit">账号限速</span></div><div class="stat"><b id="expires">-</b><span data-i18n="accountExpiry">账户到期</span></div><div class="stat"><b id="servertime">-</b><span data-i18n="serverTime">服务器时间</span></div><div class="stat"><b id="appversion">{{ version }}</b><span data-i18n="version">版本号</span></div></div>

  <div id="mainPage" class="page active">
  <div id="downloadSettingsPanel" class="panel tracker-panel" style="margin-bottom:18px;display:none"><h2 data-i18n="downloadSettings">下载设置</h2><div class="body"><div id="ytdlpFirmwareBox" class="tracker-meta" style="display:none;margin-top:0;margin-bottom:12px"><span><span data-i18n="videoFirmwareVersion">视频下载固件版本</span>：<b id="ytdlpVersion">-</b></span><button class="btn light" onclick="loadYtdlpFirmware()" data-i18n="checkUpdate">检查更新</button><button class="btn light" onclick="updateYtdlpFirmware()" data-i18n="updateFirmware">更新</button><span id="ytdlpFirmwareStatus" class="hint"></span></div><div class="download-settings-grid"><div><label data-i18n="streamOptimize">BT 边下边播优化</label><select id="btStreamPrioritize"><option value="0" data-i18n="off">关闭</option><option value="1" data-i18n="on">开启</option></select></div><div><label data-i18n="videoProxySwitch">视频下载代理</label><select id="videoProxyEnabled"><option value="0" data-i18n="off">关闭</option><option value="1" data-i18n="on">开启</option></select></div><div><label data-i18n="videoProxyMode">代理模式</label><select id="videoProxyMode"><option value="geo" data-i18n="videoProxyGeo">只解析走代理</option><option value="full" data-i18n="videoProxyFull">全程走代理</option></select></div><div class="tracker-actions"><button class="btn" onclick="saveDownloadSettings()" data-i18n="saveSettings">保存设置</button></div></div><div class="proxy-fields-grid"><div><label data-i18n="videoProxyType">代理类型</label><select id="videoProxyType"><option value="http">HTTP</option><option value="https">HTTPS</option><option value="socks5">SOCKS5</option><option value="socks5h">SOCKS5H</option><option value="socks4">SOCKS4</option></select></div><div><label data-i18n="videoProxyHost">代理 IP/域名</label><input id="videoProxyHost" placeholder="127.0.0.1"></div><div><label data-i18n="videoProxyPort">端口</label><input id="videoProxyPort" inputmode="numeric" placeholder="7890"></div><div><label data-i18n="videoProxyUsername">账号</label><input id="videoProxyUsername" autocomplete="off" placeholder="可选"></div><div><label data-i18n="videoProxyPassword">密码</label><input id="videoProxyPassword" type="password" autocomplete="new-password" placeholder="可选"></div></div><div class="actions"><button class="btn light" onclick="testVideoProxy()" data-i18n="testProxy">测试代理连接</button><span id="proxyTestResult" class="hint"></span></div><p class="hint" data-i18n="streamOptimizeHint">功能说明：开启后，新添加的 BT / 磁力 / 种子任务会优先下载文件开头和结尾，让未完成的视频更容易提前尝试在线播放；少数资源可能会略微影响整体下载调度，不需要边下边播时可以关闭。</p><p class="hint" data-i18n="videoProxyHint">视频下载代理只影响新添加的视频下载任务；不用手写完整代理 URL，选择类型后填写 IP/域名、端口，账号密码可选。只解析走代理会在获取真实下载链接后恢复服务器直连，全程走代理会连媒体文件下载也走代理。</p></div></div>
  <div id="trackerPanel" class="panel tracker-panel" style="margin-bottom:18px;display:none"><h2 data-i18n="trackerManagement">Tracker 管理</h2><div class="body"><div class="tracker-grid"><div><label data-i18n="trackerUrl">Tracker 列表地址（.txt）</label><input id="trackerUrl" placeholder="https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_all.txt"></div><div class="tracker-actions"><button class="btn" onclick="updateTrackers()" data-i18n="updateTrackers">更新 Trackers</button></div></div><p class="hint" data-i18n="trackerHint">功能说明：从指定 .txt 地址读取公共 BT tracker，写入 aria2 配置并重启下载服务。它能帮助磁力更快找到节点，但不能保证冷门资源一定有速度。更新后建议删除卡住的 [METADATA] 任务并重新添加。</p><p class="hint"><span data-i18n="recommendedProject">推荐使用的项目地址：</span><a href="https://github.com/ngosang/trackerslist" target="_blank" rel="noopener">https://github.com/ngosang/trackerslist</a></p><div class="tracker-meta"><span><span data-i18n="currentSource">当前来源</span>：<b id="trackerSource">-</b></span><span><span data-i18n="lastUpdated">最近更新</span>：<b id="trackerUpdated">-</b></span><span><span data-i18n="count">数量</span>：<b id="trackerCount">-</b></span></div></div></div>
  <div id="updatePanel" class="panel update-panel" style="margin-bottom:18px;display:none"><h2 data-i18n="versionUpdate">版本更新</h2><div class="body"><div class="tracker-grid"><div><label data-i18n="uploadUpdatePackage">上传更新包（.tar.gz / .tgz）</label><input id="updateFile" type="file" accept=".tar.gz,.tgz,application/gzip"></div><div class="tracker-actions"><button class="btn" onclick="uploadUpdate()" data-i18n="uploadAndUpdate">上传并更新</button></div></div><p class="hint" data-i18n="updateHint">功能说明：仅管理员可用。更新包必须是本项目打包出的 offline-downloader-docker.tar.gz，系统会校验后覆盖程序文件并自动重建 Docker 容器。请不要在下载任务关键时刻更新。</p><div class="tracker-meta"><span><span data-i18n="currentVersion">当前版本</span>：<b>{{ version }}</b></span><span><span data-i18n="updateStatus">更新状态</span>：<b id="updateStatus">-</b></span><span><span data-i18n="lastUpdated">最近更新</span>：<b id="updateTime">-</b></span></div><div class="changelog"><div class="changelog-head"><div class="section-title" data-i18n="versionHistory">版本介绍</div><button id="historyToggle" class="btn light" onclick="toggleChangelog()"></button></div><div id="changelogList"></div></div></div></div>
  <div class="grid">
    <div class="panel"><h2 data-i18n="addDownload">添加下载</h2><div class="body">
      <div class="tabs"><button class="tab active" onclick="mode('url')" id="tab-url" data-i18n="link">链接</button><button class="tab" onclick="mode('torrent')" id="tab-torrent" data-i18n="torrentFile">种子文件</button><button class="tab" onclick="mode('video')" id="tab-video" data-i18n="videoDownload">视频下载</button><button class="tab" onclick="mode('upload')" id="tab-upload" data-i18n="fileUpload">文件上传</button></div>
      <div id="urlbox"><label data-i18n="protocolType">协议类型</label><select id="kind"><option value="auto" data-i18n="autoDetect">自动识别</option><option value="bt">BT / Magnet</option><option value="hls">HLS / M3U8</option><option value="http">HTTP / HTTPS</option><option value="ftp">FTP</option></select><label data-i18n="downloadLink">下载链接</label><textarea id="urls" placeholder="可以粘贴磁力链接、http(s)、ftp、m3u8，一行一个" data-i18n-placeholder="urlsPlaceholder"></textarea><label data-i18n="saveDir">保存目录</label><div class="save-row"><select id="savePath"></select><button class="btn light" onclick="loadDirs()" data-i18n="refresh">刷新</button></div><label data-i18n="saveName">保存名称（可选，M3U8 建议填写 .mp4）</label><input id="name" placeholder="例如 movie.mp4" data-i18n-placeholder="namePlaceholder"><label data-i18n="remarkOptional">备注（可选）</label><input id="remark" placeholder="例如 电视剧第 1 集 / 朋友分享" data-i18n-placeholder="remarkPlaceholder"><button class="btn" style="width:100%;margin-top:14px" onclick="addUrl()" data-i18n="startDownload">开始离线下载</button></div>
      <div id="torrentbox" style="display:none"><label data-i18n="saveDir">保存目录</label><div class="save-row"><select id="torrentSavePath"></select><button class="btn light" onclick="loadDirs()" data-i18n="refresh">刷新</button></div><label data-i18n="uploadTorrent">上传 .torrent</label><input id="torrent" type="file" accept=".torrent"><button class="btn" style="width:100%;margin-top:14px" onclick="addTorrent()" data-i18n="uploadAndDownload">上传并下载</button></div>
      <div id="videobox" style="display:none"><label data-i18n="videoUrl">视频链接</label><textarea id="videoUrls" placeholder="粘贴视频网站链接，一行一个" data-i18n-placeholder="videoUrlsPlaceholder"></textarea><label data-i18n="videoQuality">视频质量</label><select id="videoQuality"><option value="best" data-i18n="qualityBest">最佳质量</option><option value="1080p">1080p</option><option value="720p">720p</option><option value="audio" data-i18n="audioOnly">仅音频 MP3</option></select><label data-i18n="saveDir">保存目录</label><div class="save-row"><select id="videoSavePath"></select><button class="btn light" onclick="loadDirs()" data-i18n="refresh">刷新</button></div><label data-i18n="remarkOptional">备注（可选）</label><input id="videoRemark" placeholder="例如 网站视频 / 课程" data-i18n-placeholder="videoRemarkPlaceholder"><button class="btn" style="width:100%;margin-top:14px" onclick="addVideo()" data-i18n="startVideoDownload">开始视频下载</button><label data-i18n="videoCookies">我的视频 Cookies</label><div class="hint" id="videoCookiesStatus">-</div><div class="save-row"><input id="videoCookiesFile" type="file" accept=".txt"><button class="btn light" onclick="uploadVideoCookies()" data-i18n="uploadCookies">上传 Cookies</button></div><button class="btn danger" style="width:100%;margin-top:8px" onclick="clearVideoCookies()" data-i18n="clearCookies">清除 Cookies</button><p class="hint" data-i18n="videoCookiesHint">每个用户可以上传自己的 cookies.txt，视频下载只会使用当前账号自己的 Cookies。</p></div>
      <div id="uploadbox" style="display:none"><label data-i18n="saveDir">保存目录</label><div class="save-row"><select id="uploadSavePath"></select><button class="btn light" onclick="loadDirs()" data-i18n="refresh">刷新</button></div><label data-i18n="chooseFile">选择文件</label><input id="uploadFile" type="file"><button class="btn" style="width:100%;margin-top:14px" onclick="uploadLocalFile()" data-i18n="uploadFileBtn">上传文件</button></div>
      <p class="hint" data-i18n="legalHint">请只下载你拥有权利或授权的内容。BT 下载需要安全组放行 6881 TCP/UDP 才更容易连上节点。</p>
    </div></div>
    <div class="panel"><h2 data-i18n="taskList">任务列表</h2><div class="body"><div class="actions" style="margin-top:0;margin-bottom:12px"><button class="btn danger" onclick="clearTasks(false)" data-i18n="clearAllTasks">一键删除所有任务</button><button class="btn danger" onclick="clearTasks(true)" data-i18n="clearAllTasksFiles">一键删除所有任务和文件</button></div><div id="tasks">加载中...</div></div></div>
  </div>
  <div class="panel" style="margin-top:18px"><h2 data-i18n="fileManager">文件管理 / 在线播放</h2><div class="body"><div class="toolbar"><div class="path" id="path">/</div><div class="folder-tools"><input id="folderName" placeholder="新建文件夹名称" data-i18n-placeholder="newFolderName"><button class="btn light" onclick="createFolder()" data-i18n="createFolder">新建文件夹</button><button class="btn light" onclick="loadTrash()" data-i18n="trash">回收站</button><button class="btn light" onclick="loadFiles(currentPath)" data-i18n="refresh">刷新</button></div></div><div class="file-search"><input id="fileSearch" placeholder="搜索当前目录下的文件和文件夹" data-i18n-placeholder="fileSearchPlaceholder" onkeydown="if(event.key==='Enter')searchFiles()"><button class="btn light" onclick="searchFiles()" data-i18n="search">搜索</button><button class="btn light" onclick="clearFileSearch()" data-i18n="clearSearch">清空</button></div><div id="files">加载中...</div><div id="viewer" class="viewer"></div></div></div>
  </div>
  <div id="userPage" class="page">
  <div id="userPanel" class="panel user-panel" style="margin-bottom:18px;display:none"><div class="panel-head"><h2 data-i18n="userManagement">用户管理</h2><button class="btn light" onclick="loadUsers()" data-i18n="refresh">刷新</button></div><div class="body"><div class="row"><div><label data-i18n="registrationSwitch">开放注册</label><select id="registrationEnabled"><option value="0" data-i18n="off">关闭</option><option value="1" data-i18n="on">开启</option></select></div><div><label data-i18n="userProxySwitch">普通用户代理设置</label><select id="userProxyEnabled"><option value="0" data-i18n="off">关闭</option><option value="1" data-i18n="on">开启</option></select></div><div><label data-i18n="serverTimeMode">服务器时间显示</label><select id="serverTimeMode"><option value="local" data-i18n="serverLocalTime">系统时间</option><option value="Asia/Shanghai">中国/北京</option><option value="Asia/Tokyo">日本/东京</option><option value="Asia/Singapore">新加坡</option><option value="America/New_York">美国/纽约</option><option value="America/Los_Angeles">美国/洛杉矶</option><option value="Europe/London">英国/伦敦</option><option value="Europe/Paris">法国/巴黎</option><option value="Asia/Dubai">阿联酋/迪拜</option><option value="Australia/Sydney">澳大利亚/悉尼</option></select></div><div style="align-self:end"><button class="btn light" onclick="saveAdminFeatureSettings()" data-i18n="saveSettings">保存设置</button></div></div><div class="user-add" style="margin-top:12px"><input id="registrationQuota" placeholder="注册默认额度 如 2G/500M/0无限制" data-i18n-placeholder="registrationQuotaHint"><input id="registrationSpeed" placeholder="注册默认限速 如 2M/*" data-i18n-placeholder="registrationSpeedHint"><input id="registrationExpires" placeholder="注册默认到期日 如 2026-12-31/空永久" data-i18n-placeholder="registrationExpiryHint"><input id="registrationRoots" placeholder="注册默认目录，如 _users/{username}" data-i18n-placeholder="registrationRootsHint"><span></span><span></span><span></span><button class="btn light" onclick="saveAdminFeatureSettings()" data-i18n="saveSettings">保存设置</button></div><p class="hint" data-i18n="registrationHint">关闭后登录页不会显示注册入口，注册接口也会拒绝新账号。默认目录支持 {username} 占位符。</p><div class="user-add"><input id="newUser" placeholder="新用户名" data-i18n-placeholder="newUsername"><input id="newUserPass" type="password" placeholder="初始密码" data-i18n-placeholder="initialPass"><input id="newUserQuota" placeholder="额度 如 2G/500M/0无限制" data-i18n-placeholder="quotaHint"><input id="newUserSpeed" placeholder="限速 如 2M/*" data-i18n-placeholder="speedHint"><input id="newUserExpires" placeholder="到期日 如 2026-12-31/空永久" data-i18n-placeholder="expiryHint"><input id="newUserRoots" placeholder="可访问目录，* 表示全部" data-i18n-placeholder="rootsHint"><select id="newUserRole"><option value="user" data-i18n="normalUser">普通用户</option><option value="admin" data-i18n="admin">管理员</option></select><button class="btn" onclick="addUser()" data-i18n="addUser">添加用户</button></div><p class="hint" data-i18n="userHint">额度 0 表示无限制；限速填 * 表示不限速，支持 500K、2M；到期日留空表示永久有效。</p><div id="usersBox" class="users-box">加载中...</div></div></div>
  </div>
</main></div><div id="toast" class="toast"></div>
<script>
let currentPath='';
let uploadTasks=[];
let lastTaskHtml='';
let LANG=document.body.dataset.lang||'zh';
let showFullChangelog=false;
let usersCache=[];
let usersPage=1;
let usersPageSize=10;
let usersQuery='';
const I18N={
zh:{dashboard:'首页',userCount:'用户数量',filteredCount:'筛选结果',pageInfo:'分页',perPage:'每页显示',userSearchPlaceholder:'搜索用户名、角色、目录或在线设备',prevPage:'上一页',nextPage:'下一页',appTitle:'离线下载中心',oldPass:'旧密码',newPass:'新密码',changePass:'改密码',logout:'退出',serverStatus:'服务器状态',refresh:'刷新',downloadSpeed:'下载速度',activeTasks:'活动任务',accountLimit:'账号限速',accountExpiry:'账户到期',serverTime:'服务器时间',version:'版本号',userManagement:'用户管理',newUsername:'新用户名',initialPass:'初始密码',quotaHint:'额度 如 2G/500M/0无限制',speedHint:'限速 如 2M/*',expiryHint:'到期日 如 2026-12-31/空永久',rootsHint:'可访问目录，* 表示全部',normalUser:'普通用户',admin:'管理员',addUser:'添加用户',userHint:'额度 0 表示无限制；限速填 * 表示不限速，支持 500K、2M；到期日留空表示永久有效。',downloadSettings:'下载设置',streamOptimize:'BT 边下边播优化',off:'关闭',on:'开启',saveSettings:'保存设置',streamOptimizeHint:'功能说明：开启后，新添加的 BT / 磁力 / 种子任务会优先下载文件开头和结尾，让未完成的视频更容易提前尝试在线播放；少数资源可能会略微影响整体下载调度，不需要边下边播时可以关闭。',trackerManagement:'Tracker 管理',trackerUrl:'Tracker 列表地址（.txt）',updateTrackers:'更新 Trackers',trackerHint:'功能说明：从指定 .txt 地址读取公共 BT tracker，写入 aria2 配置并重启下载服务。它能帮助磁力更快找到节点，但不能保证冷门资源一定有速度。更新后建议删除卡住的 [METADATA] 任务并重新添加。',recommendedProject:'推荐使用的项目地址：',currentSource:'当前来源',lastUpdated:'最近更新',count:'数量',versionUpdate:'版本更新',uploadUpdatePackage:'上传更新包（.tar.gz / .tgz）',uploadAndUpdate:'上传并更新',updateHint:'功能说明：仅管理员可用。更新包必须是本项目打包出的 offline-downloader-docker.tar.gz，系统会校验后覆盖程序文件并自动重建 Docker 容器。请不要在下载任务关键时刻更新。',currentVersion:'当前版本',updateStatus:'更新状态',addDownload:'添加下载',link:'链接',torrentFile:'种子文件',protocolType:'协议类型',autoDetect:'自动识别',downloadLink:'下载链接',urlsPlaceholder:'可以粘贴磁力链接、http(s)、ftp、m3u8，一行一个',saveDir:'保存目录',saveName:'保存名称（可选，M3U8 建议填写 .mp4）',namePlaceholder:'例如 movie.mp4',remarkOptional:'备注（可选）',remarkPlaceholder:'例如 电视剧第 1 集 / 朋友分享',startDownload:'开始离线下载',uploadTorrent:'上传 .torrent',uploadAndDownload:'上传并下载',legalHint:'请只下载你拥有权利或授权的内容。BT 下载需要安全组放行 6881 TCP/UDP 才更容易连上节点。',taskList:'任务列表',fileManager:'文件管理 / 在线播放',newFolderName:'新建文件夹名称',createFolder:'新建文件夹',copied:'已复制',copyPrompt:'复制下面的内容',noSource:'这个任务没有记录原始链接',notLoggedIn:'未登录',requestFailed:'请求失败',addedTask:'已添加任务',chooseTorrent:'请选择种子文件',torrentAdded:'种子已添加',active:'下载中',waiting:'等待中',paused:'暂停',complete:'完成',error:'错误',removed:'已删除',freeDefault:'剩余空间',quotaFree:'额度剩余',serverFree:'服务器剩余',permanent:'永久有效',copySource:'复制原始链接',size:'大小',done:'已下',speed:'速度',seeders:'种子',connections:'连接',eta:'预计',remark:'备注',pause:'暂停',resume:'继续',deleteTask:'删任务',deleteTaskFiles:'删任务和文件',clearAllTasks:'一键删除所有任务',clearAllTasksFiles:'一键删除所有任务和文件',confirmClearAllTasks:'确定删除所有任务？',confirmClearAllTasksFiles:'确定删除所有任务并把任务文件移入回收站？',allTasksDeleted:'所有任务已删除',noTasks:'暂无任务',confirmDeleteTask:'确定删除任务？',confirmDeleteTaskFiles:'确定删除任务和文件？',deleted:'已删除',name:'名称',modified:'修改时间',actions:'操作',folder:'[文件夹] ',file:'[文件] ',downloadFolder:'下载文件夹',deleteFolder:'删除文件夹',download:'下载',externalPlay:'外部播放',copyDirect:'复制直链',renameFile:'重命名',renamePrompt:'输入新名称',renamed:'已重命名',deleteFile:'删除',videoError:'浏览器无法播放这个视频格式，可以点外部播放或下载到本地',audioError:'浏览器无法播放这个音频格式',confirmDeleteFolder:'确定删除这个文件夹以及里面所有文件？',confirmDeleteFile:'确定删除这个文件？',folderDeleted:'文件夹已删除',fileDeleted:'文件已删除',enterFolderName:'请输入文件夹名称',folderCreated:'文件夹已创建',passChanged:'密码已修改',settingsSaved:'下载设置已保存',role:'角色',usedQuota:'已用/额度',speedLimit:'限速',expiryTime:'到期时间',allowedFolders:'可访问目录',onlineDevices:'在线设备',createdAt:'创建时间',allFolders:'全部',unlimited:'无限制',expired:'已到期',limitsFolders:'额度/目录',setUser:'设为普通用户',setAdmin:'设为管理员',fileSearchPlaceholder:'搜索当前目录下的文件和文件夹',search:'搜索',clearSearch:'清空',searching:'搜索中',searchResults:'搜索结果',noFiles:'没有文件',noSearchResults:'没有搜索结果',fileUpload:'文件上传',chooseFile:'选择文件',uploadFileBtn:'上传文件',chooseUploadFile:'请选择要上传的文件',fileUploaded:'文件已上传',uploading:'上传中'},
en:{appTitle:'Offline Downloader',oldPass:'Old password',newPass:'New password',changePass:'Change password',logout:'Logout',serverStatus:'Server Status',refresh:'Refresh',downloadSpeed:'Download speed',activeTasks:'Active tasks',accountLimit:'Speed limit',accountExpiry:'Account expiry',serverTime:'Server time',version:'Version',userManagement:'User Management',newUsername:'New username',initialPass:'Initial password',quotaHint:'Quota e.g. 2G/500M/0 unlimited',speedHint:'Speed e.g. 2M/*',expiryHint:'Expiry e.g. 2026-12-31 / blank forever',rootsHint:'Allowed folders, * means all',normalUser:'User',admin:'Admin',addUser:'Add user',userHint:'Quota 0 means unlimited; speed * means unlimited, supports 500K and 2M; blank expiry means permanent.',downloadSettings:'Download Settings',streamOptimize:'BT streaming optimization',off:'Off',on:'On',saveSettings:'Save settings',streamOptimizeHint:'When enabled, new BT / magnet / torrent tasks prioritize the beginning and end of files, making unfinished videos more likely to play early. It may slightly affect scheduling for some torrents.',trackerManagement:'Tracker Management',trackerUrl:'Tracker list URL (.txt)',updateTrackers:'Update Trackers',trackerHint:'Fetch public BT trackers from a .txt URL, write them to aria2 config, and restart download service. This can help magnets find peers faster but cannot guarantee speed for rare resources.',recommendedProject:'Recommended project: ',currentSource:'Source',lastUpdated:'Last updated',count:'Count',versionUpdate:'Version Update',uploadUpdatePackage:'Upload update package (.tar.gz / .tgz)',uploadAndUpdate:'Upload and update',updateHint:'Admin only. The package must be offline-downloader-docker.tar.gz built by this project. The system validates it, replaces program files, and rebuilds Docker containers.',currentVersion:'Current version',updateStatus:'Update status',addDownload:'Add Download',link:'Link',torrentFile:'Torrent file',protocolType:'Protocol',autoDetect:'Auto detect',downloadLink:'Download link',urlsPlaceholder:'Paste magnet, http(s), ftp, or m3u8 links, one per line',saveDir:'Save folder',saveName:'Save name (optional, .mp4 suggested for M3U8)',namePlaceholder:'e.g. movie.mp4',remarkOptional:'Remark (optional)',remarkPlaceholder:'e.g. Episode 1 / shared by friend',startDownload:'Start offline download',uploadTorrent:'Upload .torrent',uploadAndDownload:'Upload and download',legalHint:'Only download content you own or are authorized to use. For BT, allow TCP/UDP 6881 in the security group for better peer connectivity.',taskList:'Task List',fileManager:'File Manager / Online Playback',newFolderName:'New folder name',createFolder:'Create folder',copied:'Copied',copyPrompt:'Copy the content below',noSource:'No original link was recorded for this task',notLoggedIn:'Not logged in',requestFailed:'Request failed',addedTask:'Task added',chooseTorrent:'Please choose a torrent file',torrentAdded:'Torrent added',active:'Downloading',waiting:'Waiting',paused:'Paused',complete:'Complete',error:'Error',removed:'Removed',freeDefault:'Free space',quotaFree:'Quota free',serverFree:'Server free',permanent:'Permanent',copySource:'Copy original link',size:'Size',done:'Done',speed:'Speed',seeders:'Seeders',connections:'Connections',eta:'ETA',remark:'Remark',pause:'Pause',resume:'Resume',deleteTask:'Delete task',deleteTaskFiles:'Delete task and files',clearAllTasks:'Delete all tasks',clearAllTasksFiles:'Delete all tasks and files',confirmClearAllTasks:'Delete all tasks?',confirmClearAllTasksFiles:'Delete all tasks and move task files to trash?',allTasksDeleted:'All tasks deleted',noTasks:'No tasks',confirmDeleteTask:'Delete this task?',confirmDeleteTaskFiles:'Delete this task and its files?',deleted:'Deleted',name:'Name',modified:'Modified',actions:'Actions',folder:'[Folder] ',file:'[File] ',downloadFolder:'Download folder',deleteFolder:'Delete folder',download:'Download',externalPlay:'Open player',copyDirect:'Copy direct link',renameFile:'Rename',renamePrompt:'Enter new name',renamed:'Renamed',deleteFile:'Delete',videoError:'The browser cannot play this video format. Try external playback or download it locally.',audioError:'The browser cannot play this audio format.',confirmDeleteFolder:'Delete this folder and everything inside?',confirmDeleteFile:'Delete this file?',folderDeleted:'Folder deleted',fileDeleted:'File deleted',enterFolderName:'Enter a folder name',folderCreated:'Folder created',passChanged:'Password changed',settingsSaved:'Download settings saved',role:'Role',usedQuota:'Used / quota',speedLimit:'Speed limit',expiryTime:'Expiry',allowedFolders:'Allowed folders',onlineDevices:'Online devices',createdAt:'Created at',allFolders:'All',unlimited:'Unlimited',expired:'Expired',limitsFolders:'Quota / folders',setUser:'Set user',setAdmin:'Set admin',fileSearchPlaceholder:'Search files and folders under current folder',search:'Search',clearSearch:'Clear',searching:'Searching',searchResults:'Search results',noFiles:'No files',noSearchResults:'No search results',fileUpload:'File upload',chooseFile:'Choose file',uploadFileBtn:'Upload file',chooseUploadFile:'Please choose a file to upload',fileUploaded:'File uploaded',uploading:'Uploading'}
};
Object.assign(I18N.zh,{trash:'回收站',restore:'恢复',permanentDelete:'彻底删除',deletedToTrash:'已移入回收站',trashEmpty:'回收站为空',deletedAt:'删除时间',originalPath:'原路径',confirmPermanentDelete:'彻底删除后无法恢复，确定删除？',confirmRestore:'确定恢复到原路径？',restored:'已恢复',permanentlyDeleted:'已彻底删除'});
Object.assign(I18N.en,{trash:'Trash',restore:'Restore',permanentDelete:'Delete permanently',deletedToTrash:'Moved to trash',trashEmpty:'Trash is empty',deletedAt:'Deleted at',originalPath:'Original path',confirmPermanentDelete:'Permanently delete this item? This cannot be undone.',confirmRestore:'Restore to original path?',restored:'Restored',permanentlyDeleted:'Permanently deleted'});
Object.assign(I18N.zh,{versionHistory:'版本介绍'});
Object.assign(I18N.en,{versionHistory:'Version history'});
Object.assign(I18N.en,{dashboard:'Dashboard',userCount:'Users',filteredCount:'Filtered',pageInfo:'Page',perPage:'Per page',userSearchPlaceholder:'Search username, role, folder, or device',prevPage:'Previous',nextPage:'Next'});
Object.assign(I18N.zh,{showHistory:'查看历史',hideHistory:'收起历史',emptyTrash:'清空回收站',confirmEmptyTrash:'确定彻底删除回收站里所有可见文件？此操作无法恢复。',trashEmptied:'回收站已清空'});
Object.assign(I18N.en,{showHistory:'Show history',hideHistory:'Hide history',emptyTrash:'Empty trash',confirmEmptyTrash:'Permanently delete all visible trash items? This cannot be undone.',trashEmptied:'Trash emptied'});
Object.assign(I18N.zh,{videoDownload:'视频下载',videoUrl:'视频链接',videoUrlsPlaceholder:'粘贴视频网站链接，一行一个',videoQuality:'视频质量',qualityBest:'最佳质量',audioOnly:'仅音频 MP3',videoRemarkPlaceholder:'例如 网站视频 / 课程',startVideoDownload:'开始视频下载',videoCookies:'我的视频 Cookies',cookiePresent:'已上传 Cookies',cookieMissing:'未上传 Cookies',cookieUpdated:'更新时间',uploadCookies:'上传 Cookies',clearCookies:'清除 Cookies',confirmClearCookies:'确定清除当前账号的视频 Cookies？',cookiesCleared:'Cookies 已清除',videoCookiesHint:'每个用户可以上传自己的 cookies.txt，视频下载只会使用当前账号自己的 Cookies。',chooseCookies:'请选择 cookies.txt 文件',cookiesUploaded:'Cookies 已上传'});
Object.assign(I18N.en,{videoDownload:'Video download',videoUrl:'Video URL',videoUrlsPlaceholder:'Paste video page URLs, one per line',videoQuality:'Video quality',qualityBest:'Best quality',audioOnly:'Audio only MP3',videoRemarkPlaceholder:'e.g. web video / course',startVideoDownload:'Start video download',videoCookies:'My video cookies',cookiePresent:'Cookies uploaded',cookieMissing:'No cookies uploaded',cookieUpdated:'Updated',uploadCookies:'Upload cookies',clearCookies:'Clear cookies',confirmClearCookies:'Clear video cookies for the current account?',cookiesCleared:'Cookies cleared',videoCookiesHint:'Each user can upload their own cookies.txt. Video downloads only use the current account cookies.',chooseCookies:'Please choose a cookies.txt file',cookiesUploaded:'Cookies uploaded'});
Object.assign(I18N.zh,{videoProxySwitch:'视频下载代理',videoProxyMode:'代理模式',videoProxyGeo:'只解析走代理',videoProxyFull:'全程走代理',videoProxyType:'代理类型',videoProxyHost:'代理 IP/域名',videoProxyPort:'端口',videoProxyUsername:'账号',videoProxyPassword:'密码',testProxy:'测试代理连接',proxyTesting:'正在测试代理...',proxyTestOk:'代理连接成功',videoProxyHint:'视频下载代理只影响新添加的视频下载任务；不用手写完整代理 URL，选择类型后填写 IP/域名、端口，账号密码可选。只解析走代理会在获取真实下载链接后恢复服务器直连，全程走代理会连媒体文件下载也走代理。'});
Object.assign(I18N.en,{videoProxySwitch:'Video download proxy',videoProxyMode:'Proxy mode',videoProxyGeo:'Proxy for parsing only',videoProxyFull:'Proxy full download',videoProxyType:'Proxy type',videoProxyHost:'Proxy IP / host',videoProxyPort:'Port',videoProxyUsername:'Username',videoProxyPassword:'Password',testProxy:'Test proxy connection',proxyTesting:'Testing proxy...',proxyTestOk:'Proxy connection OK',videoProxyHint:'The video proxy only affects newly added video download tasks. Choose a proxy type and enter host, port, and optional credentials instead of a full proxy URL. Parsing-only mode uses the proxy to get the real media URL, then downloads directly from the server; full mode proxies the media download too.'});
Object.assign(I18N.zh,{videoFirmwareVersion:'视频下载固件版本',checkUpdate:'检查更新',updateFirmware:'更新',firmwareChecking:'正在检查视频下载固件版本...',firmwareChecked:'检查完成，当前版本：',firmwareUpdating:'正在更新视频下载固件，请稍等...',firmwareUpdated:'视频下载固件已更新'});
Object.assign(I18N.en,{videoFirmwareVersion:'Video downloader firmware version',checkUpdate:'Check update',updateFirmware:'Update',firmwareChecking:'Checking video downloader firmware version...',firmwareChecked:'Check complete, current version: ',firmwareUpdating:'Updating video downloader firmware, please wait...',firmwareUpdated:'Video downloader firmware updated'});
Object.assign(I18N.zh,{registrationSwitch:'开放注册',registrationHint:'关闭后登录页不会显示注册入口，注册接口也会拒绝新账号。默认目录支持 {username} 占位符。',registrationSaved:'设置已保存',registrationQuotaHint:'注册默认额度 如 2G/500M/0无限制',registrationSpeedHint:'注册默认限速 如 2M/*',registrationExpiryHint:'注册默认到期日 如 2026-12-31/空永久',registrationRootsHint:'注册默认目录，如 _users/{username}',userProxySwitch:'普通用户代理设置',serverTimeMode:'服务器时间显示',serverLocalTime:'系统时间'});
Object.assign(I18N.en,{registrationSwitch:'Open registration',registrationHint:'When disabled, the login page hides registration and the API rejects new accounts. Default folders support the {username} placeholder.',registrationSaved:'Settings saved',registrationQuotaHint:'Default signup quota e.g. 2G/500M/0 unlimited',registrationSpeedHint:'Default signup speed e.g. 2M/*',registrationExpiryHint:'Default signup expiry e.g. 2026-12-31 / blank forever',registrationRootsHint:'Default signup folder, e.g. _users/{username}',userProxySwitch:'User proxy settings',serverTimeMode:'Server time display',serverLocalTime:'System time'});
const CHANGELOG=[
{v:'V1.5.9',zh:['用户管理改为左侧导航里的独立页面，避免用户数量多时撑长首页。','用户列表新增搜索和每页数量选择，支持每页 10、30、50、100 个用户。'],en:['Moved User Management into a separate left-navigation page to keep the dashboard compact with many users.','Added user search and page-size selection with 10, 30, 50, or 100 users per page.']},
{v:'V1.5.8',zh:['管理员下载设置新增视频下载固件版本显示。','可在页面检查并更新视频下载固件，用于修复视频网站解析规则变化导致的下载失败。'],en:['Added video downloader firmware version display in admin Download Settings.','Admins can check and update the video downloader firmware from the page to handle site extractor changes.']},
{v:'V1.5.7',zh:['用户管理新增刷新按钮。','管理员可开放普通用户代理设置，普通用户可保存自己的视频下载代理。','服务器时间显示支持按多个国家/地区时区校准。'],en:['Added a refresh button in User Management.','Admins can allow normal users to configure their own video download proxy.','Server time display can be calibrated to multiple country/region time zones.']},
{v:'V1.5.6',zh:['修复普通用户可通过删除到回收站绕过空间额度的问题。','额度统计现在会同时计算当前文件和该用户回收站内的文件，恢复回收站文件后额度剩余也保持正确。'],en:['Fixed a quota bypass where normal users could move files to trash and keep downloading.','Quota usage now counts both active files and files in that user trash, keeping remaining quota correct after restore.']},
{v:'V1.5.5',zh:['登录/注册页面新增中文和英文切换。','管理员可设置新注册用户默认额度、限速、到期时间和可访问目录，注册成功后自动套用。'],en:['Added Chinese / English switching on the login and registration pages.','Admins can set default quota, speed limit, expiry, and allowed folders for newly registered users.']},
{v:'V1.5.4',zh:['新增账号注册功能，注册时需要完成验证码验证，减少批量注册。','管理员用户管理新增开放注册开关；关闭后登录页不显示注册入口，后端注册接口也会拒绝新账号。'],en:['Added account registration with captcha verification to reduce bulk signups.','Admins can toggle open registration in User Management; when disabled, the login page hides registration and the backend rejects new accounts.']},
{v:'V1.5.3',zh:['下载设置新增代理连接测试按钮。','测试会使用当前填写的代理类型、IP/域名、端口和账号密码，从服务器实际发起连接并显示成功或失败原因。'],en:['Added a proxy connection test button in Download Settings.','The test uses the currently entered proxy type, host, port, and credentials to make a real server-side connection and show success or failure details.']},
{v:'V1.5.2',zh:['移除测试版浏览器指纹功能，恢复稳定版下载设置。','视频下载代理改为代理类型、IP/域名、端口、账号、密码分项填写，系统会自动拼接代理地址。'],en:['Removed the test browser fingerprint feature and returned download settings to the stable flow.','Video proxy settings now use separate type, host, port, username, and password fields; the system builds the proxy URL automatically.']},
{v:'V1.5.1',zh:['修复视频下载、M3U8 下载任务无法暂停和继续的问题。','暂停后任务会显示暂停状态，继续后恢复下载中。'],en:['Fixed pause and resume for video and M3U8 download tasks.','Paused tasks now show paused status and resume back to active.']},
{v:'V1.5.0',zh:['视频下载代理新增模式选择：只解析走代理或全程走代理。','只解析走代理适合代理容易断开媒体下载的情况，获取真实下载链接后会恢复服务器直连。'],en:['Added video proxy mode selection: proxy for parsing only or full proxy download.','Parsing-only mode is useful when the proxy disconnects during media download; after resolving the real media URL, the server downloads directly.']},
{v:'V1.4.9',zh:['管理员下载设置新增视频下载代理开关和代理地址。','开启代理后，新添加的视频下载任务会自动通过该代理访问目标网站；关闭后新任务恢复直连。'],en:['Added an admin video download proxy toggle and proxy URL setting.','When enabled, newly added video download tasks use the proxy; when disabled, new tasks use direct server access.']},
{v:'V1.4.8',zh:['优化界面交互手感：按钮新增按下动画和点击波纹。','刷新、打开回收站、添加下载等操作新增加载状态和过渡动画。'],en:['Improved UI feel with pressed button animation and click ripple feedback.','Added loading states and transitions for refresh, trash, and add-download actions.']},
{v:'V1.4.7',zh:['任务列表新增一键删除所有任务、一键删除所有任务和文件。','修复普通用户可以看到或删除其他用户任务和文件的权限问题。'],en:['Added one-click delete all tasks, and delete all tasks with files.','Fixed permissions so normal users cannot view or delete other users tasks or files.']},
{v:'V1.4.6',zh:['视频下载针对 PornHub 链接自动加入桌面浏览器请求参数。','当服务器拿到的不是正常视频页时，失败提示会说明可能是年龄确认、地区限制或反爬限制，并提示可尝试真实 Cookies、换 IP 或代理。'],en:['Video download now adds desktop browser request headers for PornHub links.','When the server receives a non-video page, the error now explains possible age, region, or anti-bot restrictions and suggests real cookies, another IP, or a proxy.']},
{v:'V1.4.5',zh:['视频下载页新增当前账号 Cookies 状态显示，已上传时会显示大小和更新时间，避免重复上传。'],en:['Added current account cookies status in the video download tab, including size and update time when uploaded.']},
{v:'V1.4.4',zh:['修复 YouTube 新签名解析问题：启用远程 EJS 解密组件，服务器已验证可列出 1080p/1440p/2160p 格式。','新增清除当前账号视频 Cookies 的功能。'],en:['Fixed YouTube signature extraction by enabling remote EJS components; verified server can list 1080p/1440p/2160p formats.','Added a button to clear video cookies for the current account.']},
{v:'V1.4.3',zh:['修复 YouTube 只获取到图片格式的问题：容器新增 nodejs，并让视频下载组件使用 JavaScript runtime 解析签名。','视频格式选择增加 fallback，减少 Requested format is not available 错误。','修复删除 HLS/视频任务时可能出现 INTERNAL SERVER ERROR 的问题。','视频 Cookies 改为每个用户独立上传和使用，普通用户也能上传自己的 cookies.txt。'],en:['Fixed YouTube cases where only image/storyboard formats were available by adding nodejs and enabling JavaScript runtime for the video downloader component.','Added format fallbacks to reduce Requested format is not available errors.','Fixed INTERNAL SERVER ERROR when deleting HLS/video tasks.','Video cookies are now uploaded and used per user, and normal users can upload their own cookies.txt.']},
{v:'V1.4.2',zh:['视频下载失败时显示更明确的视频下载组件错误信息。','支持管理员上传 cookies.txt，用于 YouTube 登录验证或机器人验证场景。'],en:['Video download failures now show clearer video downloader component errors.','Admins can upload cookies.txt for YouTube sign-in or bot verification cases.']},
{v:'V1.4.1',zh:['添加视频下载功能，使用视频下载组件和 ffmpeg 支持最佳质量、1080p、720p 和 MP3 音频。'],en:['Added video download using a video downloader component and ffmpeg with best, 1080p, 720p, and MP3 audio modes.']},
{v:'V1.4.0',zh:['版本介绍默认只显示最新版本，点击后可查看完整历史。','回收站新增一键清空功能。'],en:['Version history now shows only the latest update by default, with full history available on click.','Added one-click empty trash.']},
{v:'V1.3.9',zh:['新增版本介绍/历史更新说明，管理员可在版本更新面板查看。'],en:['Added version history in the update panel for admins.']},
{v:'V1.3.8',zh:['删除文件或文件夹会先进入回收站。','回收站支持恢复和彻底删除。'],en:['Files and folders are moved to trash before deletion.','Trash supports restore and permanent deletion.']},
{v:'V1.3.7',zh:['下载好的文件、上传好的文件和文件夹支持重命名。'],en:['Downloaded files, uploaded files, and folders can be renamed.']},
{v:'V1.3.6',zh:['上传文件时任务列表显示上传速度、进度和预计剩余时间。'],en:['File uploads show speed, progress, and ETA in the task list.']},
{v:'V1.3.5',zh:['添加下载区域新增普通文件上传功能。'],en:['Added local file upload in the add-download area.']},
{v:'V1.3.4',zh:['文件管理和在线播放区域新增搜索功能。'],en:['Added search for file manager and playback area.']},
{v:'V1.3.3',zh:['新增中文/英文语言切换。'],en:['Added Chinese / English language switch.']},
{v:'V1.3.2',zh:['新增 BT 边下边播优化开关。','任务列表显示预计完成时间。'],en:['Added BT streaming optimization toggle.','Task list shows estimated completion time.']},
{v:'V1.3.1',zh:['修复部分视频在线播放点击无反应的问题。'],en:['Fixed playback button issues for some videos.']},
{v:'V1.3',zh:['添加下载支持备注。','任务列表显示种子数、连接数等资源信息。'],en:['Added remarks for download tasks.','Task list shows seeders and connections.']},
{v:'V1.2',zh:['任务列表新增复制原始下载地址。'],en:['Added copying original download source from the task list.']},
{v:'V1.1',zh:['新增页面上传更新包并自动更新程序。'],en:['Added web-based update package upload and auto update.']},
{v:'V1',zh:['Docker 一键安装版本。','支持离线下载、文件管理、在线播放、多用户和空间限制。'],en:['Docker one-key install release.','Supports offline download, file manager, playback, multi-user, and quota limits.']}
];
function tr(k){return (I18N[LANG]&&I18N[LANG][k])||I18N.zh[k]||k}
function applyI18n(){document.documentElement.lang=LANG==='en'?'en':'zh-CN';let sel=qs('#langSelect');if(sel)sel.value=LANG;document.querySelectorAll('[data-i18n]').forEach(el=>{el.textContent=tr(el.dataset.i18n)});document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{el.placeholder=tr(el.dataset.i18nPlaceholder)})}
function renderChangelog(){let el=qs('#changelogList');if(!el)return;let items=showFullChangelog?CHANGELOG:CHANGELOG.slice(0,1);el.innerHTML=items.map(x=>`<div class="changelog-item"><div class="changelog-title">${esc(x.v)}</div><ul>${(x[LANG]||x.zh).map(i=>`<li>${esc(i)}</li>`).join('')}</ul></div>`).join('');let btn=qs('#historyToggle');if(btn)btn.textContent=showFullChangelog?tr('hideHistory'):tr('showHistory')}
function toggleChangelog(){showFullChangelog=!showFullChangelog;renderChangelog()}
function qs(x){return document.querySelector(x)}
function toast(t){let el=qs('#toast');el.textContent=t;el.style.display='block';el.style.animation='none';void el.offsetWidth;el.style.animation='toastIn .18s ease';setTimeout(()=>el.style.display='none',2400)}
function showPage(page){let isUsers=page==='users';if(qs('#mainPage'))qs('#mainPage').classList.toggle('active',!isUsers);if(qs('#userPage'))qs('#userPage').classList.toggle('active',isUsers);if(qs('#navMain'))qs('#navMain').classList.toggle('active',!isUsers);if(qs('#navUsers'))qs('#navUsers').classList.toggle('active',isUsers);if(isUsers)loadUsers()}
function bindButtonEffects(){document.addEventListener('pointerdown',e=>{let b=e.target.closest('.btn,.tab');if(!b||b.disabled)return;b.classList.add('pressed');setTimeout(()=>b.classList.remove('pressed'),160);if(!b.classList.contains('btn'))return;let r=document.createElement('span');r.className='ripple';let rect=b.getBoundingClientRect();let size=Math.max(rect.width,rect.height);r.style.width=r.style.height=size+'px';r.style.left=(e.clientX-rect.left-size/2)+'px';r.style.top=(e.clientY-rect.top-size/2)+'px';b.appendChild(r);setTimeout(()=>r.remove(),520)})}
async function withButtonLoading(btn,fn){btn=btn&&btn.closest?btn.closest('.btn'):btn;if(btn){btn.classList.add('loading');btn.disabled=true}try{return await fn()}finally{if(btn){btn.classList.remove('loading');btn.disabled=false}}}
function showLoading(target,text){let el=typeof target==='string'?qs(target):target;if(el)el.innerHTML=`<div class="hint loading-line">${esc(text||'加载中...')}</div>`}
function clickEvent(){return (typeof event!=='undefined'&&event&&event.type==='click')?event:null}
function fmtBytesJs(n){n=Number(n||0);let u=['B','KB','MB','GB','TB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return (i?n.toFixed(n>=10?1:2):Math.round(n))+ ' ' + u[i]}
function fmtEtaJs(seconds){seconds=Number(seconds||0);if(!isFinite(seconds)||seconds<=0)return '--';seconds=Math.round(seconds);if(seconds<60)return seconds+(LANG==='en'?'s':'秒');let m=Math.floor(seconds/60),s=seconds%60;if(m<60)return m+(LANG==='en'?'m ':'分')+String(s).padStart(2,'0')+(LANG==='en'?'s':'秒');let h=Math.floor(m/60);m=m%60;if(h<24)return h+(LANG==='en'?'h ':'小时')+String(m).padStart(2,'0')+(LANG==='en'?'m':'分');let d=Math.floor(h/24);h=h%24;return d+(LANG==='en'?'d ':'天')+String(h).padStart(2,'0')+(LANG==='en'?'h':'小时')}
function renderTaskList(){let uploads=uploadTasks.map(t=>{let p=Math.max(0,Math.min(100,t.progress||0));let status=t.status||'active';let speed=t.speed||0;let eta=speed>0&&t.total>t.loaded?fmtEtaJs((t.total-t.loaded)/speed):'--';return `<div class="task"><div class="task-head"><div class="name" title="${esc(t.name)}">${esc(t.name)}</div><span class="badge ${esc(status)}">${status==='complete'?tr('complete'):status==='error'?tr('error'):tr('uploading')}</span></div><div class="meta">${tr('size')} ${fmtBytesJs(t.total)} · ${tr('done')} ${fmtBytesJs(t.loaded)} · ${tr('speed')} ${fmtBytesJs(speed)}/s · ${tr('eta')} ${eta}</div>${t.error?`<div class="meta">${esc(t.error)}</div>`:''}<div class="bar"><i style="width:${p}%"></i></div><div class="meta">${p.toFixed(1)}%</div></div>`}).join('');qs('#tasks').innerHTML=uploads||lastTaskHtml?uploads+(lastTaskHtml||''):`<div class="hint">${tr('noTasks')}</div>`}
async function copyText(t){try{await navigator.clipboard.writeText(t);toast(tr('copied'))}catch(e){prompt(tr('copyPrompt'),t)}}
async function copyTaskSource(id){let value=(window.taskSources||{})[id];if(value)await copyText(value);else toast(tr('noSource'))}
function mode(m){qs('#urlbox').style.display=m==='url'?'block':'none';qs('#torrentbox').style.display=m==='torrent'?'block':'none';qs('#videobox').style.display=m==='video'?'block':'none';qs('#uploadbox').style.display=m==='upload'?'block':'none';qs('#tab-url').classList.toggle('active',m==='url');qs('#tab-torrent').classList.toggle('active',m==='torrent');qs('#tab-video').classList.toggle('active',m==='video');qs('#tab-upload').classList.toggle('active',m==='upload')}
async function api(url,opt={}){let r=await fetch(url,opt); if(r.status===401){location.href='/';throw new Error(tr('notLoggedIn'))} if(!r.ok){let j=await r.json().catch(()=>({error:r.statusText})); throw new Error(j.error||tr('requestFailed'))} return r.json()}
async function loadDirs(){try{let d=await api('/api/dirs');let opts=(d.dirs||[]).map(x=>`<option value="${esc(x.path)}">${esc(x.label)}</option>`).join('');if(qs('#savePath'))qs('#savePath').innerHTML=opts;if(qs('#torrentSavePath'))qs('#torrentSavePath').innerHTML=opts;if(qs('#videoSavePath'))qs('#videoSavePath').innerHTML=opts;if(qs('#uploadSavePath'))qs('#uploadSavePath').innerHTML=opts}catch(e){}}
async function addUrl(){await withButtonLoading(clickEvent()?.currentTarget,async()=>{try{await api('/api/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:qs('#kind').value,urls:qs('#urls').value,name:qs('#name').value,remark:qs('#remark')?qs('#remark').value:'',save_path:qs('#savePath')?qs('#savePath').value:''})});qs('#urls').value='';qs('#name').value='';if(qs('#remark'))qs('#remark').value='';toast(tr('addedTask'));refresh();loadFiles(currentPath);loadDirs()}catch(e){toast(e.message)}})}
async function addTorrent(){let f=qs('#torrent').files[0]; if(!f)return toast(tr('chooseTorrent')); await withButtonLoading(clickEvent()?.currentTarget,async()=>{let fd=new FormData();fd.append('torrent',f);fd.append('save_path',qs('#torrentSavePath')?qs('#torrentSavePath').value:'');try{await api('/api/torrent',{method:'POST',body:fd});qs('#torrent').value='';toast(tr('torrentAdded'));refresh();loadDirs()}catch(e){toast(e.message)}})}
async function addVideo(){await withButtonLoading(clickEvent()?.currentTarget,async()=>{try{await api('/api/video',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({urls:qs('#videoUrls').value,quality:qs('#videoQuality').value,remark:qs('#videoRemark')?qs('#videoRemark').value:'',save_path:qs('#videoSavePath')?qs('#videoSavePath').value:''})});qs('#videoUrls').value='';if(qs('#videoRemark'))qs('#videoRemark').value='';toast(tr('addedTask'));refresh();loadFiles(currentPath);loadDirs()}catch(e){toast(e.message)}})}
async function loadVideoCookiesStatus(){try{let d=await api('/api/video/cookies');let el=qs('#videoCookiesStatus');if(!el)return;el.textContent=d.exists?`${tr('cookiePresent')} · ${esc(d.size||'')} · ${tr('cookieUpdated')} ${esc(d.updated_at||'-')}`:tr('cookieMissing')}catch(e){let el=qs('#videoCookiesStatus');if(el)el.textContent='-'}}
async function uploadVideoCookies(){let f=qs('#videoCookiesFile').files[0];if(!f)return toast(tr('chooseCookies'));let fd=new FormData();fd.append('cookies',f);try{await api('/api/video/cookies',{method:'POST',body:fd});qs('#videoCookiesFile').value='';toast(tr('cookiesUploaded'));loadVideoCookiesStatus()}catch(e){toast(e.message)}}
async function clearVideoCookies(){if(!confirm(tr('confirmClearCookies')))return;try{await api('/api/video/cookies',{method:'DELETE'});toast(tr('cookiesCleared'));loadVideoCookiesStatus()}catch(e){toast(e.message)}}
async function uploadLocalFile(){let f=qs('#uploadFile').files[0];if(!f)return toast(tr('chooseUploadFile'));let fd=new FormData();fd.append('file',f);fd.append('save_path',qs('#uploadSavePath')?qs('#uploadSavePath').value:'');let id='up-'+Date.now()+'-'+Math.random().toString(16).slice(2);let task={id,name:f.name,total:f.size,loaded:0,speed:0,progress:0,status:'active',started:Date.now(),lastTime:Date.now(),lastLoaded:0};uploadTasks.unshift(task);renderTaskList();toast(tr('uploading')+'...');try{await new Promise((resolve,reject)=>{let xhr=new XMLHttpRequest();xhr.open('POST','/api/upload-file');xhr.upload.onprogress=e=>{if(e.lengthComputable){let now=Date.now();let dt=(now-task.lastTime)/1000;task.loaded=e.loaded;task.total=e.total||f.size;task.progress=task.total?task.loaded*100/task.total:0;if(dt>=0.35){task.speed=(task.loaded-task.lastLoaded)/dt;task.lastLoaded=task.loaded;task.lastTime=now}renderTaskList()}};xhr.onload=()=>{if(xhr.status===401){location.href='/';reject(new Error(tr('notLoggedIn')));return}let data={};try{data=JSON.parse(xhr.responseText||'{}')}catch(e){}if(xhr.status>=200&&xhr.status<300&&data.ok!==false)resolve(data);else reject(new Error(data.error||xhr.statusText||tr('requestFailed')))};xhr.onerror=()=>reject(new Error(tr('requestFailed')));xhr.send(fd)});task.loaded=task.total;task.progress=100;task.status='complete';task.speed=0;renderTaskList();qs('#uploadFile').value='';toast(tr('fileUploaded'));loadFiles(currentPath);loadDirs();refresh();setTimeout(()=>{uploadTasks=uploadTasks.filter(x=>x.id!==id);renderTaskList()},5000)}catch(e){task.status='error';task.error=e.message;renderTaskList();toast(e.message)}}
function statusText(s){return tr(s)||s}
async function refresh(){let ev=clickEvent();if(ev)showLoading('#tasks','正在刷新任务...');await withButtonLoading(ev?ev.currentTarget:null,async()=>{try{let d=await api('/api/status');qs('#free').textContent=d.free;if(qs('#freeLabel'))qs('#freeLabel').textContent=d.free_label_key?tr(d.free_label_key):(d.free_label||tr('freeDefault'));qs('#downspeed').textContent=d.down_speed;qs('#active').textContent=d.active;if(qs('#speedlimit'))qs('#speedlimit').textContent=d.speed_limit||'*';if(qs('#expires'))qs('#expires').textContent=d.expires_label_key?tr(d.expires_label_key):(d.expires_label||tr('permanent'));if(qs('#servertime'))qs('#servertime').textContent=d.server_time||'-';let html='';window.taskSources={}; for(let t of d.tasks){let p=Math.max(0,Math.min(100,t.progress||0));if(t.source_url)window.taskSources[String(t.id)]=t.source_url;let copyBtn=t.source_url?`<button class="btn light" onclick="copyTaskSource('${esc(t.id)}')">${tr('copySource')}</button>`:'';let remark=t.remark?`<div class="meta">${tr('remark')}：${esc(t.remark)}</div>`:'';let peerMeta=`${tr('seeders')} ${esc(t.seeders??0)} · ${tr('connections')} ${esc(t.connections??0)} · ${tr('eta')} ${esc(t.eta||'--')}`;html+=`<div class="task"><div class="task-head"><div class="name" title="${esc(t.name)}">${esc(t.name)}</div><span class="badge ${esc(t.status)}">${statusText(t.status)}</span></div><div class="meta">${tr('size')} ${esc(t.total)} · ${tr('done')} ${esc(t.done)} · ${tr('speed')} ${esc(t.speed)} · ${peerMeta} · ${esc(t.extra||'')}</div>${remark}<div class="bar"><i style="width:${p}%"></i></div><div class="meta">${p.toFixed(1)}%</div><div class="actions">${copyBtn}<button class="btn light" onclick="pauseTask('${esc(t.type)}','${esc(t.id)}')">${tr('pause')}</button><button class="btn light" onclick="resumeTask('${esc(t.type)}','${esc(t.id)}')">${tr('resume')}</button><button class="btn danger" onclick="delTask('${esc(t.type)}','${esc(t.id)}',false)">${tr('deleteTask')}</button><button class="btn danger" onclick="delTask('${esc(t.type)}','${esc(t.id)}',true)">${tr('deleteTaskFiles')}</button></div></div>`} lastTaskHtml=html;renderTaskList()}catch(e){qs('#tasks').textContent=e.message}})}
async function pauseTask(type,id){try{await api('/api/task/'+type+'/'+id+'/pause',{method:'POST'});refresh()}catch(e){toast(e.message)}}
async function resumeTask(type,id){try{await api('/api/task/'+type+'/'+id+'/resume',{method:'POST'});refresh()}catch(e){toast(e.message)}}
async function delTask(type,id,files){if(!confirm(files?tr('confirmDeleteTaskFiles'):tr('confirmDeleteTask')))return;try{await api('/api/task/'+type+'/'+id+'?files='+(files?'1':'0'),{method:'DELETE'});toast(tr('deleted'));refresh();loadFiles(currentPath)}catch(e){toast(e.message)}}
async function clearTasks(files){if(!confirm(files?tr('confirmClearAllTasksFiles'):tr('confirmClearAllTasks')))return;try{let d=await api('/api/tasks?files='+(files?'1':'0'),{method:'DELETE'});toast(tr('allTasksDeleted')+'：'+(d.removed??0));refresh();loadFiles(currentPath);loadDirs()}catch(e){toast(e.message)}}
function jsq(s){return esc(JSON.stringify(String(s??'')))}
function fileUrl(base,p){return base+'/'+String(p??'').replaceAll('\\','/').split('/').map(encodeURIComponent).join('/')}
function renderFiles(d){if(d.dirs){let opts=d.dirs.map(x=>`<option value="${esc(x.path)}">${esc(x.label)}</option>`).join('');if(qs('#savePath'))qs('#savePath').innerHTML=opts;if(qs('#torrentSavePath'))qs('#torrentSavePath').innerHTML=opts;if(qs('#uploadSavePath'))qs('#uploadSavePath').innerHTML=opts}qs('#path').textContent='/' + (d.path??currentPath);let rows=`<div class="files-wrap"><table class="files"><thead><tr><th>${tr('name')}</th><th>${tr('size')}</th><th>${tr('modified')}</th><th>${tr('actions')}</th></tr></thead><tbody>`;if(!d.searching&&currentPath){let up=currentPath.split('/').slice(0,-1).join('/');rows+=`<tr><td><a href="javascript:void(0)" onclick="loadFiles(${jsq(up)})">..</a></td><td></td><td></td><td></td></tr>`}for(let f of d.files){let p=f.path.replaceAll('\\','/');let encoded=p.split('/').map(encodeURIComponent).join('/');let direct='/raw/'+d.share_token+'/'+encoded;let downloadUrl=fileUrl('/download',p);let folderUrl=fileUrl('/download-folder',p);let nameClick=f.dir?`loadFiles(${jsq(p)})`:`play(${jsq(p)},${jsq(f.kind)})`;let renameBtn=`<button class="btn light" onclick="renameFile(${jsq(p)})">${tr('renameFile')}</button>`;let ops=f.dir?`<a class="btn light" href="${folderUrl}">${tr('downloadFolder')}</a> ${renameBtn} <button class="btn danger" onclick="delFile(${jsq(p)},true)">${tr('deleteFolder')}</button>`:`<a class="btn light" href="${downloadUrl}">${tr('download')}</a> ${f.kind==='video'?`<a class="btn light" target="_blank" href="${esc(direct)}">${tr('externalPlay')}</a> <button class="btn light" onclick="copyText(location.origin+${jsq(direct)})">${tr('copyDirect')}</button>`:''} ${renameBtn} <button class="btn danger" onclick="delFile(${jsq(p)},false)">${tr('deleteFile')}</button>`;let displayName=d.searching?p:f.name;rows+=`<tr><td><a href="javascript:void(0)" onclick="${nameClick}">${f.dir?tr('folder'):tr('file')}${esc(displayName)}</a></td><td>${esc(f.size)}</td><td>${esc(f.mtime)}</td><td>${ops}</td></tr>`}rows+='</tbody></table></div>';if(!d.files.length)rows=`<div class="hint">${d.searching?tr('noSearchResults'):tr('noFiles')}</div>`;qs('#files').innerHTML=(d.searching?`<div class="hint">${tr('searchResults')}：${esc(d.query||'')}</div>`:'')+rows}
function renderTrash(d){qs('#path').textContent=tr('trash');let rows=`<div class="actions"><button class="btn danger" onclick="emptyTrash()">${tr('emptyTrash')}</button></div><div class="files-wrap"><table class="files"><thead><tr><th>${tr('name')}</th><th>${tr('size')}</th><th>${tr('originalPath')}</th><th>${tr('deletedAt')}</th><th>${tr('actions')}</th></tr></thead><tbody>`;for(let f of d.files||[]){let ops=`<button class="btn light" onclick="restoreTrash(${jsq(f.id)})">${tr('restore')}</button> <button class="btn danger" onclick="deleteTrash(${jsq(f.id)})">${tr('permanentDelete')}</button>`;rows+=`<tr><td>${f.dir?tr('folder'):tr('file')}${esc(f.name)}</td><td>${esc(f.size)}</td><td>${esc(f.path)}</td><td>${esc(f.deleted_at)}</td><td>${ops}</td></tr>`}rows+='</tbody></table></div>';qs('#files').innerHTML=(d.files&&d.files.length)?rows:`<div class="hint">${tr('trashEmpty')}</div>`}
async function loadFiles(path=''){let ev=clickEvent();if(ev)showLoading('#files','正在加载文件...');await withButtonLoading(ev?ev.currentTarget:null,async()=>{try{let d=await api('/api/files?path='+encodeURIComponent(path));currentPath=d.path??path;renderFiles(d)}catch(e){qs('#files').textContent=e.message}})}
async function loadTrash(){showLoading('#files','正在打开回收站...');await withButtonLoading(clickEvent()?.currentTarget,async()=>{try{let d=await api('/api/trash');renderTrash(d)}catch(e){qs('#files').textContent=e.message}})}
async function searchFiles(){let q=(qs('#fileSearch')?qs('#fileSearch').value:'').trim();if(!q)return loadFiles(currentPath);try{qs('#files').innerHTML=`<div class="hint">${tr('searching')}...</div>`;let d=await api('/api/files?path='+encodeURIComponent(currentPath)+'&q='+encodeURIComponent(q));d.searching=true;renderFiles(d)}catch(e){qs('#files').textContent=e.message}}
function clearFileSearch(){if(qs('#fileSearch'))qs('#fileSearch').value='';loadFiles(currentPath)}
function play(p,kind){let src=fileUrl('/download',p);let viewer=qs('#viewer');if(kind==='video')viewer.innerHTML=`<video controls autoplay playsinline preload="metadata" src="${src}" onerror="toast(tr('videoError'))"></video>`;else if(kind==='audio')viewer.innerHTML=`<audio controls autoplay preload="metadata" src="${src}" onerror="toast(tr('audioError'))"></audio>`;else location.href=src;viewer.scrollIntoView({behavior:'smooth',block:'nearest'})}
async function delFile(p,isDir=false){if(!confirm(isDir?tr('confirmDeleteFolder'):tr('confirmDeleteFile')))return;try{await api('/api/file?path='+encodeURIComponent(p),{method:'DELETE'});toast(tr('deletedToTrash'));loadFiles(currentPath);loadDirs();refresh()}catch(e){toast(e.message)}}
async function restoreTrash(id){if(!confirm(tr('confirmRestore')))return;try{await api('/api/trash/'+encodeURIComponent(id)+'/restore',{method:'POST'});toast(tr('restored'));loadTrash();loadDirs();refresh()}catch(e){toast(e.message)}}
async function deleteTrash(id){if(!confirm(tr('confirmPermanentDelete')))return;try{await api('/api/trash/'+encodeURIComponent(id),{method:'DELETE'});toast(tr('permanentlyDeleted'));loadTrash();refresh()}catch(e){toast(e.message)}}
async function emptyTrash(){if(!confirm(tr('confirmEmptyTrash')))return;try{await api('/api/trash',{method:'DELETE'});toast(tr('trashEmptied'));loadTrash();refresh()}catch(e){toast(e.message)}}
async function renameFile(p){let oldName=String(p||'').split('/').pop();let name=prompt(tr('renamePrompt'),oldName);if(name===null)return;name=name.trim();if(!name||name===oldName)return;try{await api('/api/file/rename',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:p,name})});toast(tr('renamed'));loadFiles(currentPath);loadDirs()}catch(e){toast(e.message)}}
async function createFolder(){let name=qs('#folderName').value.trim();if(!name)return toast(tr('enterFolderName'));try{await api('/api/folder',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:currentPath,name})});qs('#folderName').value='';toast(tr('folderCreated'));loadFiles(currentPath);loadDirs()}catch(e){toast(e.message)}}
async function transcode(p){if(!confirm('转成手机兼容 MP4 可能需要一些时间，并会占用额外空间，确定开始？'))return;try{await api('/api/transcode',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:p})});toast('已加入转码任务');refresh()}catch(e){toast(e.message)}}
async function changePass(){try{await api('/api/password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({old:qs('#oldpass').value,new:qs('#newpass').value})});qs('#oldpass').value='';qs('#newpass').value='';toast(tr('passChanged'))}catch(e){toast(e.message)}}
async function changeLanguage(lang){try{let d=await api('/api/language',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({language:lang})});LANG=d.language||lang;document.body.dataset.lang=LANG;applyI18n();renderChangelog();if(usersCache.length)renderUsers();refresh();loadFiles(currentPath);loadUsers()}catch(e){toast(e.message)}}

function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function deviceHtml(devs=[]){if(!devs.length)return '<div class="hint">无在线设备</div>';return `<div class="device-list">${devs.map(d=>`<div class="device-item"><div class="device-top"><span class="device-ip">${esc(d.ip||'-')}</span>${d.current?'<span class="device-current">当前</span>':''}</div><div class="device-meta">${esc(d.user_agent||'未知设备')}</div><div class="device-meta">登录：${esc(d.created_at||'-')} · 活跃：${esc(d.last_seen||'-')}</div>${d.current?'':`<button class="btn danger" onclick="kickDevice('${esc(d.id||d.sid)}')">退出设备</button>`}</div>`).join('')}</div>`}
function userMatchesQuery(u,q){if(!q)return true;let text=[u.username,u.role,u.usage,u.quota,u.speed_limit,u.expires_label,u.created_at,(u.allowed_roots||[]).join(' '),(u.devices||[]).map(d=>[d.ip,d.user_agent].join(' ')).join(' ')].join(' ').toLowerCase();return text.includes(q)}
function updateUserSearch(value){usersQuery=value;usersPage=1;renderUsers();setTimeout(()=>{let el=qs('#userSearch');if(el){el.focus();el.setSelectionRange(el.value.length,el.value.length)}},0)}
function renderUsers(){let q=usersQuery.trim().toLowerCase();usersPageSize=Number(qs('#usersPageSize')?qs('#usersPageSize').value:usersPageSize)||10;let filtered=usersCache.filter(u=>userMatchesQuery(u,q));let total=usersCache.length;let pages=Math.max(1,Math.ceil(filtered.length/usersPageSize));usersPage=Math.min(Math.max(1,usersPage),pages);let start=(usersPage-1)*usersPageSize;let list=filtered.slice(start,start+usersPageSize);let rows=`<div class="user-list-head"><div class="file-search" style="margin:0;flex:1"><input id="userSearch" value="${esc(usersQuery)}" placeholder="${esc(tr('userSearchPlaceholder'))}" oninput="updateUserSearch(this.value)"><select id="usersPageSize" onchange="usersPageSize=Number(this.value)||10;usersPage=1;renderUsers()"><option value="10" ${usersPageSize===10?'selected':''}>10</option><option value="30" ${usersPageSize===30?'selected':''}>30</option><option value="50" ${usersPageSize===50?'selected':''}>50</option><option value="100" ${usersPageSize===100?'selected':''}>100</option></select></div><div class="hint">${tr('userCount')}：${total} · ${tr('filteredCount')}：${filtered.length} · ${tr('pageInfo')}：${usersPage} / ${pages}</div></div><table class="users-table"><thead><tr><th>${tr('name')}</th><th>${tr('role')}</th><th>${tr('usedQuota')}</th><th>${tr('speedLimit')}</th><th>${tr('expiryTime')}</th><th>${tr('allowedFolders')}</th><th>${tr('onlineDevices')}</th><th>${tr('createdAt')}</th><th>${tr('actions')}</th></tr></thead><tbody>`;for(let u of list){let isAdmin=u.role==='admin';let roots=(u.allowed_roots||[]).join(', ')||tr('allFolders');rows+=`<tr><td>${esc(u.username)}</td><td><span class="role-pill ${isAdmin?'admin':''}">${isAdmin?tr('admin'):tr('normalUser')}</span></td><td>${esc(u.usage||'-')} / ${esc(u.quota||tr('unlimited'))}</td><td>${esc(u.speed_limit||'*')}</td><td>${esc(u.expires_label||tr('permanent'))}${u.expired?` <span class="badge error">${tr('expired')}</span>`:''}</td><td style="max-width:260px;word-break:break-all">${esc(roots)}</td><td>${deviceHtml(u.devices||[])}</td><td>${esc(u.created_at||'-')}</td><td><button class="btn light" onclick="resetUserPass('${esc(u.username)}')">${tr('changePass')}</button> ${u.username==='admin'?'':`<button class="btn light" onclick="editLimits('${esc(u.username)}','${u.quota_bytes||0}','${u.speed_limit_bytes||0}',\`${esc(roots===tr('allFolders')?'':roots)}\`,'${esc(u.expires_at||'')}')">${tr('limitsFolders')}</button> <button class="btn light" onclick="toggleRole('${esc(u.username)}','${isAdmin?'user':'admin'}')">${isAdmin?tr('setUser'):tr('setAdmin')}</button> <button class="btn danger" onclick="deleteUser('${esc(u.username)}')">${tr('deleteFile')}</button>`}</td></tr>`}rows+='</tbody></table>';rows+=`<div class="pager"><button class="btn light" ${usersPage<=1?'disabled':''} onclick="usersPage--;renderUsers()">${tr('prevPage')}</button><span class="hint">${usersPage} / ${pages}</span><button class="btn light" ${usersPage>=pages?'disabled':''} onclick="usersPage++;renderUsers()">${tr('nextPage')}</button></div>`;qs('#usersBox').innerHTML=rows}
async function loadUsers(){let ev=clickEvent();await withButtonLoading(ev?ev.currentTarget:null,async()=>{try{let d=await api('/api/users');qs('#userPanel').style.display='block';if(qs('#navUsers'))qs('#navUsers').style.display='block';if(qs('#registrationEnabled'))qs('#registrationEnabled').value=d.registration_enabled?'1':'0';if(qs('#userProxyEnabled'))qs('#userProxyEnabled').value=d.user_proxy_enabled?'1':'0';if(qs('#serverTimeMode'))qs('#serverTimeMode').value=d.server_time_mode||'local';let rd=d.registration_defaults||{};if(qs('#registrationQuota'))qs('#registrationQuota').value=rd.quota||'0';if(qs('#registrationSpeed'))qs('#registrationSpeed').value=rd.speed_limit||'*';if(qs('#registrationExpires'))qs('#registrationExpires').value=rd.expires_at||'';if(qs('#registrationRoots'))qs('#registrationRoots').value=rd.allowed_roots||'_users/{username}';usersCache=d.users||[];renderUsers()}catch(e){if(qs('#userPanel'))qs('#userPanel').style.display='none';if(qs('#navUsers'))qs('#navUsers').style.display='none';if(qs('#userPage')&&qs('#userPage').classList.contains('active'))showPage('main')}})}
async function saveAdminFeatureSettings(){await withButtonLoading(clickEvent()?.currentTarget,async()=>{try{let enabled=qs('#registrationEnabled')&&qs('#registrationEnabled').value==='1';let user_proxy_enabled=qs('#userProxyEnabled')&&qs('#userProxyEnabled').value==='1';let server_time_mode=qs('#serverTimeMode')?qs('#serverTimeMode').value:'local';let defaults={quota:qs('#registrationQuota')?qs('#registrationQuota').value.trim():'0',speed_limit:qs('#registrationSpeed')?qs('#registrationSpeed').value.trim():'*',expires_at:qs('#registrationExpires')?qs('#registrationExpires').value.trim():'',allowed_roots:qs('#registrationRoots')?qs('#registrationRoots').value.trim():'_users/{username}'};await api('/api/registration',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled,user_proxy_enabled,server_time_mode,defaults})});toast(tr('registrationSaved'));loadUsers();refresh();loadDownloadSettings()}catch(e){toast(e.message)}})}
async function saveRegistrationSetting(){return saveAdminFeatureSettings()}
async function kickDevice(id){if(!confirm('确定退出这个设备？'))return;try{await api('/api/sessions/'+encodeURIComponent(id),{method:'DELETE'});toast('设备已退出');loadUsers()}catch(e){toast(e.message)}}
async function addUser(){let username=qs('#newUser').value.trim();let password=qs('#newUserPass').value;let role=qs('#newUserRole').value;let quota=qs('#newUserQuota').value;let speed_limit=qs('#newUserSpeed').value;let expires_at=qs('#newUserExpires').value;let allowed_roots=qs('#newUserRoots').value;try{await api('/api/users',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password,role,quota,speed_limit,expires_at,allowed_roots})});qs('#newUser').value='';qs('#newUserPass').value='';qs('#newUserQuota').value='';qs('#newUserSpeed').value='';qs('#newUserExpires').value='';qs('#newUserRoots').value='';toast('用户已添加');loadUsers()}catch(e){toast(e.message)}}
async function editLimits(username,quotaBytes,speedBytes,roots,expiresAt=''){let quota=prompt('设置 '+username+' 的空间额度，例如 500M、2G，0 表示无限制', quotaBytes&&quotaBytes!=='0'?quotaBytes:'0');if(quota===null)return;let speed_limit=prompt('设置 '+username+' 的下载限速，例如 500K、2M，* 表示不限速', speedBytes&&speedBytes!=='0'?speedBytes:'*');if(speed_limit===null)return;let expires_at=prompt('设置 '+username+' 的到期时间，例如 2026-12-31，留空表示永久有效', expiresAt||'');if(expires_at===null)return;let allowed_roots=prompt('设置可访问目录，多个用英文逗号分隔。必须是下载根目录下的相对路径；填 * 表示全部目录', roots||('_users/'+username));if(allowed_roots===null)return;try{await api('/api/users/'+encodeURIComponent(username)+'/limits',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({quota,speed_limit,expires_at,allowed_roots})});toast('额度、限速、到期时间和目录已更新');loadUsers();refresh()}catch(e){toast(e.message)}}
async function resetUserPass(username){let password=prompt('输入 '+username+' 的新密码，至少 6 位');if(!password)return;try{await api('/api/users/'+encodeURIComponent(username)+'/password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password})});toast('密码已修改')}catch(e){toast(e.message)}}
async function toggleRole(username,role){if(!confirm('确定修改 '+username+' 的角色？'))return;try{await api('/api/users/'+encodeURIComponent(username)+'/role',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({role})});toast('角色已修改');loadUsers()}catch(e){toast(e.message)}}
async function deleteUser(username){if(!confirm('确定删除用户 '+username+'？不会删除服务器文件。'))return;try{await api('/api/users/'+encodeURIComponent(username),{method:'DELETE'});toast('用户已删除');loadUsers()}catch(e){toast(e.message)}}

async function loadTrackerInfo(){try{let d=await api('/api/trackers');if(qs('#trackerPanel'))qs('#trackerPanel').style.display='block';qs('#trackerUrl').value=d.url||'';qs('#trackerSource').textContent=d.url||'-';qs('#trackerUpdated').textContent=d.updated_at||'未更新';qs('#trackerCount').textContent=d.count??'-'}catch(e){if(qs('#trackerPanel'))qs('#trackerPanel').style.display='none'}}
async function updateTrackers(){let url=qs('#trackerUrl').value.trim();if(!url)return toast('请输入 tracker .txt 地址');if(!confirm('更新 tracker 会重启下载服务，正在下载的任务通常会自动恢复，确定更新？'))return;try{let d=await api('/api/trackers/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url})});toast('Tracker 已更新：'+d.count+' 个');loadTrackerInfo();refresh()}catch(e){toast(e.message)}}
async function loadDownloadSettings(){try{let d=await api('/api/settings');if(qs('#downloadSettingsPanel'))qs('#downloadSettingsPanel').style.display='block';if(qs('#btStreamPrioritize'))qs('#btStreamPrioritize').value=d.bt_stream_prioritize?'1':'0';if(qs('#btStreamPrioritize'))qs('#btStreamPrioritize').disabled=!d.is_admin;if(qs('#videoProxyEnabled'))qs('#videoProxyEnabled').value=d.video_proxy_enabled?'1':'0';if(qs('#videoProxyMode'))qs('#videoProxyMode').value=d.video_proxy_mode||'geo';if(qs('#videoProxyType'))qs('#videoProxyType').value=d.video_proxy_type||'http';if(qs('#videoProxyHost'))qs('#videoProxyHost').value=d.video_proxy_host||'';if(qs('#videoProxyPort'))qs('#videoProxyPort').value=d.video_proxy_port||'';if(qs('#videoProxyUsername'))qs('#videoProxyUsername').value=d.video_proxy_username||'';if(qs('#videoProxyPassword'))qs('#videoProxyPassword').value=d.video_proxy_password||'';if(qs('#ytdlpFirmwareBox'))qs('#ytdlpFirmwareBox').style.display=d.is_admin?'flex':'none';if(d.is_admin)loadYtdlpFirmware()}catch(e){if(qs('#downloadSettingsPanel'))qs('#downloadSettingsPanel').style.display='none'}}
async function saveDownloadSettings(){await withButtonLoading(clickEvent()?.currentTarget,async()=>{try{let enabled=qs('#btStreamPrioritize').value==='1';let video_proxy_enabled=qs('#videoProxyEnabled')&&qs('#videoProxyEnabled').value==='1';let video_proxy_mode=qs('#videoProxyMode')?qs('#videoProxyMode').value:'geo';let video_proxy_type=qs('#videoProxyType')?qs('#videoProxyType').value:'http';let video_proxy_host=qs('#videoProxyHost')?qs('#videoProxyHost').value.trim():'';let video_proxy_port=qs('#videoProxyPort')?qs('#videoProxyPort').value.trim():'';let video_proxy_username=qs('#videoProxyUsername')?qs('#videoProxyUsername').value.trim():'';let video_proxy_password=qs('#videoProxyPassword')?qs('#videoProxyPassword').value:'';await api('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({bt_stream_prioritize:enabled,video_proxy_enabled,video_proxy_mode,video_proxy_type,video_proxy_host,video_proxy_port,video_proxy_username,video_proxy_password})});toast(tr('settingsSaved'));loadDownloadSettings()}catch(e){toast(e.message)}})}
async function loadYtdlpFirmware(){let status=qs('#ytdlpFirmwareStatus');let clicked=!!clickEvent();if(status)status.textContent=tr('firmwareChecking');await withButtonLoading(clickEvent()?.currentTarget,async()=>{try{let d=await api('/api/video/firmware');let version=d.version||'未知';if(qs('#ytdlpVersion'))qs('#ytdlpVersion').textContent=version;if(status)status.textContent=d.error||`${tr('firmwareChecked')}${version}`;if(clicked)toast(`${tr('firmwareChecked')}${version}`)}catch(e){if(status)status.textContent=e.message;toast(e.message)}})}
async function updateYtdlpFirmware(){if(!confirm('确定更新视频下载固件？更新过程中视频下载解析可能短暂受影响。'))return;let status=qs('#ytdlpFirmwareStatus');if(status)status.textContent=tr('firmwareUpdating');await withButtonLoading(clickEvent()?.currentTarget,async()=>{try{let d=await api('/api/video/firmware/update',{method:'POST'});if(qs('#ytdlpVersion'))qs('#ytdlpVersion').textContent=d.version||'未知';if(status)status.textContent=d.message||tr('firmwareUpdated');toast(d.message||tr('firmwareUpdated'))}catch(e){if(status)status.textContent=e.message;toast(e.message)}})}
async function testVideoProxy(){let result=qs('#proxyTestResult');if(result)result.textContent=tr('proxyTesting');await withButtonLoading(clickEvent()?.currentTarget,async()=>{try{let body={video_proxy_type:qs('#videoProxyType')?qs('#videoProxyType').value:'http',video_proxy_host:qs('#videoProxyHost')?qs('#videoProxyHost').value.trim():'',video_proxy_port:qs('#videoProxyPort')?qs('#videoProxyPort').value.trim():'',video_proxy_username:qs('#videoProxyUsername')?qs('#videoProxyUsername').value.trim():'',video_proxy_password:qs('#videoProxyPassword')?qs('#videoProxyPassword').value:''};let d=await api('/api/proxy/test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});let msg=(d.message||tr('proxyTestOk'))+(d.ip?' · IP '+d.ip:'')+(d.elapsed?' · '+d.elapsed+'s':'');if(result)result.textContent=msg;toast(msg)}catch(e){if(result)result.textContent=e.message;toast(e.message)}})}
async function loadUpdateStatus(){try{let d=await api('/api/update/status');if(qs('#updatePanel'))qs('#updatePanel').style.display='block';qs('#updateStatus').textContent=d.message||'-';qs('#updateTime').textContent=d.updated_at||'-'}catch(e){if(qs('#updatePanel'))qs('#updatePanel').style.display='none'}}
async function uploadUpdate(){let f=qs('#updateFile').files[0];if(!f)return toast('请选择更新包');if(!confirm('确定上传并更新版本？容器会自动重建并重启，期间页面可能短暂断开。'))return;let fd=new FormData();fd.append('update',f);try{let d=await api('/api/update/upload',{method:'POST',body:fd});toast(d.message||'更新已开始');loadUpdateStatus();setTimeout(loadUpdateStatus,5000);setTimeout(()=>location.reload(),45000)}catch(e){toast(e.message)}}
bindButtonEffects();applyI18n();renderChangelog();refresh();loadFiles();loadDirs();loadVideoCookiesStatus();loadTrackerInfo();loadDownloadSettings();loadUsers();loadUpdateStatus();setInterval(refresh,2500);setInterval(loadUpdateStatus,10000);
</script>
{% endif %}
</body></html>'''

from flask import render_template_string

@APP.route('/')
def index():
    is_authed = authed()
    reg_enabled = registration_enabled()
    captcha_text = captcha_new() if (not is_authed and reg_enabled) else ''
    return render_template_string(HTML, authed=is_authed, needs_disclaimer=is_authed and not disclaimer_accepted(), error='', register_error='', registration_enabled=reg_enabled, captcha_text=captcha_text, version=APP_VERSION, lang=user_language() if is_authed else 'zh')

@APP.post('/login')
def login():
    cfg = ensure_users_config()
    username = request.form.get('username', '').strip()
    user = cfg.get('users', {}).get(username)
    if user and check_password_hash(user.get('password_hash', ''), request.form.get('password', '')):
        if user.get('role') != 'admin' and user_expired(username):
            reg_enabled = registration_enabled()
            return render_template_string(HTML, authed=False, needs_disclaimer=False, error='账户已到期，请联系管理员', register_error='', registration_enabled=reg_enabled, captcha_text=captcha_new() if reg_enabled else '', version=APP_VERSION, lang='zh')
        session['ok'] = True
        session['user'] = username
        session['sid'] = create_login_session(username)
        return redirect('/')
    reg_enabled = registration_enabled()
    return render_template_string(HTML, authed=False, needs_disclaimer=False, error='账户或密码错误', register_error='', registration_enabled=reg_enabled, captcha_text=captcha_new() if reg_enabled else '', version=APP_VERSION, lang='zh')


@APP.post('/register')
def register():
    reg_enabled = registration_enabled()
    if not reg_enabled:
        return render_template_string(HTML, authed=False, needs_disclaimer=False, error='注册已关闭', register_error='', registration_enabled=False, captcha_text='', version=APP_VERSION, lang='zh'), 403
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '')
    confirm = request.form.get('confirm', '')
    lang = 'en' if str(request.form.get('language') or '').lower() == 'en' else 'zh'
    error = ''
    if not captcha_valid(request.form.get('captcha', '')):
        error = '验证码错误或已过期'
    elif not valid_username(username):
        error = '用户名需 3-32 位，只能包含字母数字下划线横线，且不能以横线开头'
    elif len(password) < 6:
        error = '密码至少 6 位'
    elif password != confirm:
        error = '两次输入的密码不一致'
    else:
        cfg = ensure_users_config()
        if username in cfg.get('users', {}):
            error = '用户已存在'
        else:
            defaults = registration_defaults()
            try:
                quota_bytes = parse_size_to_bytes(defaults.get('quota') or '0')
                speed_limit_bytes = parse_speed_to_bytes(defaults.get('speed_limit') or '*')
                expires_at = normalize_expiry(defaults.get('expires_at') or '')
            except ValueError as e:
                error = '注册默认设置错误：' + str(e)
                return render_template_string(HTML, authed=False, needs_disclaimer=False, error='', register_error=error, registration_enabled=True, captcha_text=captcha_new(), version=APP_VERSION, lang=lang), 400
            roots = []
            for root in str(defaults.get('allowed_roots') or '_users/{username}').replace('\n', ',').split(','):
                root = root.strip().strip('/').replace('{username}', username)
                if not root:
                    continue
                if root != '*' and '..' in Path(root).parts:
                    error = '注册默认目录不能包含 ..'
                    return render_template_string(HTML, authed=False, needs_disclaimer=False, error='', register_error=error, registration_enabled=True, captcha_text=captcha_new(), version=APP_VERSION, lang=lang), 400
                roots.append(root)
            if not roots:
                roots = [f'_users/{username}']
            cfg['users'][username] = {
                'password_hash': generate_password_hash(password),
                'role': 'user',
                'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                'quota_bytes': quota_bytes,
                'speed_limit_bytes': speed_limit_bytes,
                'expires_at': expires_at,
                'allowed_roots': roots,
                'language': lang,
                'disclaimer_accepted_at': '',
            }
            save_config(cfg)
            for root in roots:
                if root != '*':
                    (DOWNLOADS / root).mkdir(parents=True, exist_ok=True)
            session['ok'] = True
            session['user'] = username
            session['sid'] = create_login_session(username)
            return redirect('/')
    return render_template_string(HTML, authed=False, needs_disclaimer=False, error='', register_error=error, registration_enabled=True, captcha_text=captcha_new(), version=APP_VERSION, lang=lang), 400

@APP.post('/api/disclaimer/accept')
def accept_disclaimer():
    err = require_auth_json()
    if err: return err
    cfg = ensure_users_config()
    username = current_user()
    if username not in cfg.get('users', {}):
        return jsonify({'ok': False, 'error': '用户不存在'}), 404
    cfg['users'][username]['disclaimer_accepted_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
    save_config(cfg)
    return jsonify({'ok': True})


@APP.post('/api/language')
def language_update():
    err = require_auth_json()
    if err: return err
    data = request.json or {}
    lang = 'en' if str(data.get('language') or '').lower() == 'en' else 'zh'
    cfg = ensure_users_config()
    cfg['users'][current_user()]['language'] = lang
    save_config(cfg)
    return jsonify({'ok': True, 'language': lang})

@APP.route('/logout')
def logout():
    remove_login_session(session.get('sid'))
    session.clear()
    return redirect('/')

@APP.post('/api/password')
def password():
    err = require_auth_json()
    if err: return err
    data = request.json or {}
    cfg = ensure_users_config()
    username = current_user()
    user = cfg.get('users', {}).get(username)
    if not user or not check_password_hash(user.get('password_hash', ''), data.get('old', '')):
        return jsonify({'ok': False, 'error': '旧密码不正确'}), 400
    if len(data.get('new', '')) < 6:
        return jsonify({'ok': False, 'error': '新密码至少 6 位'}), 400
    user['password_hash'] = generate_password_hash(data['new'])
    save_config(cfg)
    return jsonify({'ok': True})

@APP.get('/api/users')
def users_list():
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    cfg = ensure_users_config()
    users = []
    for name, u in sorted(cfg.get('users', {}).items()):
        ensure_user_defaults(name); users.append({'username': name, 'role': u.get('role', 'user'), 'created_at': u.get('created_at', ''), 'quota_bytes': int(u.get('quota_bytes') or 0), 'quota': fmt_bytes(u.get('quota_bytes') or 0) if int(u.get('quota_bytes') or 0) else '无限制', 'usage': fmt_bytes(user_usage_bytes(name)), 'speed_limit_bytes': int(u.get('speed_limit_bytes') or 0), 'speed_limit': fmt_speed_limit(u.get('speed_limit_bytes') or 0), 'expires_at': u.get('expires_at') or '', 'expires_label': fmt_expiry(name), 'expired': user_expired(name), 'devices': user_devices(name), 'allowed_roots': u.get('allowed_roots') or ([] if u.get('role') == 'admin' else [f'_users/{name}'])})
    return jsonify({'ok': True, 'users': users, 'registration_enabled': registration_enabled(), 'registration_defaults': registration_defaults(), 'user_proxy_enabled': bool(cfg.get('user_proxy_enabled')), 'server_time_mode': cfg.get('server_time_mode') or 'local'})


@APP.post('/api/registration')
def registration_update():
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    data = request.json or {}
    defaults = data.get('defaults') if isinstance(data.get('defaults'), dict) else {}
    quota = str(defaults.get('quota') or '0').strip()
    speed_limit = str(defaults.get('speed_limit') or '*').strip()
    expires_at = str(defaults.get('expires_at') or '').strip()
    allowed_roots = str(defaults.get('allowed_roots') or '_users/{username}').strip()
    try:
        parse_size_to_bytes(quota)
        parse_speed_to_bytes(speed_limit)
        normalize_expiry(expires_at)
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    for root in allowed_roots.replace('\n', ',').split(','):
        root = root.strip().strip('/').replace('{username}', 'testuser')
        if root and root != '*' and '..' in Path(root).parts:
            return jsonify({'ok': False, 'error': '注册默认目录不能包含 ..'}), 400
    cfg = ensure_users_config()
    server_time_mode = str(data.get('server_time_mode') or 'local')
    if server_time_mode not in TIMEZONE_OPTIONS:
        server_time_mode = 'local'
    cfg['registration_enabled'] = bool(data.get('enabled'))
    cfg['user_proxy_enabled'] = bool(data.get('user_proxy_enabled'))
    cfg['server_time_mode'] = server_time_mode
    cfg['registration_defaults'] = {'quota': quota, 'speed_limit': speed_limit, 'expires_at': normalize_expiry(expires_at), 'allowed_roots': allowed_roots}
    save_config(cfg)
    return jsonify({'ok': True, 'registration_enabled': bool(cfg.get('registration_enabled')), 'registration_defaults': registration_defaults()})

@APP.post('/api/users')
def users_add():
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    data = request.json or {}
    username = (data.get('username') or '').strip()
    password = data.get('password') or ''
    role = 'admin' if data.get('role') == 'admin' else 'user'
    try:
        quota_bytes = parse_size_to_bytes(data.get('quota') or data.get('quota_bytes') or '0')
        speed_limit_bytes = parse_speed_to_bytes(data.get('speed_limit') or data.get('speed_limit_bytes') or '*')
        expires_at = normalize_expiry(data.get('expires_at') or data.get('expires') or '')
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    roots = [x.strip().strip('/') for x in str(data.get('allowed_roots') or '').replace('\n', ',').split(',') if x.strip()]
    if role != 'admin' and not roots:
        roots = [f'_users/{username}']
    if not valid_username(username):
        return jsonify({'ok': False, 'error': '用户名需 3-32 位，只能包含字母数字下划线横线，且不能以横线开头'}), 400
    if len(password) < 6:
        return jsonify({'ok': False, 'error': '密码至少 6 位'}), 400
    cfg = ensure_users_config()
    if username in cfg.get('users', {}):
        return jsonify({'ok': False, 'error': '用户已存在'}), 400
    cfg['users'][username] = {'password_hash': generate_password_hash(password), 'role': role, 'created_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'quota_bytes': quota_bytes, 'speed_limit_bytes': 0 if role == 'admin' else speed_limit_bytes, 'expires_at': '' if role == 'admin' else expires_at, 'allowed_roots': [] if role == 'admin' else roots, 'language': 'zh'}
    save_config(cfg)
    return jsonify({'ok': True})

@APP.post('/api/users/<username>/password')
def users_change_password(username):
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    data = request.json or {}
    password = data.get('password') or ''
    if len(password) < 6:
        return jsonify({'ok': False, 'error': '密码至少 6 位'}), 400
    cfg = ensure_users_config()
    if username not in cfg.get('users', {}):
        return jsonify({'ok': False, 'error': '用户不存在'}), 404
    cfg['users'][username]['password_hash'] = generate_password_hash(password)
    save_config(cfg)
    return jsonify({'ok': True})

@APP.post('/api/users/<username>/role')
def users_change_role(username):
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    data = request.json or {}
    role = 'admin' if data.get('role') == 'admin' else 'user'
    try:
        quota_bytes = parse_size_to_bytes(data.get('quota') or data.get('quota_bytes') or '0')
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    roots = [x.strip().strip('/') for x in str(data.get('allowed_roots') or '').replace('\n', ',').split(',') if x.strip()]
    if role != 'admin' and not roots:
        roots = [f'_users/{username}']
    cfg = ensure_users_config()
    if username not in cfg.get('users', {}):
        return jsonify({'ok': False, 'error': '用户不存在'}), 404
    if username == 'admin' and role != 'admin':
        return jsonify({'ok': False, 'error': '不能取消 admin 管理员权限'}), 400
    cfg['users'][username]['role'] = role
    save_config(cfg)
    return jsonify({'ok': True})

@APP.post('/api/users/<username>/limits')
def users_change_limits(username):
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    data = request.json or {}
    cfg = ensure_users_config()
    if username not in cfg.get('users', {}):
        return jsonify({'ok': False, 'error': '用户不存在'}), 404
    if cfg['users'][username].get('role') == 'admin':
        return jsonify({'ok': False, 'error': '管理员不限制目录和额度'}), 400
    try:
        quota_bytes = parse_size_to_bytes(data.get('quota') or data.get('quota_bytes') or '0')
        speed_limit_bytes = parse_speed_to_bytes(data.get('speed_limit') or data.get('speed_limit_bytes') or '*')
        expires_at = normalize_expiry(data.get('expires_at') or data.get('expires') or '')
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    roots = [x.strip().strip('/') for x in str(data.get('allowed_roots') or '').replace('\n', ',').split(',') if x.strip()]
    clean = []
    for r in roots:
        if r == '*':
            clean.append('*')
            continue
        if '..' in Path(r).parts:
            return jsonify({'ok': False, 'error': '目录不能包含 ..'}), 400
        clean.append(r)
    if not clean:
        clean = [f'_users/{username}']
    cfg['users'][username]['quota_bytes'] = quota_bytes
    cfg['users'][username]['speed_limit_bytes'] = speed_limit_bytes
    cfg['users'][username]['expires_at'] = expires_at
    cfg['users'][username]['allowed_roots'] = clean
    save_config(cfg)
    for r in clean:
        if r != '*':
            (DOWNLOADS / r).mkdir(parents=True, exist_ok=True)
    return jsonify({'ok': True})

@APP.delete('/api/sessions/<sid>')
def sessions_delete(sid):
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    data = read_sessions()
    if sid not in data:
        return jsonify({'ok': False, 'error': '设备不存在或已离线'}), 404
    if sid == session.get('sid'):
        return jsonify({'ok': False, 'error': '不能在这里退出当前设备，请点右上角退出'}), 400
    del data[sid]
    write_sessions(data)
    return jsonify({'ok': True})

@APP.delete('/api/users/<username>')
def users_delete(username):
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    if username == 'admin' or username == current_user():
        return jsonify({'ok': False, 'error': '不能删除 admin 或当前登录用户'}), 400
    cfg = ensure_users_config()
    if username not in cfg.get('users', {}):
        return jsonify({'ok': False, 'error': '用户不存在'}), 404
    del cfg['users'][username]
    save_config(cfg)
    remove_user_sessions(username)
    return jsonify({'ok': True})

@APP.post('/api/add')
def add():
    err = require_auth_json()
    if err: return err
    quota_err = ensure_quota_available()
    if quota_err: return quota_err
    data = request.json or {}
    urls = [u.strip() for u in data.get('urls', '').splitlines() if u.strip()]
    if not urls:
        return jsonify({'ok': False, 'error': '请输入下载链接'}), 400
    kind = data.get('kind', 'auto')
    remark = str(data.get('remark') or '').strip()
    try:
        save_dir = save_dir_from_request(data.get('save_path') or data.get('dir') or '')
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    added = []
    for url in urls:
        is_hls = kind == 'hls' or (kind == 'auto' and '.m3u8' in url.lower().split('?')[0])
        if is_hls:
            name = secure_filename(data.get('name') or '') or f'hls-{int(time.time())}.mp4'
            if not Path(name).suffix:
                name += '.mp4'
            rel_name = str((save_dir / name).relative_to(DOWNLOADS)) if save_dir != DOWNLOADS else name
            job = {'id': str(uuid.uuid4()), 'type': 'hls', 'name': rel_name, 'url': url, 'remark': remark, 'status': 'waiting', 'progress': 0, 'size': 0, 'speed': '', 'message': '等待开始', 'created_at': time.time(), 'path': rel_name}
            jobs = read_hls_jobs(); jobs.append(job); write_hls_jobs(jobs)
            threading.Thread(target=hls_worker, args=(job['id'], url, name, str(save_dir)), daemon=True).start()
            added.append(job['id'])
        else:
            opts = {'dir': str(save_dir)}
            if stream_prioritize_enabled() and (url.startswith('magnet:') or kind == 'bt'):
                opts['bt-prioritize-piece'] = 'head=4M,tail=4M'
            if not is_admin():
                opts['max-download-limit'] = aria_speed_option(current_user())
            name = secure_filename(data.get('name') or '')
            if name:
                opts['out'] = name
            gid = aria('aria2.addUri', [[url], opts])
            remember_task_source(gid, url, remark)
            added.append(gid)
    return jsonify({'ok': True, 'added': added})

@APP.post('/api/torrent')
def torrent():
    err = require_auth_json()
    if err: return err
    quota_err = ensure_quota_available()
    if quota_err: return quota_err
    f = request.files.get('torrent')
    if not f:
        return jsonify({'ok': False, 'error': '请选择种子文件'}), 400
    b64 = base64.b64encode(f.read()).decode()
    try:
        save_dir = save_dir_from_request(request.form.get('save_path') or request.form.get('dir') or '')
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    opts = {'dir': str(save_dir)}
    if stream_prioritize_enabled():
        opts['bt-prioritize-piece'] = 'head=4M,tail=4M'
    if not is_admin():
        opts['max-download-limit'] = aria_speed_option(current_user())
    gid = aria('aria2.addTorrent', [b64, [], opts])
    return jsonify({'ok': True, 'gid': gid})


@APP.post('/api/video')
def video_download():
    err = require_auth_json()
    if err: return err
    quota_err = ensure_quota_available()
    if quota_err: return quota_err
    data = request.json or {}
    urls = [u.strip() for u in str(data.get('urls') or '').splitlines() if u.strip()]
    if not urls:
        return jsonify({'ok': False, 'error': '请输入视频链接'}), 400
    quality = str(data.get('quality') or 'best')
    if quality not in {'best', '1080p', '720p', 'audio'}:
        quality = 'best'
    remark = str(data.get('remark') or '').strip()
    try:
        save_dir = save_dir_from_request(data.get('save_path') or '')
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    jobs = read_hls_jobs()
    added = []
    owner = current_user() or 'admin'
    for url in urls:
        job = {'id': str(uuid.uuid4()), 'type': 'video', 'name': '视频下载：' + url[:80], 'url': url, 'remark': remark, 'status': 'waiting', 'progress': 0, 'size': 0, 'speed': '', 'message': '等待解析视频', 'created_at': time.time(), 'path': '', 'user': owner}
        jobs.append(job)
        added.append(job['id'])
        write_hls_jobs(jobs)
        threading.Thread(target=video_worker, args=(job['id'], url, quality, str(save_dir), owner), daemon=True).start()
    return jsonify({'ok': True, 'added': added})


@APP.post('/api/video/cookies')
def video_cookies_upload():
    err = require_auth_json()
    if err: return err
    f = request.files.get('cookies')
    if not f:
        return jsonify({'ok': False, 'error': '请选择 cookies.txt 文件'}), 400
    content = f.read(2 * 1024 * 1024 + 1)
    if len(content) > 2 * 1024 * 1024:
        return jsonify({'ok': False, 'error': 'cookies.txt 不能超过 2MB'}), 400
    text = content.decode('utf-8', errors='ignore')
    if '# Netscape HTTP Cookie File' not in text and '\t' not in text:
        return jsonify({'ok': False, 'error': '请上传 Netscape 格式的 cookies.txt'}), 400
    ytdlp_cookie_path().write_text(text, encoding='utf-8')
    return jsonify({'ok': True})


@APP.get('/api/video/cookies')
def video_cookies_status():
    err = require_auth_json()
    if err: return err
    p = ytdlp_cookie_path()
    if not p.exists():
        return jsonify({'ok': True, 'exists': False, 'size': '', 'updated_at': ''})
    st = p.stat()
    return jsonify({'ok': True, 'exists': True, 'size': fmt_bytes(st.st_size), 'updated_at': time.strftime('%Y-%m-%d %H:%M', time.localtime(st.st_mtime))})


@APP.delete('/api/video/cookies')
def video_cookies_delete():
    err = require_auth_json()
    if err: return err
    ytdlp_cookie_path().unlink(missing_ok=True)
    return jsonify({'ok': True})


@APP.get('/api/video/firmware')
def video_firmware_info():
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    version, error = ytdlp_version()
    return jsonify({'ok': True, 'version': version or '未知', 'error': error})


@APP.post('/api/video/firmware/update')
def video_firmware_update():
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    cmd = ['python3', '-m', 'pip', 'install', '--no-cache-dir', '--upgrade', 'yt-dlp']
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors='ignore', timeout=180)
    except subprocess.TimeoutExpired:
        return jsonify({'ok': False, 'error': '视频下载固件更新超时，请稍后再试'}), 504
    except Exception as e:
        return jsonify({'ok': False, 'error': f'启动更新失败：{e}'}), 500
    output = (result.stdout or '').strip()
    if result.returncode != 0:
        last = output.splitlines()[-1][-240:] if output.splitlines() else f'退出码 {result.returncode}'
        return jsonify({'ok': False, 'error': '视频下载固件更新失败：' + last}), 500
    version, error = ytdlp_version()
    return jsonify({'ok': True, 'version': version or '未知', 'message': '视频下载固件已更新', 'detail': error})


@APP.post('/api/upload-file')
def upload_file():
    err = require_auth_json()
    if err: return err
    quota_err = ensure_quota_available()
    if quota_err: return quota_err
    f = request.files.get('file')
    if not f:
        return jsonify({'ok': False, 'error': '请选择要上传的文件'}), 400
    try:
        save_dir = save_dir_from_request(request.form.get('save_path') or request.form.get('dir') or '')
        filename = safe_upload_name(f.filename)
        if not is_admin():
            quota = int(user_record().get('quota_bytes') or 0)
            upload_size = int(request.content_length or 0)
            if quota and upload_size and user_usage_bytes() + upload_size > quota:
                return jsonify({'ok': False, 'error': f'空间额度不足：{fmt_bytes(user_usage_bytes())} / {fmt_bytes(quota)}'}), 400
        target = unique_upload_path(save_dir, filename)
        f.save(target)
        if not is_admin():
            quota = int(user_record().get('quota_bytes') or 0)
            if quota and user_usage_bytes() > quota:
                target.unlink(missing_ok=True)
                return jsonify({'ok': False, 'error': f'空间额度不足：{fmt_bytes(user_usage_bytes())} / {fmt_bytes(quota)}'}), 400
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e) or '上传失败'}), 400
    return jsonify({'ok': True, 'path': str(target.relative_to(DOWNLOADS)), 'name': target.name})

@APP.get('/api/trackers')
def trackers_info():
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    meta = load_tracker_meta()
    meta['count'] = meta.get('count') or current_bt_tracker_count()
    return jsonify({'ok': True, **meta})

@APP.post('/api/trackers/update')
def trackers_update():
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    data = request.json or {}
    url = (data.get('url') or '').strip()
    try:
        meta = update_trackers_from_url(url)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    return jsonify({'ok': True, **meta})


@APP.get('/api/settings')
def settings_info():
    err = require_auth_json()
    if err: return err
    cfg = load_config()
    admin = is_admin()
    if not admin and not cfg.get('user_proxy_enabled'):
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    source = cfg if admin else user_record()
    fields = proxy_fields_from(source)
    proxy_enabled, proxy_url, proxy_mode = video_proxy_config(None if admin else current_user())
    return jsonify({
        'ok': True,
        'is_admin': admin,
        'bt_stream_prioritize': stream_prioritize_enabled(),
        'video_proxy_enabled': proxy_enabled,
        'video_proxy_url': proxy_url,
        'video_proxy_mode': proxy_mode,
        'video_proxy_type': fields.get('video_proxy_type') or 'http',
        'video_proxy_host': fields.get('video_proxy_host') or '',
        'video_proxy_port': fields.get('video_proxy_port') or '',
        'video_proxy_username': fields.get('video_proxy_username') or '',
        'video_proxy_password': fields.get('video_proxy_password') or '',
    })


@APP.post('/api/settings')
def settings_update():
    err = require_auth_json()
    if err: return err
    cfg = load_config()
    admin = is_admin()
    if not admin and not cfg.get('user_proxy_enabled'):
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    data = request.json or {}
    enabled = bool(data.get('bt_stream_prioritize')) if admin else stream_prioritize_enabled()
    try:
        proxy_type = str(data.get('video_proxy_type') or 'http').strip().lower()
        proxy_host = str(data.get('video_proxy_host') or '').strip()
        proxy_port = str(data.get('video_proxy_port') or '').strip()
        proxy_username = str(data.get('video_proxy_username') or '').strip()
        proxy_password = str(data.get('video_proxy_password') or '').strip()
        proxy_url = build_proxy_url(proxy_type, proxy_host, proxy_port, proxy_username, proxy_password)
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    proxy_enabled = bool(data.get('video_proxy_enabled')) and bool(proxy_url)
    proxy_mode = str(data.get('video_proxy_mode') or 'geo').strip().lower()
    if proxy_mode not in {'geo', 'full'}:
        proxy_mode = 'geo'
    target = cfg if admin else cfg.get('users', {}).setdefault(current_user(), {})
    if admin:
        cfg['bt_stream_prioritize'] = enabled
        cfg.pop('video_proxy_url', None)
    target['video_proxy_enabled'] = proxy_enabled
    target['video_proxy_type'] = proxy_type
    target['video_proxy_host'] = proxy_host
    target['video_proxy_port'] = proxy_port
    target['video_proxy_username'] = proxy_username
    target['video_proxy_password'] = proxy_password
    target['video_proxy_mode'] = proxy_mode
    save_config(cfg)
    if admin:
        apply_stream_prioritize(enabled)
    return jsonify({
        'ok': True,
        'bt_stream_prioritize': enabled,
        'video_proxy_enabled': proxy_enabled,
        'video_proxy_url': proxy_url,
        'video_proxy_mode': proxy_mode,
        'video_proxy_type': proxy_type,
        'video_proxy_host': proxy_host,
        'video_proxy_port': proxy_port,
        'video_proxy_username': proxy_username,
        'video_proxy_password': proxy_password,
    })


@APP.post('/api/proxy/test')
def proxy_test():
    err = require_auth_json()
    if err: return err
    if not is_admin() and not load_config().get('user_proxy_enabled'):
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    data = request.json or {}
    try:
        proxy_url = build_proxy_url(
            data.get('video_proxy_type') or 'http',
            data.get('video_proxy_host') or '',
            data.get('video_proxy_port') or '',
            data.get('video_proxy_username') or '',
            data.get('video_proxy_password') or '',
        )
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    if not proxy_url:
        return jsonify({'ok': False, 'error': '请先填写代理 IP/域名和端口'}), 400
    start = time.time()
    cmd = [
        'curl',
        '--silent',
        '--show-error',
        '--location',
        '--max-time', '8',
        '--proxy', proxy_url,
        'https://api.ipify.org',
    ]
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, errors='ignore', timeout=10)
    except subprocess.TimeoutExpired:
        return jsonify({'ok': False, 'error': '代理测试超时'}), 400
    elapsed = f'{time.time() - start:.2f}'
    body = (result.stdout or '').strip()
    err_text = (result.stderr or '').strip()
    if result.returncode != 0:
        msg = err_text.splitlines()[-1] if err_text else f'curl 退出码 {result.returncode}'
        return jsonify({'ok': False, 'error': f'代理连接失败：{msg[-220:]}'}), 400
    if not re.match(r'^[0-9a-fA-F:.]+$', body):
        body = ''
    return jsonify({'ok': True, 'message': '代理连接成功', 'ip': body, 'elapsed': elapsed})


@APP.get('/api/update/status')
def update_status():
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    return jsonify({'ok': True, **read_update_status()})

@APP.post('/api/update/upload')
def update_upload():
    err = require_auth_json()
    if err: return err
    if not is_admin():
        return jsonify({'ok': False, 'error': '需要管理员权限'}), 403
    status = read_update_status()
    if status.get('running'):
        return jsonify({'ok': False, 'error': '已有更新任务正在执行'}), 400
    f = request.files.get('update')
    if not f:
        return jsonify({'ok': False, 'error': '请选择更新包'}), 400
    filename = secure_filename(f.filename or '')
    if not (filename.endswith('.tar.gz') or filename.endswith('.tgz')):
        return jsonify({'ok': False, 'error': '请上传 .tar.gz 或 .tgz 更新包'}), 400
    path = TMP / f'upload-update-{uuid.uuid4().hex}.tar.gz'
    f.save(path)
    try:
        validate_update_archive(path)
    except Exception as e:
        path.unlink(missing_ok=True)
        return jsonify({'ok': False, 'error': str(e)}), 400
    write_update_status(running=True, message='更新任务已提交，准备执行')
    threading.Thread(target=apply_update_archive, args=(path,), daemon=True).start()
    return jsonify({'ok': True, 'message': '更新已开始，请等待 30-120 秒后刷新页面'})

@APP.get('/api/status')
def status():
    err = require_auth_json()
    if err: return err
    keys = ['gid','status','totalLength','completedLength','downloadSpeed','uploadSpeed','files','bittorrent','errorMessage','connections','numSeeders']
    tasks = []
    active = aria('aria2.tellActive', [keys])
    waiting = aria('aria2.tellWaiting', [0, 100, keys])
    stopped = aria('aria2.tellStopped', [0, 100, keys])
    live_gids = []
    for t in active + waiting + stopped:
        live_gids.append(t.get('gid'))
        total = int(t.get('totalLength') or 0); done = int(t.get('completedLength') or 0)
        files = t.get('files') or []
        name = ''
        if t.get('bittorrent', {}).get('info', {}).get('name'):
            name = t['bittorrent']['info']['name']
        elif files:
            name = Path(files[0].get('path') or files[0].get('uris',[{}])[0].get('uri','任务')).name
        owner = aria_task_owner(t)
        extra = t.get('errorMessage','')
        status_value = t.get('status')
        speed_value = int(t.get('downloadSpeed') or 0)
        if owner:
            apply_user_speed_limit_to_task(t.get('gid'), owner)
            exceeded, used_owner, quota_owner = quota_exceeded_for_user(owner)
            if exceeded:
                extra = f'用户 {owner} 空间额度已满：{fmt_bytes(used_owner)} / {fmt_bytes(quota_owner)}，任务已自动停止'
                if status_value in {'active', 'waiting', 'paused'}:
                    gid = t.get('gid')
                    for method in ('aria2.forceRemove', 'aria2.remove', 'aria2.forcePause'):
                        try:
                            aria(method, [gid])
                            break
                        except Exception:
                            pass
                    try: aria('aria2.removeDownloadResult', [gid])
                    except Exception: pass
                    try: aria('aria2.saveSession', [])
                    except Exception: pass
                    status_value = 'removed'
                    speed_value = 0
        seeders, connections = task_bt_stats(t)
        if is_admin() or aria_task_allowed(t):
            tasks.append({'type':'aria2','id':t['gid'],'name':name or t['gid'],'status':status_value,'progress':(done*100/total if total else 0),'total':fmt_bytes(total),'done':fmt_bytes(done),'speed':fmt_bytes(speed_value)+'/s','eta':eta_label(total, done, speed_value),'extra':extra,'source_url':task_source_url(t),'remark':task_remark(t),'seeders':seeders,'connections':connections})
    cleanup_task_sources(live_gids)
    for j in read_hls_jobs():
        if not hls_job_allowed(j):
            continue
        size = int(j.get('size') or 0)
        tasks.insert(0, {'type':'hls','id':j['id'],'name':j['name'],'status':j.get('status','waiting'),'progress':float(j.get('progress') or (100 if j.get('status')=='complete' else 0)),'total':'未知','done':fmt_bytes(size),'speed':j.get('speed') or '-','eta':'未知','extra':j.get('message',''),'source_url':j.get('url') or '','remark':j.get('remark') or '','seeders':0,'connections':0})
    usage = shutil.disk_usage(DOWNLOADS)
    down_speed = sum(int(t.get('downloadSpeed') or 0) for t in active)
    quota = int(user_record().get('quota_bytes') or 0) if authed() and not is_admin() else 0
    speed_limit = user_speed_limit_bytes() if authed() and not is_admin() else 0
    used = user_usage_bytes() if authed() else 0
    display_free = max(quota - used, 0) if quota else usage.free
    free_label = '额度剩余' if quota else '服务器剩余'
    free_label_key = 'quotaFree' if quota else 'serverFree'
    expires_label = fmt_expiry()
    expires_label_key = 'permanent' if expires_label == '永久有效' else ''
    return jsonify({'ok': True, 'free': fmt_bytes(display_free), 'free_label': free_label, 'free_label_key': free_label_key, 'server_free': fmt_bytes(usage.free), 'down_speed': fmt_bytes(down_speed) + '/s', 'active': sum(1 for t in tasks if t['status']=='active'), 'quota': fmt_bytes(quota) if quota else '无限制', 'used': fmt_bytes(used), 'speed_limit': fmt_speed_limit(speed_limit), 'expires_at': user_record().get('expires_at') or '', 'expires_label': expires_label, 'expires_label_key': expires_label_key, 'server_time': server_time_string(), 'version': APP_VERSION, 'tasks': tasks})

@APP.route('/api/task/<typ>/<tid>/pause', methods=['POST'])
def pause(typ, tid):
    err = require_auth_json()
    if err: return err
    if typ == 'aria2':
        try:
            info = aria('aria2.tellStatus', [tid, ['files']])
            if not aria_task_allowed(info):
                return jsonify({'ok': False, 'error': '没有权限操作这个任务'}), 403
        except Exception:
            if not is_admin():
                return jsonify({'ok': False, 'error': '没有权限操作这个任务'}), 403
        try: aria('aria2.pause', [tid])
        except Exception: pass
    else:
        if not signal_hls_task(tid, signal.SIGSTOP, True):
            return jsonify({'ok': False, 'error': '没有权限操作这个任务'}), 403
    return jsonify({'ok': True})

@APP.route('/api/task/<typ>/<tid>/resume', methods=['POST'])
def resume(typ, tid):
    err = require_auth_json()
    if err: return err
    if typ == 'aria2':
        try:
            info = aria('aria2.tellStatus', [tid, ['files']])
            if not aria_task_allowed(info):
                return jsonify({'ok': False, 'error': '没有权限操作这个任务'}), 403
        except Exception:
            if not is_admin():
                return jsonify({'ok': False, 'error': '没有权限操作这个任务'}), 403
        try: aria('aria2.unpause', [tid])
        except Exception: pass
    else:
        if not signal_hls_task(tid, signal.SIGCONT, False):
            return jsonify({'ok': False, 'error': '没有权限操作这个任务'}), 403
    return jsonify({'ok': True})

@APP.route('/api/task/<typ>/<tid>', methods=['DELETE'])
def delete_task(typ, tid):
    err = require_auth_json()
    if err: return err
    delete_files = request.args.get('files') == '1'
    if typ == 'aria2':
        if not delete_aria_task(tid, delete_files):
            return jsonify({'ok': False, 'error': '没有权限操作这个任务'}), 403
    else:
        if not delete_hls_task(tid, delete_files):
            return jsonify({'ok': False, 'error': '没有权限操作这个任务'}), 403
    return jsonify({'ok': True})


@APP.delete('/api/tasks')
def delete_all_tasks():
    err = require_auth_json()
    if err: return err
    delete_files = request.args.get('files') == '1'
    keys = ['gid', 'files']
    removed = 0
    for task in aria('aria2.tellActive', [keys]) + aria('aria2.tellWaiting', [0, 1000, keys]) + aria('aria2.tellStopped', [0, 1000, keys]):
        gid = task.get('gid')
        if not gid or not aria_task_allowed(task):
            continue
        if delete_aria_task(gid, delete_files):
            removed += 1
    for job in list(read_hls_jobs()):
        if not hls_job_allowed(job):
            continue
        if delete_hls_task(job.get('id'), delete_files):
            removed += 1
    return jsonify({'ok': True, 'removed': removed})

@APP.get('/api/files')
def files():
    err = require_auth_json()
    if err: return err
    try:
        req_path = request.args.get('path','')
        query = (request.args.get('q') or '').strip().lower()
        if not req_path and not is_admin():
            roots = user_allowed_roots()
            req_path = '' if '*' in roots else roots[0]
        root = safe_path(req_path)
    except Exception:
        return jsonify({'ok': False, 'error': '路径非法'}), 400
    if not root.exists():
        return jsonify({'ok': False, 'error': '路径不存在'}), 404
    out = []
    if query:
        items = []
        for p in root.rglob('*'):
            try:
                if path_is_allowed(p) and query in str(p.relative_to(DOWNLOADS)).lower():
                    items.append(p)
            except Exception:
                pass
        items = sorted(items, key=lambda x: (not x.is_dir(), str(x.relative_to(DOWNLOADS)).lower()))[:200]
    else:
        items = sorted(root.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
    for p in items:
        rel = str(p.relative_to(DOWNLOADS))
        suffix = p.suffix.lower()
        kind = 'video' if suffix in VIDEO_EXT else 'audio' if suffix in AUDIO_EXT else 'file'
        out.append({'name': p.name, 'path': rel, 'dir': p.is_dir(), 'size': '' if p.is_dir() else fmt_bytes(p.stat().st_size), 'mtime': time.strftime('%Y-%m-%d %H:%M', time.localtime(p.stat().st_mtime)), 'kind': kind})
    return jsonify({'ok': True, 'path': req_path, 'files': out, 'dirs': list_allowed_dirs(), 'share_token': load_config().get('share_token'), 'query': query, 'searching': bool(query)})

@APP.get('/api/dirs')
def dirs():
    err = require_auth_json()
    if err: return err
    return jsonify({'ok': True, 'dirs': list_allowed_dirs()})


@APP.get('/api/trash')
def trash_list():
    err = require_auth_json()
    if err: return err
    items = []
    changed = False
    for item in read_trash():
        p = trash_item_path(item)
        if not p.exists():
            changed = True
            continue
        if not is_admin() and item.get('user') != current_user():
            continue
        items.append({
            'id': item.get('id'),
            'name': item.get('name') or Path(item.get('path', '')).name,
            'path': item.get('path') or '',
            'dir': bool(item.get('dir')),
            'size': fmt_bytes(item.get('size') or directory_size(p)),
            'user': item.get('user') or '',
            'deleted_at': time.strftime('%Y-%m-%d %H:%M', time.localtime(item.get('deleted_at') or 0)),
        })
    if changed:
        write_trash([x for x in read_trash() if trash_item_path(x).exists()])
    items.sort(key=lambda x: x['deleted_at'], reverse=True)
    return jsonify({'ok': True, 'files': items})


@APP.post('/api/trash/<item_id>/restore')
def trash_restore(item_id):
    err = require_auth_json()
    if err: return err
    items = read_trash()
    item = next((x for x in items if x.get('id') == item_id), None)
    if not item:
        return jsonify({'ok': False, 'error': '回收站项目不存在'}), 404
    if not is_admin() and item.get('user') != current_user():
        return jsonify({'ok': False, 'error': '没有权限恢复这个文件'}), 403
    src = trash_item_path(item)
    if not src.exists():
        write_trash([x for x in items if x.get('id') != item_id])
        return jsonify({'ok': False, 'error': '回收站文件不存在'}), 404
    try:
        target = (DOWNLOADS / item.get('path', '')).resolve()
        if not path_is_allowed(target.parent):
            return jsonify({'ok': False, 'error': '没有权限恢复到原目录'}), 403
        if target.exists():
            return jsonify({'ok': False, 'error': '原路径已存在同名文件，请先改名或删除'}), 400
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(target))
        write_trash([x for x in items if x.get('id') != item_id])
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e) or '恢复失败'}), 400
    return jsonify({'ok': True})


@APP.delete('/api/trash/<item_id>')
def trash_delete(item_id):
    err = require_auth_json()
    if err: return err
    items = read_trash()
    item = next((x for x in items if x.get('id') == item_id), None)
    if not item:
        return jsonify({'ok': False, 'error': '回收站项目不存在'}), 404
    if not is_admin() and item.get('user') != current_user():
        return jsonify({'ok': False, 'error': '没有权限删除这个文件'}), 403
    p = trash_item_path(item)
    try:
        if p.is_dir():
            shutil.rmtree(p)
        elif p.exists():
            p.unlink()
        write_trash([x for x in items if x.get('id') != item_id])
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e) or '彻底删除失败'}), 400
    return jsonify({'ok': True})


@APP.delete('/api/trash')
def trash_empty():
    err = require_auth_json()
    if err: return err
    kept = []
    deleted = 0
    for item in read_trash():
        if not is_admin() and item.get('user') != current_user():
            kept.append(item)
            continue
        p = trash_item_path(item)
        try:
            if p.is_dir():
                shutil.rmtree(p)
            elif p.exists():
                p.unlink()
            deleted += 1
        except Exception:
            kept.append(item)
    write_trash(kept)
    return jsonify({'ok': True, 'deleted': deleted})

@APP.post('/api/folder')
def create_folder():
    err = require_auth_json()
    if err: return err
    data = request.json or {}
    parent = str(data.get('path') or '').strip().strip('/')
    if not parent and not is_admin():
        roots = user_allowed_roots()
        parent = '' if '*' in roots else roots[0]
    name = str(data.get('name') or '').strip().strip('/')
    if not name or '/' in name or '\\' in name or '..' in Path(name).parts:
        return jsonify({'ok': False, 'error': '文件夹名称不合法'}), 400
    try:
        base = safe_path(parent)
        if base.exists() and not base.is_dir():
            return jsonify({'ok': False, 'error': '当前位置不是文件夹'}), 400
        target = (base / name).resolve()
        if not path_is_allowed(target):
            return jsonify({'ok': False, 'error': '没有权限创建到这个目录'}), 403
        target.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e) or '创建失败'}), 400
    return jsonify({'ok': True})

@APP.route('/raw/<token>/<path:rel>')
def raw_file(token, rel):
    cfg = load_config()
    if token != cfg.get('share_token'):
        return '链接无效', 403
    try:
        p = safe_path(rel)
    except Exception:
        return '路径非法', 400
    if not p.exists() or p.is_dir():
        return '文件不存在', 404
    return send_file(p, conditional=True, as_attachment=False)

@APP.route('/download/<path:rel>')
def download(rel):
    if not authed(): return redirect('/')
    try: p = safe_path(rel)
    except Exception: return '路径非法', 400
    if not p.exists() or p.is_dir(): return '文件不存在', 404
    return send_file(p, conditional=True, as_attachment=False)

@APP.route('/download-folder/<path:rel>')
def download_folder(rel):
    if not authed(): return redirect('/')
    try:
        folder = safe_path(rel)
    except Exception:
        return '路径非法', 400
    if not folder.exists() or not folder.is_dir():
        return '文件夹不存在', 404
    if folder.resolve() == DOWNLOADS.resolve():
        return '不能下载根目录', 400
    zip_name = secure_filename(folder.name) or 'folder'
    zip_path = TMP / f'{zip_name}-{uuid.uuid4().hex}.zip'
    base_parent = folder.parent
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for item in folder.rglob('*'):
            if item.is_file():
                zf.write(item, item.relative_to(base_parent))

    @after_this_request
    def cleanup_zip(response):
        try:
            zip_path.unlink(missing_ok=True)
        except Exception:
            pass
        return response

    return send_file(zip_path, conditional=True, as_attachment=True, download_name=f'{folder.name}.zip')

@APP.post('/api/transcode')
def transcode():
    err = require_auth_json()
    if err: return err
    data = request.json or {}
    rel = data.get('path', '')
    try:
        src = safe_path(rel)
    except Exception:
        return jsonify({'ok': False, 'error': '路径非法'}), 400
    if not src.exists() or src.is_dir():
        return jsonify({'ok': False, 'error': '文件不存在'}), 404
    if src.suffix.lower() not in VIDEO_EXT:
        return jsonify({'ok': False, 'error': '只支持视频文件转码'}), 400
    job = {'id': str(uuid.uuid4()), 'type': 'hls', 'name': src.name + ' -> mobile.mp4', 'url': str(src), 'status': 'waiting', 'progress': 0, 'size': 0, 'speed': '', 'message': '等待转码', 'created_at': time.time()}
    jobs = read_hls_jobs(); jobs.append(job); write_hls_jobs(jobs)
    threading.Thread(target=transcode_worker, args=(job['id'], rel), daemon=True).start()
    return jsonify({'ok': True, 'id': job['id']})

@APP.delete('/api/file')
def delete_file():
    err = require_auth_json()
    if err: return err
    try: p = safe_path(request.args.get('path',''))
    except Exception: return jsonify({'ok': False, 'error': '路径非法'}), 400
    if p == DOWNLOADS: return jsonify({'ok': False, 'error': '不能删除根目录'}), 400
    try:
        item = move_to_trash(p)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e) or '删除失败'}), 400
    return jsonify({'ok': True, 'trash_id': item.get('id') if item else ''})


@APP.post('/api/file/rename')
def rename_file():
    err = require_auth_json()
    if err: return err
    data = request.json or {}
    try:
        p = safe_path(data.get('path', ''))
    except Exception:
        return jsonify({'ok': False, 'error': '路径非法'}), 400
    if p == DOWNLOADS:
        return jsonify({'ok': False, 'error': '不能重命名根目录'}), 400
    if not p.exists():
        return jsonify({'ok': False, 'error': '文件不存在'}), 404
    try:
        name = safe_upload_name(data.get('name') or '')
        target = (p.parent / name).resolve()
        if not path_is_allowed(target):
            return jsonify({'ok': False, 'error': '没有权限重命名到这个位置'}), 403
        if target.exists():
            return jsonify({'ok': False, 'error': '目标名称已存在'}), 400
        p.rename(target)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e) or '重命名失败'}), 400
    return jsonify({'ok': True, 'path': str(target.relative_to(DOWNLOADS)), 'name': target.name})


if __name__ == '__main__':
    start_quota_guard()
    APP.run(host='0.0.0.0', port=int(os.environ.get('APP_PORT', '8090')))
