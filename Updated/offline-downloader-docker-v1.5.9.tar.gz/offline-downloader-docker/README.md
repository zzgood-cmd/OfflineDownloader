# 离线下载中心 Docker 版

支持 BT、磁力链接、种子文件、HLS/M3U8、HTTP、FTP，多用户、额度、限速、到期时间、在线设备、Tracker 更新、文件管理、在线播放。

文件管理支持下载单个文件，也支持把整个文件夹临时打包成 `.zip` 下载。
先解压
tar -xzf offline-downloader-docker.tar.gz
cd offline-downloader-docker

## 一键安装

```bash
sudo bash install.sh
```

安装脚本会生成 8 位随机 `admin` 密码，并在安装完成后显示：

```text
访问网站：http://服务器IP:端口
账户：admin
密码：随机密码
```

默认端口：

- Web：`80/tcp`
- BT：`6881/tcp`、`6881/udp`

可自定义端口：

```bash
sudo WEB_PORT=8080 BT_PORT=6881 bash install.sh
```

## 首次登录声明

每个账号第一次登录后会看到合法用途声明，必须点击同意才能进入面板。声明状态保存在 `data/config.json`。

## 数据目录

- `data/`：配置、会话、aria2 状态、Tracker 信息
- `downloads/`：下载文件

重建容器不会删除这些目录。

## 更新

```bash
bash update.sh
```

## 卸载

```bash
bash uninstall.sh
```

卸载默认保留 `data/` 和 `downloads/`。
