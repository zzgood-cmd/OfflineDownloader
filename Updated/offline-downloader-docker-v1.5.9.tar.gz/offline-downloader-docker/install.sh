#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/offline-downloader-docker}"
WEB_PORT="${WEB_PORT:-80}"
BT_PORT="${BT_PORT:-6881}"

random_alnum() {
  local value
  value="$(openssl rand -base64 24 2>/dev/null | LC_ALL=C tr -dc 'A-Za-z0-9' | head -c 8 || true)"
  if [ "${#value}" -lt 8 ]; then
    value="$(date +%s%N | sha256sum | LC_ALL=C tr -dc 'A-Za-z0-9' | head -c 8)"
  fi
  printf '%s' "$value"
}

need_cmd() {
  command -v "$1" >/dev/null 2>&1
}

if [ "$(id -u)" -ne 0 ]; then
  echo "请使用 root 运行，或执行：sudo bash install.sh"
  exit 1
fi

if ! need_cmd docker; then
  echo "未检测到 Docker，正在安装 Docker..."
  curl -fsSL https://get.docker.com | sh
fi

if docker compose version >/dev/null 2>&1; then
  COMPOSE=(docker compose)
elif need_cmd docker-compose; then
  COMPOSE=(docker-compose)
else
  echo "未检测到 Docker Compose，请先安装 Docker Compose。"
  exit 1
fi

mkdir -p "$APP_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ "$SCRIPT_DIR" != "$APP_DIR" ]; then
  tar --exclude='./data' --exclude='./downloads' --exclude='./.env' -C "$SCRIPT_DIR" -cf - . | tar -C "$APP_DIR" -xf -
fi

cd "$APP_DIR"
mkdir -p data downloads

if [ -f .env ]; then
  ADMIN_PASSWORD="$(grep -E '^ADMIN_PASSWORD=' .env | head -n1 | cut -d= -f2- || true)"
else
  ADMIN_PASSWORD="$(random_alnum)"
  APP_SECRET="$(openssl rand -hex 32 2>/dev/null || date +%s%N | sha256sum | awk '{print $1}')"
  ARIA_SECRET="$(openssl rand -hex 24 2>/dev/null || date +%s%N | sha256sum | awk '{print $1}')"
  cat > .env <<EOF
WEB_PORT=$WEB_PORT
BT_PORT=$BT_PORT
ADMIN_PASSWORD=$ADMIN_PASSWORD
APP_SECRET=$APP_SECRET
ARIA_SECRET=$ARIA_SECRET
ARIA_RPC=http://127.0.0.1:6800/jsonrpc
APP_PORT=8090
EOF
fi

"${COMPOSE[@]}" up -d --build

SERVER_IP="$(curl -fsS --connect-timeout 3 https://api.ipify.org || hostname -I | awk '{print $1}')"
echo
echo "离线下载中心安装完成"
echo "访问网站：http://${SERVER_IP}:${WEB_PORT}"
echo "账户：admin"
echo "密码：${ADMIN_PASSWORD}"
echo
echo "请先到云服务器安全组放行端口：${WEB_PORT}/TCP、${BT_PORT}/TCP、${BT_PORT}/UDP"
