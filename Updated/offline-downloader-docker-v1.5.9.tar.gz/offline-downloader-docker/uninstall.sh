#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
docker compose down
echo "容器已停止。data/ 和 downloads/ 已保留，如需彻底删除请手动删除目录。"
