#!/usr/bin/env sh
set -eu

BASE="${BASE_DIR:-/srv/offline-downloader}"
REQUEST_FILE="$BASE/update_request.json"
STATUS_FILE="$BASE/update_status.json"
PROJECT_DIR="${HOST_PROJECT_DIR:-/opt/offline-downloader-docker}"

write_status() {
  running="$1"
  message="$2"
  log="${3:-}"
  updated_at="$(date '+%Y-%m-%d %H:%M:%S')"
  python3 - "$STATUS_FILE" "$running" "$message" "$updated_at" "$log" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
running = sys.argv[2].lower() == 'true'
message = sys.argv[3]
updated_at = sys.argv[4]
log = sys.argv[5]

try:
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        data = {}
except Exception:
    data = {}

data.update({'running': running, 'message': message, 'updated_at': updated_at})
if log:
    data['log'] = log[-3000:]
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
PY
}

run_update() {
  rm -f "$REQUEST_FILE"
  write_status true "更新助手正在重建并重启容器"
  cd "$PROJECT_DIR"
  if docker compose version >/dev/null 2>&1; then
    output="$(docker compose -p offline-downloader-docker up -d --build offline-downloader 2>&1)" || {
      write_status false "更新失败：Docker Compose 重建失败" "$output"
      return
    }
  else
    output="$(docker-compose -p offline-downloader-docker up -d --build offline-downloader 2>&1)" || {
      write_status false "更新失败：Docker Compose 重建失败" "$output"
      return
    }
  fi
  write_status false "更新完成，容器已重启，请刷新页面" "$output"
}

mkdir -p "$BASE"
write_status false "更新助手已启动"

while true; do
  if [ -f "$REQUEST_FILE" ]; then
    run_update
  fi
  sleep 3
done
