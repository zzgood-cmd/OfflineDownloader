#!/bin/sh
set -eu

BASE=/srv/offline-downloader
ARIA_DIR="$BASE/aria2"
DOWNLOADS="$BASE/downloads"
ARIA_SECRET="${ARIA_SECRET:-offline_rpc_2026}"

mkdir -p "$ARIA_DIR" "$DOWNLOADS" "$BASE/tmp"
touch "$ARIA_DIR/session.txt"

if [ ! -f "$ARIA_DIR/aria2.conf" ]; then
  cat > "$ARIA_DIR/aria2.conf" <<EOF
dir=$DOWNLOADS
input-file=$ARIA_DIR/session.txt
save-session=$ARIA_DIR/session.txt
save-session-interval=30
continue=true
enable-rpc=true
rpc-listen-all=false
rpc-listen-port=6800
rpc-secret=$ARIA_SECRET
max-concurrent-downloads=5
max-connection-per-server=8
split=8
min-split-size=1M
bt-enable-lpd=true
enable-dht=true
enable-dht6=false
dht-listen-port=6881
listen-port=6881
seed-time=0
file-allocation=none
summary-interval=5
allow-overwrite=true
auto-file-renaming=true
bt-tracker=udp://tracker.opentrackr.org:1337/announce,udp://open.stealth.si:80/announce,udp://tracker.torrent.eu.org:451/announce,udp://tracker.qu.ax:6969/announce,udp://tracker.bittor.pw:1337/announce
EOF
fi

sed -i "s#^dir=.*#dir=$DOWNLOADS#" "$ARIA_DIR/aria2.conf"
sed -i "s#^input-file=.*#input-file=$ARIA_DIR/session.txt#" "$ARIA_DIR/aria2.conf"
sed -i "s#^save-session=.*#save-session=$ARIA_DIR/session.txt#" "$ARIA_DIR/aria2.conf"
sed -i "s#^rpc-secret=.*#rpc-secret=$ARIA_SECRET#" "$ARIA_DIR/aria2.conf"

aria2c --conf-path="$ARIA_DIR/aria2.conf" &
ARIA_PID=$!

cleanup() {
  kill "$ARIA_PID" 2>/dev/null || true
}
trap cleanup INT TERM EXIT

python /opt/offline-downloader/app.py
